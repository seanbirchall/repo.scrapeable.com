# == Schemas ===================================================================

.schema_apis <- tibble::tibble(
  organization = character(),
  api_name     = character(),
  api_url      = character()
)

.schema_hubs <- tibble::tibble(
  organization = character(),
  hub_url      = character()
)

.schema_catalog <- tibble::tibble(
  name         = character(),
  type         = character(),
  url          = character(),
  organization = character()
)

# == Public functions ==========================================================

#' List all US government APIs from the 18F catalog
#'
#' Fetches and parses the individual_apis dataset from 18F's API-All-the-X
#' project. Returns a tibble with one row per API.
#'
#' @return tibble with columns: organization, api_name, api_url
#' @export
gsa_apis <- function() {
  lines <- tryCatch(.fetch_text(.apis_url), error = function(e) {
    warning("Failed to fetch APIs data: ", conditionMessage(e))
    return(character())
  })
  if (length(lines) == 0) return(.schema_apis)
  .parse_apis_yaml(lines)
}

#' List all US government developer hubs from the 18F catalog
#'
#' Fetches and parses the developer_hubs dataset from 18F's API-All-the-X
#' project. Returns a tibble with one row per developer hub.
#'
#' @return tibble with columns: organization, hub_url
#' @export
gsa_hubs <- function() {
  lines <- tryCatch(.fetch_text(.hubs_url), error = function(e) {
    warning("Failed to fetch hubs data: ", conditionMessage(e))
    return(character())
  })
  if (length(lines) == 0) return(.schema_hubs)
  .parse_hubs_yaml(lines)
}

#' Search across government APIs and developer hubs
#'
#' Performs a case-insensitive keyword search across the combined catalog of
#' APIs and developer hubs. Matches on name, organization, and URL fields.
#'
#' @param query Character string to search for (case-insensitive grep)
#' @return tibble with columns: name, type ("api" or "hub"), url, organization
#' @export
gsa_search <- function(query) {
  stopifnot(is.character(query), length(query) == 1, nzchar(query))
  catalog <- gsa_list()
  if (nrow(catalog) == 0) return(.schema_catalog)

  pattern <- query
  matches <- grepl(pattern, catalog$name, ignore.case = TRUE) |
    grepl(pattern, catalog$organization, ignore.case = TRUE) |
    grepl(pattern, catalog$url, ignore.case = TRUE)
  catalog[matches, , drop = FALSE]
}

#' Combined catalog of all government APIs and developer hubs
#'
#' Merges both datasets into a single tibble with a type column
#' distinguishing between APIs and developer hubs.
#'
#' @return tibble with columns: name, type, url, organization
#' @export
gsa_list <- function() {
  apis <- gsa_apis()
  hubs <- gsa_hubs()

  api_rows <- if (nrow(apis) > 0) {
    tibble::tibble(
      name         = apis$api_name,
      type         = "api",
      url          = apis$api_url,
      organization = apis$organization
    )
  } else {
    .schema_catalog[0, ]
  }

  hub_rows <- if (nrow(hubs) > 0) {
    tibble::tibble(
      name         = hubs$organization,
      type         = "hub",
      url          = hubs$hub_url,
      organization = hubs$organization
    )
  } else {
    .schema_catalog[0, ]
  }

  dplyr::bind_rows(api_rows, hub_rows)
}

#' Return context about the 18F / GSA client functions
#'
#' Reads the source file and returns all function signatures with
#' roxygen documentation for use by LLMs or introspection tools.
#'
#' @return Character string of the full source file (invisibly), printed to console
#' @export
gsa_context <- function() {
  .build_context("18f.gov", header_lines = c(
    "# 18f.gov - US Government API Catalog (18F / GSA)",
    "# 5 public functions: gsa_apis, gsa_hubs, gsa_search, gsa_list, gsa_context"
  ))
}
