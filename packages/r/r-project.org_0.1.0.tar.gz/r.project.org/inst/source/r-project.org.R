# cran.r-project.org.R - Self-contained cran.r-project.org client

library(httr2)
library(jsonlite)
library(tibble)
library(dplyr)


.ua <- "support@scrapeable.com"

.fetch_json <- function(url) {
  tmp <- tempfile(fileext = ".json")
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  jsonlite::fromJSON(tmp, simplifyVector = FALSE)
}


#' Search CRAN packages
#'
#' @param query Search term
#' @param size Number of results (default 30)
#' @return tibble: package, version, title, description, maintainer
cran_search <- function(query, size = 30L) {
  schema <- tibble::tibble(package = character(), version = character(),
                           title = character(), description = character(),
                           maintainer = character())
  url <- sprintf(
    "https://packagemanager.posit.co/__api__/repos/2/packages?_sort=name&_limit=%d&name_like=%s",
    as.integer(size), utils::URLencode(query, reserved = TRUE)
  )
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || length(raw) == 0) return(schema)

  if (is.list(raw) && !is.data.frame(raw)) {
    rows <- lapply(raw, function(x) {
      tibble::tibble(
        package = as.character(x$name %||% NA_character_),
        version = as.character(x$version %||% NA_character_),
        title = as.character(x$title %||% NA_character_),
        description = as.character(x$description %||% NA_character_),
        maintainer = as.character(x$maintainer %||% NA_character_)
      )
    })
    bind_rows(rows)
  } else if (is.data.frame(raw)) {
    nms <- names(raw)
    as_tibble(raw) |>
      transmute(
        package = as.character(name),
        version = as.character(version),
        title = as.character(if ("title" %in% nms) title else NA_character_),
        description = as.character(if ("description" %in% nms) description else NA_character_),
        maintainer = as.character(if ("maintainer" %in% nms) maintainer else NA_character_)
      )
  } else {
    schema
  }
}

#' Get CRAN package metadata
#'
#' @param package Package name
#' @return tibble with one row of package metadata
cran_package <- function(package) {
  url <- sprintf("https://crandb.r-pkg.org/%s", utils::URLencode(package))
  raw <- .fetch_json(url)
  tibble::tibble(
    package = raw$Package %||% NA_character_,
    version = raw$Version %||% NA_character_,
    title = raw$Title %||% NA_character_,
    description = raw$Description %||% NA_character_,
    date = raw$date %||% NA_character_,
    maintainer = raw$Maintainer %||% NA_character_,
    license = raw$License %||% NA_character_,
    url = if (!is.null(raw$URL)) raw$URL else NA_character_,
    depends = if (!is.null(raw$Depends)) paste(names(raw$Depends), collapse = ", ") else NA_character_,
    imports = if (!is.null(raw$Imports)) paste(names(raw$Imports), collapse = ", ") else NA_character_
  )
}

#' Get download counts for a CRAN package
#'
#' Uses the cranlogs API to get daily download counts.
#'
#' @param package Package name (e.g., "dplyr")
#' @param period "last-day", "last-week", "last-month" (default), or a date range "YYYY-MM-DD:YYYY-MM-DD"
#' @return tibble: date, downloads
cran_downloads <- function(package, period = "last-month") {
  url <- sprintf("https://cranlogs.r-pkg.org/downloads/daily/%s/%s",
                 period, utils::URLencode(package))
  raw <- .fetch_json(url)
  if (is.null(raw) || length(raw) == 0) return(tibble(date = as.Date(character()), downloads = integer()))

  downloads <- raw[[1]]$downloads
  if (is.null(downloads) || length(downloads) == 0) return(tibble(date = as.Date(character()), downloads = integer()))

  tibble(
    date = as.Date(vapply(downloads, function(d) d$day %||% NA_character_, character(1))),
    downloads = vapply(downloads, function(d) as.integer(d$downloads %||% 0L), integer(1))
  )
}

#' Get top downloaded CRAN packages
#'
#' @param count Number of top packages to return (default 25)
#' @param period "last-day", "last-week", or "last-month" (default)
#' @return tibble: rank, package, downloads
cran_top <- function(count = 25, period = "last-month") {
  url <- sprintf("https://cranlogs.r-pkg.org/top/%s/%d", period, as.integer(count))
  raw <- .fetch_json(url)
  if (is.null(raw)) return(tibble(rank = integer(), package = character(), downloads = integer()))

  pkgs <- raw$downloads
  if (is.null(pkgs) || length(pkgs) == 0) return(tibble(rank = integer(), package = character(), downloads = integer()))

  tibble(
    rank = seq_along(pkgs),
    package = vapply(pkgs, function(p) p$package %||% NA_character_, character(1)),
    downloads = vapply(pkgs, function(p) as.integer(p$downloads %||% 0L), integer(1))
  )
}

#' Get reverse dependencies for a CRAN package
#'
#' Shows which packages depend on, import, or suggest this package.
#'
#' @param package Package name
#' @return tibble: package, type (Depends/Imports/Suggests/LinkingTo), version, title
cran_deps <- function(package) {
  url <- sprintf("https://crandb.r-pkg.org/-/revdeps/%s", utils::URLencode(package))
  raw <- .fetch_json(url)
  if (is.null(raw) || length(raw) == 0) return(tibble(package = character(), type = character()))

  pkg_data <- raw[[1]]
  if (is.null(pkg_data)) return(tibble(package = character(), type = character()))

  rows <- list()
  for (dep_type in c("Depends", "Imports", "Suggests", "Enhances")) {
    deps <- pkg_data[[dep_type]]
    if (!is.null(deps) && length(deps) > 0) {
      dep_pkgs <- unlist(deps)
      if (length(dep_pkgs) > 0) {
        rows[[length(rows) + 1]] <- tibble(
          package = as.character(dep_pkgs),
          type = dep_type
        )
      }
    }
  }
  if (length(rows) == 0) return(tibble(package = character(), type = character()))
  bind_rows(rows)
}

# == Context ===================================================================

#' Generate LLM-friendly context for cran.r-project.org
#'
#' @return Character string with full function signatures and bodies
cran_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/cran.r-project.org.R"
  if (!file.exists(src_file)) {
    cat("# cran.r-project.org context - source not found\n")
    return(invisible("# cran.r-project.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

