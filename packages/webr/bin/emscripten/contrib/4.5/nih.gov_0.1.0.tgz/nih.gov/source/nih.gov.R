# nih.gov.R
# Self-contained NIH client.
# Covers: NIH RePORTER (grants), NCBI (Gene/PubMed), PubChem (compounds),
# and RxNav/RxNorm (drug information).
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required

library(httr2)
library(jsonlite)
library(dplyr, warn.conflicts = FALSE)
library(tibble)


# == Private utilities =========================================================

`%||%` <- function(a, b) if (is.null(a)) b else a
.ua <- "support@scrapeable.com"
.nih_base <- "https://api.reporter.nih.gov/v2"
.ncbi_base <- "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
.pubchem_base <- "https://pubchem.ncbi.nlm.nih.gov/rest/pug"
.rx_base <- "https://rxnav.nlm.nih.gov/REST"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))
.fetch_json_nested <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE)


# == Schemas ===================================================================

.schema_projects <- tibble(
  project_num = character(), title = character(), pi_name = character(),
  org_name = character(), fiscal_year = integer(),
  award_amount = numeric(), agency = character()
)

.schema_pubs <- tibble(
  pmid = character(), title = character(), journal = character(),
  pub_year = integer(), project_num = character()
)

.schema_search <- tibble(id = character(), count = integer())

.schema_summary <- tibble(uid = character(), name = character(), description = character())

.schema_compound <- tibble(
  cid = integer(), iupac_name = character(), molecular_formula = character(),
  molecular_weight = numeric(), inchi = character(),
  canonical_smiles = character()
)

.schema_properties <- tibble(
  cid = integer(), property = character(), value = character()
)

.schema_synonyms <- tibble(
  cid = integer(), synonym = character()
)

.schema_concepts <- tibble(
  rxcui = character(), name = character(), tty = character(),
  synonym = character()
)

.schema_rxcui <- tibble(
  rxcui = character()
)

.schema_suggestions <- tibble(
  suggestion = character()
)

.schema_classes <- tibble(
  class_id = character(), class_name = character(), class_type = character(),
  rxcui = character(), drug_name = character()
)




#' Search NIH-funded research projects
#'
#' @param text Full-text search across project title and abstract
#' @param pi_names PI last names (character vector)
#' @param org_names Organization names
#' @param fiscal_years Fiscal years (integer vector)
#' @param agencies NIH institute codes (e.g. "NCI", "NIAID")
#' @param limit Max results (default 50, max 500)
#' @param offset Pagination offset
#' @return tibble: project_num, title, pi_name, org_name, fiscal_year,
#'   award_amount, agency
nih_projects <- function(text = NULL, pi_names = NULL, org_names = NULL,
                         fiscal_years = NULL, agencies = NULL,
                         limit = 50, offset = 0) {
  criteria <- list()
  if (!is.null(text))         criteria$advanced_text_search <- list(operator = "and", search_field = "projecttitle,terms", search_text = text)
  if (!is.null(pi_names))     criteria$pi_names <- lapply(pi_names, function(n) list(last_name = n, any_name = n))
  if (!is.null(org_names))    criteria$org_names <- as.list(org_names)
  if (!is.null(fiscal_years)) criteria$fiscal_years <- as.list(as.integer(fiscal_years))
  if (!is.null(agencies))     criteria$agencies <- as.list(agencies)

  body <- list(criteria = criteria, limit = limit, offset = offset)

  resp <- httr2::request(paste0(.nih_base, "/projects/search")) |>
    httr2::req_headers(`User-Agent` = .ua, `Content-Type` = "application/json") |>
    httr2::req_body_json(body) |>
    httr2::req_perform()

  tmp <- tempfile(fileext = ".json")
  writeLines(httr2::resp_body_string(resp), tmp)
  raw <- jsonlite::fromJSON(tmp, simplifyVector = FALSE)

  results <- raw$results
  if (is.null(results) || length(results) == 0) return(.schema_projects)

  tibble(
    project_num  = vapply(results, function(r) r$project_num %||% NA_character_, character(1)),
    title        = vapply(results, function(r) r$project_title %||% NA_character_, character(1)),
    pi_name      = vapply(results, function(r) {
      pis <- r$principal_investigators
      if (is.null(pis) || length(pis) == 0) NA_character_
      else paste(vapply(pis, function(p) p$full_name %||% "", character(1)), collapse = "; ")
    }, character(1)),
    org_name     = vapply(results, function(r) r$organization$org_name %||% NA_character_, character(1)),
    fiscal_year  = vapply(results, function(r) as.integer(r$fiscal_year %||% NA_integer_), integer(1)),
    award_amount = vapply(results, function(r) as.numeric(r$award_amount %||% NA_real_), numeric(1)),
    agency       = vapply(results, function(r) r$agency_ic_fundings[[1]]$abbreviation %||% r$agency_code %||% NA_character_, character(1))
  )
}


#' Search publications linked to NIH grants
#'
#' @param text Search text
#' @param project_nums Project numbers to filter by
#' @param limit Max results (default 50)
#' @param offset Pagination offset
#' @return tibble: pmid, title, journal, pub_year, project_num
nih_publications <- function(text = NULL, project_nums = NULL,
                             limit = 50, offset = 0) {
  criteria <- list()
  if (!is.null(text))         criteria$advanced_text_search <- list(operator = "and", search_field = "title,abstract", search_text = text)
  if (!is.null(project_nums)) criteria$project_nums <- as.list(project_nums)

  body <- list(criteria = criteria, limit = limit, offset = offset)

  resp <- httr2::request(paste0(.nih_base, "/publications/search")) |>
    httr2::req_headers(`User-Agent` = .ua, `Content-Type` = "application/json") |>
    httr2::req_body_json(body) |>
    httr2::req_perform()

  tmp <- tempfile(fileext = ".json")
  writeLines(httr2::resp_body_string(resp), tmp)
  raw <- jsonlite::fromJSON(tmp, simplifyVector = FALSE)

  results <- raw$results
  if (is.null(results) || length(results) == 0) return(.schema_pubs)

  tibble(
    pmid        = vapply(results, function(r) as.character(r$pmid %||% NA_character_), character(1)),
    title       = vapply(results, function(r) r$title %||% NA_character_, character(1)),
    journal     = vapply(results, function(r) r$journal %||% NA_character_, character(1)),
    pub_year    = vapply(results, function(r) as.integer(r$pub_year %||% NA_integer_), integer(1)),
    project_num = vapply(results, function(r) {
      cnums <- r$coreproject
      if (is.null(cnums)) NA_character_ else as.character(cnums)
    }, character(1))
  )
}


#' Get detailed information about a specific NIH project
#'
#' @param project_num NIH project number (e.g., "5R01CA123456-05")
#' @return tibble: project_num, title, abstract, pi_name, org_name,
#'   fiscal_year, award_amount, start_date, end_date
nih_project_detail <- function(project_num) {
  schema <- tibble(project_num = character(), title = character(),
                   abstract = character(), pi_name = character(),
                   org_name = character(), fiscal_year = integer(),
                   award_amount = numeric(), start_date = character(),
                   end_date = character())

  body <- list(
    criteria = list(project_nums = list(project_num)),
    limit = 1, offset = 0
  )

  resp <- tryCatch({
    httr2::request(paste0(.nih_base, "/projects/search")) |>
      httr2::req_headers(`User-Agent` = .ua, `Content-Type` = "application/json") |>
      httr2::req_body_json(body) |>
      httr2::req_perform()
  }, error = function(e) NULL)
  if (is.null(resp)) return(schema)

  tmp <- tempfile(fileext = ".json")
  writeLines(httr2::resp_body_string(resp), tmp)
  raw <- jsonlite::fromJSON(tmp, simplifyVector = FALSE)

  results <- raw$results
  if (is.null(results) || length(results) == 0) return(schema)

  r <- results[[1]]
  tibble(
    project_num = as.character(r$project_num %||% NA_character_),
    title = as.character(r$project_title %||% NA_character_),
    abstract = as.character(r$abstract_text %||% NA_character_),
    pi_name = {
      pis <- r$principal_investigators
      if (is.null(pis) || length(pis) == 0) NA_character_
      else paste(vapply(pis, function(p) p$full_name %||% "", character(1)), collapse = "; ")
    },
    org_name = as.character(r$organization$org_name %||% NA_character_),
    fiscal_year = as.integer(r$fiscal_year %||% NA_integer_),
    award_amount = as.numeric(r$award_amount %||% NA_real_),
    start_date = as.character(r$project_start_date %||% NA_character_),
    end_date = as.character(r$project_end_date %||% NA_character_)
  )
}


#' Get NIH spending by institute/center
#'
#' Returns total spending by NIH institute for a fiscal year.
#'
#' @param fiscal_year Fiscal year (default current year)
#' @param limit Max results (default 100)
#' @return tibble: agency, total_funding, project_count
nih_spending <- function(fiscal_year = as.integer(format(Sys.Date(), "%Y")), limit = 100) {
  schema <- tibble(agency = character(), total_funding = numeric(), project_count = integer())

  # Search for all projects in the fiscal year, grouped by agency
  agencies <- c("NCI", "NIAID", "NHLBI", "NIGMS", "NINDS", "NIDDK", "NIA",
                "NIMH", "NHGRI", "NEI", "NIBIB", "NIDCR", "NIEHS", "NIDCD",
                "NINR", "NICHD", "NIAAA", "NIDA", "NCATS", "NCCIH")

  rows <- lapply(agencies, function(ag) {
    tryCatch({
      body <- list(
        criteria = list(
          fiscal_years = list(as.integer(fiscal_year)),
          agencies = list(ag)
        ),
        limit = 1, offset = 0
      )
      resp <- httr2::request(paste0(.nih_base, "/projects/search")) |>
        httr2::req_headers(`User-Agent` = .ua, `Content-Type` = "application/json") |>
        httr2::req_body_json(body) |>
        httr2::req_perform()

      tmp <- tempfile(fileext = ".json")
      writeLines(httr2::resp_body_string(resp), tmp)
      raw <- jsonlite::fromJSON(tmp, simplifyVector = FALSE)

      meta <- raw$meta
      total <- meta$total %||% 0
      funding <- if (total > 0 && length(raw$results) > 0) {
        as.numeric(meta$total %||% 0)
      } else 0

      tibble(agency = ag, total_funding = NA_real_, project_count = as.integer(total))
    }, error = function(e) NULL)
  })
  rows <- rows[!vapply(rows, is.null, logical(1))]
  if (length(rows) == 0) return(schema)
  bind_rows(rows) |> arrange(desc(project_count))
}



#' Search NCBI databases
#'
#' Search any NCBI database (gene, pubmed, protein, nucleotide, etc.)
#' Returns a list of IDs matching the query.
#'
#' @param db Database name: "gene", "pubmed", "protein", "nucleotide", etc.
#' @param term Search term (e.g. "BRCA1", "cancer AND 2024\[pdat\]")
#' @param retmax Max results (default 20, max 10000)
#' @param api_key Optional API key (raises rate limit to 10/sec)
#' @return tibble: id (character), count (integer, total matches)
ncbi_search <- function(db, term, retmax = 20, api_key = NULL) {
  url <- sprintf("%s/esearch.fcgi?db=%s&term=%s&retmode=json&retmax=%d",
                 .ncbi_base, db, utils::URLencode(term, reserved = TRUE), retmax)
  if (!is.null(api_key)) url <- paste0(url, "&api_key=", api_key)
  raw <- tryCatch(.fetch_json(url), error = function(e) { warning("NCBI error: ", e$message); NULL })
  if (is.null(raw)) return(.schema_search)
  result <- raw$esearchresult
  ids <- result$idlist
  if (is.null(ids) || length(ids) == 0) return(tibble(id = character(), count = as.integer(result$count %||% 0L)))
  tibble(id = as.character(ids), count = as.integer(result$count %||% length(ids)))
}


#' Get summaries for NCBI IDs
#'
#' @param db Database name
#' @param ids Character vector of NCBI IDs (from ncbi_search)
#' @param api_key Optional API key
#' @return tibble: uid, name, description (columns vary by database)
ncbi_summary <- function(db, ids, api_key = NULL) {
  id_str <- paste(ids, collapse = ",")
  url <- sprintf("%s/esummary.fcgi?db=%s&id=%s&retmode=json", .ncbi_base, db, id_str)
  if (!is.null(api_key)) url <- paste0(url, "&api_key=", api_key)
  raw <- tryCatch(.fetch_json(url), error = function(e) { warning("NCBI error: ", e$message); NULL })
  if (is.null(raw)) return(.schema_summary)
  result <- raw$result
  uids <- result$uids
  if (is.null(uids) || length(uids) == 0) return(.schema_summary)
  entries <- lapply(uids, function(uid) {
    r <- result[[uid]]
    if (is.null(r)) return(NULL)
    tibble(uid = as.character(uid),
           name = as.character(r$name %||% r$title %||% NA_character_),
           description = as.character(r$description %||% r$fulljournalname %||% NA_character_))
  })
  bind_rows(entries)
}


#' Search PubMed articles
#'
#' @param query Search query (e.g. "CRISPR AND 2024\[pdat\]")
#' @param retmax Max results (default 20)
#' @param api_key Optional API key
#' @return tibble: uid, name (title), description (journal)
ncbi_pubmed <- function(query, retmax = 20, api_key = NULL) {
  ids <- ncbi_search("pubmed", query, retmax = retmax, api_key = api_key)
  if (nrow(ids) == 0) return(.schema_summary)
  ncbi_summary("pubmed", ids$id, api_key = api_key)
}


#' Search NCBI genes
#'
#' @param query Gene name or symbol (e.g. "BRCA1", "TP53")
#' @param retmax Max results (default 10)
#' @param api_key Optional API key
#' @return tibble: uid, name, description
ncbi_genes <- function(query, retmax = 10, api_key = NULL) {
  ids <- ncbi_search("gene", query, retmax = retmax, api_key = api_key)
  if (nrow(ids) == 0) return(.schema_summary)
  ncbi_summary("gene", ids$id, api_key = api_key)
}



#' Look up a compound by name in PubChem
#'
#' Returns key properties for a compound identified by name.
#'
#' @param name Compound name (e.g., "aspirin", "caffeine", "glucose")
#' @return tibble: cid, iupac_name, molecular_formula, molecular_weight,
#'   inchi, canonical_smiles
pubchem_compound <- function(name) {
  url <- sprintf(
    "%s/compound/name/%s/property/IUPACName,MolecularFormula,MolecularWeight,InChI,CanonicalSMILES/JSON",
    .pubchem_base, utils::URLencode(name, reserved = TRUE)
  )
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_compound)

  props <- raw$PropertyTable$Properties
  if (is.null(props) || nrow(props) == 0) return(.schema_compound)

  nms <- names(props)
  as_tibble(props) |>
    transmute(
      cid = as.integer(CID),
      iupac_name = as.character(if ("IUPACName" %in% nms) IUPACName else NA_character_),
      molecular_formula = as.character(if ("MolecularFormula" %in% nms) MolecularFormula else NA_character_),
      molecular_weight = as.numeric(if ("MolecularWeight" %in% nms) MolecularWeight else NA_real_),
      inchi = as.character(if ("InChI" %in% nms) InChI else NA_character_),
      canonical_smiles = as.character(if ("CanonicalSMILES" %in% nms) CanonicalSMILES else NA_character_)
    )
}


#' Get specific properties for a compound
#'
#' @param name Compound name (e.g., "aspirin")
#' @param properties Comma-separated property names. Default includes common
#'   properties. See PubChem docs for full list.
#' @return tibble: cid, property, value (long format)
pubchem_properties <- function(name,
                               properties = "MolecularFormula,MolecularWeight,XLogP,ExactMass,MonoisotopicMass,TPSA,Complexity,HBondDonorCount,HBondAcceptorCount,RotatableBondCount") {
  url <- sprintf(
    "%s/compound/name/%s/property/%s/JSON",
    .pubchem_base, utils::URLencode(name, reserved = TRUE), properties
  )
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_properties)

  props <- raw$PropertyTable$Properties
  if (is.null(props) || nrow(props) == 0) return(.schema_properties)

  # Pivot to long format
  cid <- props$CID[1]
  prop_names <- setdiff(names(props), "CID")
  rows <- lapply(prop_names, function(p) {
    tibble(
      cid = as.integer(cid),
      property = p,
      value = as.character(props[[p]][1])
    )
  })
  bind_rows(rows)
}


#' Get synonyms for a compound
#'
#' @param name Compound name (e.g., "aspirin")
#' @return tibble: cid, synonym
pubchem_synonyms <- function(name) {
  url <- sprintf(
    "%s/compound/name/%s/synonyms/JSON",
    .pubchem_base, utils::URLencode(name, reserved = TRUE)
  )
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_synonyms)

  info <- raw$InformationList$Information
  if (is.null(info) || length(info) == 0) return(.schema_synonyms)

  cid <- info[[1]]$CID %||% info$CID[1]
  syns <- info[[1]]$Synonym %||% info$Synonym[[1]]
  if (is.null(syns)) return(.schema_synonyms)

  tibble(
    cid = as.integer(cid),
    synonym = as.character(syns)
  )
}


#' Search PubChem compounds by text query
#'
#' Returns multiple matching compounds with basic properties.
#'
#' @param query Search text (e.g., "aspirin", "anti-inflammatory")
#' @param max_results Maximum number of results (default 10)
#' @return tibble: cid, iupac_name, molecular_formula, molecular_weight
pubchem_search <- function(query, max_results = 10) {
  # Step 1: get CIDs from autocomplete/search
  url <- sprintf(
    "%s/compound/name/%s/cids/JSON",
    .pubchem_base, utils::URLencode(query, reserved = TRUE)
  )
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_compound[, c("cid", "iupac_name", "molecular_formula", "molecular_weight")])

  cids <- raw$IdentifierList$CID
  if (is.null(cids) || length(cids) == 0) return(.schema_compound[, c("cid", "iupac_name", "molecular_formula", "molecular_weight")])
  cids <- head(cids, max_results)

  # Step 2: get properties for those CIDs
  cid_str <- paste(cids, collapse = ",")
  prop_url <- sprintf(
    "%s/compound/cid/%s/property/IUPACName,MolecularFormula,MolecularWeight/JSON",
    .pubchem_base, cid_str
  )
  prop_raw <- tryCatch(.fetch_json(prop_url), error = function(e) NULL)
  if (is.null(prop_raw)) return(tibble(cid = as.integer(cids), iupac_name = NA_character_,
                                        molecular_formula = NA_character_, molecular_weight = NA_real_))

  props <- prop_raw$PropertyTable$Properties
  if (is.null(props) || nrow(props) == 0) return(tibble(cid = as.integer(cids)))

  nms <- names(props)
  as_tibble(props) |>
    transmute(
      cid = as.integer(CID),
      iupac_name = as.character(if ("IUPACName" %in% nms) IUPACName else NA_character_),
      molecular_formula = as.character(if ("MolecularFormula" %in% nms) MolecularFormula else NA_character_),
      molecular_weight = as.numeric(if ("MolecularWeight" %in% nms) MolecularWeight else NA_real_)
    )
}


#' Get bioactivity/assay data for a compound
#'
#' Returns bioassay results from PubChem BioAssay database.
#'
#' @param cid PubChem Compound ID (integer)
#' @param max_results Maximum assays to return (default 20)
#' @return tibble: aid, assay_name, activity_outcome, target_name
pubchem_assays <- function(cid, max_results = 20) {
  schema <- tibble(aid = integer(), assay_name = character(),
                   activity_outcome = character(), target_name = character())

  # Get assay IDs linked to this compound
  url <- sprintf("%s/compound/cid/%d/assaysummary/JSON", .pubchem_base, as.integer(cid))
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(schema)

  tbl <- raw$Table
  if (is.null(tbl)) return(schema)

  cols <- tbl$Columns$Column
  rows <- tbl$Row
  if (is.null(rows) || length(rows) == 0) return(schema)

  # Parse tabular response
  col_names <- if (is.data.frame(cols)) cols$Heading else vapply(cols, function(c) c$Heading %||% "", character(1))

  aid_idx <- which(col_names == "AID")[1]
  name_idx <- which(col_names == "Assay Name")[1]
  outcome_idx <- which(col_names == "Activity Outcome")[1]
  target_idx <- which(col_names == "Target Name")[1]

  parsed <- lapply(head(rows, max_results), function(row) {
    cells <- row$Cell
    get_cell <- function(idx) {
      if (is.na(idx) || idx > length(cells)) return(NA_character_)
      cells[[idx]] %||% NA_character_
    }
    tibble(
      aid = suppressWarnings(as.integer(get_cell(aid_idx))),
      assay_name = as.character(get_cell(name_idx)),
      activity_outcome = as.character(get_cell(outcome_idx)),
      target_name = as.character(get_cell(target_idx))
    )
  })
  bind_rows(parsed)
}


#' Look up RxCUI by drug name
#'
#' Returns the RxNorm Concept Unique Identifier (RxCUI) for a drug name.
#'
#' @param name Drug name (e.g. "aspirin", "metformin")
#' @return tibble: rxcui (character)
rxnorm_rxcui <- function(name) {
  url <- sprintf("%s/rxcui.json?name=%s", .rx_base,
                 utils::URLencode(name, reserved = TRUE))
  raw <- tryCatch(.fetch_json(url), error = function(e) {
    warning("RxNorm API error: ", e$message); NULL
  })
  if (is.null(raw)) return(.schema_rxcui)

  ids <- raw$idGroup$rxnormId
  if (is.null(ids) || length(ids) == 0) return(.schema_rxcui)
  tibble(rxcui = as.character(ids))
}



#' Search drugs by name
#'
#' Returns all RxNorm concepts matching a drug name, grouped by term type.
#'
#' @param name Drug name (e.g. "metformin")
#' @return tibble: rxcui, name, tty (term type), synonym
rxnorm_drugs <- function(name) {
  url <- sprintf("%s/drugs.json?name=%s", .rx_base,
                 utils::URLencode(name, reserved = TRUE))
  raw <- tryCatch(.fetch_json(url), error = function(e) {
    warning("RxNorm API error: ", e$message); NULL
  })
  if (is.null(raw)) return(.schema_concepts)

  groups <- raw$drugGroup$conceptGroup
  if (is.null(groups) || length(groups) == 0) return(.schema_concepts)

  results <- lapply(groups, function(g) {
    props <- g$conceptProperties
    if (is.null(props) || length(props) == 0) return(NULL)
    tibble(
      rxcui   = vapply(props, function(p) p$rxcui %||% NA_character_, character(1)),
      name    = vapply(props, function(p) p$name %||% NA_character_, character(1)),
      tty     = vapply(props, function(p) p$tty %||% NA_character_, character(1)),
      synonym = vapply(props, function(p) p$synonym %||% NA_character_, character(1))
    )
  })
  bind_rows(results)
}



#' Get drug properties by RxCUI
#'
#' @param rxcui RxNorm concept ID
#' @return tibble: one row with rxcui, name, tty, synonym
rxnorm_properties <- function(rxcui) {
  url <- sprintf("%s/rxcui/%s/properties.json", .rx_base, rxcui)
  raw <- tryCatch(.fetch_json(url), error = function(e) {
    warning("RxNorm API error: ", e$message); NULL
  })
  if (is.null(raw) || is.null(raw$properties)) return(.schema_concepts)

  p <- raw$properties
  tibble(
    rxcui   = p$rxcui %||% NA_character_,
    name    = p$name %||% NA_character_,
    tty     = p$tty %||% NA_character_,
    synonym = p$synonym %||% NA_character_
  )
}



#' Get all related concepts for a drug
#'
#' Returns all brand names, clinical drugs, dose forms, etc.
#'
#' @param rxcui RxNorm concept ID
#' @param tty Optional term type filter (e.g. "BN" for brand names,
#'   "SCD" for clinical drugs). Can be a vector.
#' @return tibble: rxcui, name, tty, synonym
rxnorm_related <- function(rxcui, tty = NULL) {
  if (!is.null(tty)) {
    tty_str <- paste(tty, collapse = "+")
    url <- sprintf("%s/rxcui/%s/related.json?tty=%s", .rx_base, rxcui, tty_str)
  } else {
    url <- sprintf("%s/rxcui/%s/allrelated.json", .rx_base, rxcui)
  }

  raw <- tryCatch(.fetch_json(url), error = function(e) {
    warning("RxNorm API error: ", e$message); NULL
  })
  if (is.null(raw)) return(.schema_concepts)

  groups <- raw$allRelatedGroup$conceptGroup %||% raw$relatedGroup$conceptGroup
  if (is.null(groups) || length(groups) == 0) return(.schema_concepts)

  results <- lapply(groups, function(g) {
    props <- g$conceptProperties
    if (is.null(props) || length(props) == 0) return(NULL)
    tibble(
      rxcui   = vapply(props, function(p) p$rxcui %||% NA_character_, character(1)),
      name    = vapply(props, function(p) p$name %||% NA_character_, character(1)),
      tty     = vapply(props, function(p) p$tty %||% NA_character_, character(1)),
      synonym = vapply(props, function(p) p$synonym %||% NA_character_, character(1))
    )
  })
  bind_rows(results)
}



#' Get spelling suggestions
#'
#' @param name Misspelled drug name
#' @return tibble: suggestion (character)
rxnorm_spelling <- function(name) {
  url <- sprintf("%s/spellingsuggestions.json?name=%s", .rx_base,
                 utils::URLencode(name, reserved = TRUE))
  raw <- tryCatch(.fetch_json(url), error = function(e) {
    warning("RxNorm API error: ", e$message); NULL
  })
  if (is.null(raw)) return(.schema_suggestions)

  suggestions <- raw$suggestionGroup$suggestionList$suggestion
  if (is.null(suggestions) || length(suggestions) == 0) return(.schema_suggestions)
  tibble(suggestion = as.character(suggestions))
}



#' Get drug classes for an RxCUI
#'
#' Returns ATC, VA, and other classification codes.
#'
#' @param rxcui RxNorm concept ID
#' @param source Classification source: "ATC", "VA", "MESH", "MEDRT".
#'   Default "ATC".
#' @return tibble: class_id, class_name, class_type, rxcui, drug_name
rxnorm_class <- function(rxcui, source = "ATC") {
  url <- sprintf("%s/rxclass/class/byRxcui.json?rxcui=%s&relaSource=%s",
                 .rx_base, rxcui, source)
  raw <- tryCatch(.fetch_json(url), error = function(e) {
    warning("RxNorm API error: ", e$message); NULL
  })
  if (is.null(raw)) return(.schema_classes)

  items <- raw$rxclassDrugInfoList$rxclassDrugInfo
  if (is.null(items) || length(items) == 0) return(.schema_classes)

  tibble(
    class_id   = vapply(items, function(i) i$rxclassMinConceptItem$classId %||% NA_character_, character(1)),
    class_name = vapply(items, function(i) i$rxclassMinConceptItem$className %||% NA_character_, character(1)),
    class_type = vapply(items, function(i) i$rxclassMinConceptItem$classType %||% NA_character_, character(1)),
    rxcui      = vapply(items, function(i) i$minConcept$rxcui %||% NA_character_, character(1)),
    drug_name  = vapply(items, function(i) i$minConcept$name %||% NA_character_, character(1))
  )
}


# == Context ===================================================================

#' Generate LLM-friendly context for nih.gov
#'
#' @return Character string with full function signatures and bodies
nih_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/nih.gov.R"
  if (!file.exists(src_file)) {
    cat("# nih.gov context - source not found\n")
    return(invisible("# nih.gov context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

