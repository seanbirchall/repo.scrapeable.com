# waterqualitydata.us.R - Self-contained waterqualitydata.us client

library(httr2)
library(tibble)
library(dplyr)


# waterqualitydata-us.R
# Self-contained Water Quality Portal client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, dplyr, tibble
# Auth: none
# Rate limits: be polite - large queries can be slow


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.wqp_base <- "https://www.waterqualitydata.us"

`%||%` <- function(a, b) if (is.null(a)) b else a

.fetch_csv <- function(url) {
  tmp <- tempfile(fileext = ".csv")
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_timeout(120) |>
    httr2::req_perform(path = tmp)
  tmp
}

# == Schemas ===================================================================

.schema_results <- tibble(
  organization = character(), activity_id = character(),
  activity_type = character(), activity_date = as.Date(character()),
  monitoring_location = character(), characteristic = character(),
  result_value = numeric(), result_unit = character(),
  result_status = character(), method_id = character()
)

.schema_stations <- tibble(
  organization = character(), monitoring_location_id = character(),
  monitoring_location_name = character(), location_type = character(),
  latitude = numeric(), longitude = numeric(),
  state_code = character(), county_code = character(),
  huc_code = character()
)

# == Results ===================================================================


#' Fetch water quality results from the Water Quality Portal
#'
#' @param countycode County FIPS code (e.g. "US:06:037" for LA County)
#' @param statecode State FIPS code (e.g. "US:06" for California)
#' @param siteid Monitoring location ID
#' @param characteristicName Filter by characteristic (e.g. "Temperature, water")
#' @param startDateLo Start date "MM-DD-YYYY"
#' @param startDateHi End date "MM-DD-YYYY"
#' @param dataProfile Data profile: "resultPhysChem" (default), "biological", "narrowResult"
#' @param top Max number of records (default 100)
#' @return tibble: organization, activity_id, activity_type, activity_date,
#'   monitoring_location, characteristic, result_value, result_unit,
#'   result_status, method_id
wqp_results <- function(countycode = NULL, statecode = NULL, siteid = NULL,
                        characteristicName = NULL, startDateLo = NULL,
                        startDateHi = NULL, dataProfile = "resultPhysChem",
                        top = 100) {
  params <- list(mimeType = "csv", zip = "no", sorted = "no")
  if (!is.null(countycode)) params$countycode <- countycode
  if (!is.null(statecode)) params$statecode <- statecode
  if (!is.null(siteid)) params$siteid <- siteid
  if (!is.null(characteristicName)) params$characteristicName <- characteristicName
  if (!is.null(startDateLo)) params$startDateLo <- startDateLo
  if (!is.null(startDateHi)) params$startDateHi <- startDateHi
  if (!is.null(dataProfile)) params$dataProfile <- dataProfile
  params$top <- as.integer(top)

  query <- paste(names(params), sapply(params, function(x) utils::URLencode(as.character(x), reserved = TRUE)), sep = "=", collapse = "&")
  url <- paste0(.wqp_base, "/data/Result/search?", query)
  f <- .fetch_csv(url)
  raw <- tryCatch(read.csv(f, stringsAsFactors = FALSE, check.names = FALSE),
                  error = function(e) data.frame())
  if (nrow(raw) == 0) return(.schema_results)

  as_tibble(raw) |>
    transmute(
      organization        = as.character(if ("OrganizationIdentifier" %in% names(raw)) OrganizationIdentifier else NA),
      activity_id         = as.character(if ("ActivityIdentifier" %in% names(raw)) ActivityIdentifier else NA),
      activity_type       = as.character(if ("ActivityTypeCode" %in% names(raw)) ActivityTypeCode else NA),
      activity_date       = tryCatch(as.Date(if ("ActivityStartDate" %in% names(raw)) ActivityStartDate else NA), error = function(e) NA),
      monitoring_location = as.character(if ("MonitoringLocationIdentifier" %in% names(raw)) MonitoringLocationIdentifier else NA),
      characteristic      = as.character(if ("CharacteristicName" %in% names(raw)) CharacteristicName else NA),
      result_value        = suppressWarnings(as.numeric(if ("ResultMeasureValue" %in% names(raw)) ResultMeasureValue else NA)),
      result_unit         = as.character(if ("ResultMeasure/MeasureUnitCode" %in% names(raw)) `ResultMeasure/MeasureUnitCode` else NA),
      result_status       = as.character(if ("ResultStatusIdentifier" %in% names(raw)) ResultStatusIdentifier else NA),
      method_id           = as.character(if ("ResultAnalyticalMethod/MethodIdentifier" %in% names(raw)) `ResultAnalyticalMethod/MethodIdentifier` else NA)
    )
}

#' Fetch monitoring stations from the Water Quality Portal
#'
#' @param countycode County FIPS code (e.g. "US:06:037")
#' @param statecode State FIPS code (e.g. "US:06")
#' @param top Max number of records (default 100)
#' @return tibble: organization, monitoring_location_id, monitoring_location_name,
#'   location_type, latitude, longitude, state_code, county_code, huc_code
wqp_stations <- function(countycode = NULL, statecode = NULL, top = 100) {
  params <- list(mimeType = "csv", zip = "no", sorted = "no")
  if (!is.null(countycode)) params$countycode <- countycode
  if (!is.null(statecode)) params$statecode <- statecode
  params$top <- as.integer(top)

  query <- paste(names(params), sapply(params, function(x) utils::URLencode(as.character(x), reserved = TRUE)), sep = "=", collapse = "&")
  url <- paste0(.wqp_base, "/data/Station/search?", query)
  f <- .fetch_csv(url)
  raw <- tryCatch(read.csv(f, stringsAsFactors = FALSE, check.names = FALSE),
                  error = function(e) data.frame())
  if (nrow(raw) == 0) return(.schema_stations)

  as_tibble(raw) |>
    transmute(
      organization            = as.character(if ("OrganizationIdentifier" %in% names(raw)) OrganizationIdentifier else NA),
      monitoring_location_id  = as.character(if ("MonitoringLocationIdentifier" %in% names(raw)) MonitoringLocationIdentifier else NA),
      monitoring_location_name = as.character(if ("MonitoringLocationName" %in% names(raw)) MonitoringLocationName else NA),
      location_type           = as.character(if ("MonitoringLocationTypeName" %in% names(raw)) MonitoringLocationTypeName else NA),
      latitude                = as.numeric(if ("LatitudeMeasure" %in% names(raw)) LatitudeMeasure else NA),
      longitude               = as.numeric(if ("LongitudeMeasure" %in% names(raw)) LongitudeMeasure else NA),
      state_code              = as.character(if ("StateCode" %in% names(raw)) StateCode else NA),
      county_code             = as.character(if ("CountyCode" %in% names(raw)) CountyCode else NA),
      huc_code                = as.character(if ("HUCEightDigitCode" %in% names(raw)) HUCEightDigitCode else NA)
    )
}

# == Characteristics lookup =====================================================

#' List available characteristics (parameters) for a location
#'
#' @param siteid Monitoring location ID (e.g. "USGS-01646500")
#' @param top Max records (default 100)
#' @return tibble: characteristic, result_count
wqp_characteristics <- function(siteid, top = 100) {
  schema <- tibble(characteristic = character(), result_count = integer())
  params <- list(mimeType = "csv", zip = "no", sorted = "no",
                 siteid = siteid, top = as.integer(top),
                 dataProfile = "resultPhysChem")
  query <- paste(names(params), sapply(params, function(x) utils::URLencode(as.character(x), reserved = TRUE)), sep = "=", collapse = "&")
  url <- paste0(.wqp_base, "/data/Result/search?", query)
  f <- tryCatch(.fetch_csv(url), error = function(e) NULL)
  if (is.null(f)) return(schema)
  raw <- tryCatch(read.csv(f, stringsAsFactors = FALSE, check.names = FALSE),
                  error = function(e) data.frame())
  if (nrow(raw) == 0 || !("CharacteristicName" %in% names(raw))) return(schema)

  as_tibble(raw) |>
    group_by(characteristic = as.character(CharacteristicName)) |>
    summarise(result_count = n(), .groups = "drop") |>
    arrange(desc(result_count))
}

#' Fetch station details with summary statistics
#'
#' @param siteid Monitoring location ID (e.g. "USGS-01646500")
#' @return tibble: organization, monitoring_location_id, monitoring_location_name,
#'   location_type, latitude, longitude, state_code, county_code, huc_code
wqp_station_detail <- function(siteid) {
  params <- list(mimeType = "csv", zip = "no", sorted = "no",
                 siteid = siteid, top = 1L)
  query <- paste(names(params), sapply(params, function(x) utils::URLencode(as.character(x), reserved = TRUE)), sep = "=", collapse = "&")
  url <- paste0(.wqp_base, "/data/Station/search?", query)
  f <- tryCatch(.fetch_csv(url), error = function(e) NULL)
  if (is.null(f)) return(.schema_stations)
  raw <- tryCatch(read.csv(f, stringsAsFactors = FALSE, check.names = FALSE),
                  error = function(e) data.frame())
  if (nrow(raw) == 0) return(.schema_stations)

  as_tibble(raw) |>
    transmute(
      organization            = as.character(if ("OrganizationIdentifier" %in% names(raw)) OrganizationIdentifier else NA),
      monitoring_location_id  = as.character(if ("MonitoringLocationIdentifier" %in% names(raw)) MonitoringLocationIdentifier else NA),
      monitoring_location_name = as.character(if ("MonitoringLocationName" %in% names(raw)) MonitoringLocationName else NA),
      location_type           = as.character(if ("MonitoringLocationTypeName" %in% names(raw)) MonitoringLocationTypeName else NA),
      latitude                = as.numeric(if ("LatitudeMeasure" %in% names(raw)) LatitudeMeasure else NA),
      longitude               = as.numeric(if ("LongitudeMeasure" %in% names(raw)) LongitudeMeasure else NA),
      state_code              = as.character(if ("StateCode" %in% names(raw)) StateCode else NA),
      county_code             = as.character(if ("CountyCode" %in% names(raw)) CountyCode else NA),
      huc_code                = as.character(if ("HUCEightDigitCode" %in% names(raw)) HUCEightDigitCode else NA)
    )
}

# == Context ===================================================================

#' Generate LLM-friendly context for waterqualitydata.us
#'
#' @return Character string with full function signatures and bodies
wqp_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/waterqualitydata.us.R"
  if (!file.exists(src_file)) {
    cat("# waterqualitydata.us context - source not found\n")
    return(invisible("# waterqualitydata.us context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

