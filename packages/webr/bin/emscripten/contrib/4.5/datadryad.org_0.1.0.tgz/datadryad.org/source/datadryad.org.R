# datadryad.org.R - Self-contained datadryad.org client

library(httr2)
library(jsonlite)
library(tibble)
library(dplyr)


# dryad.R
# Self-contained Dryad API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required
# Rate limits: be respectful


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.dryad_base <- "https://datadryad.org/api/v2"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))

`%||%` <- function(a, b) if (is.null(a)) b else a

# == Schemas ===================================================================

.schema_datasets <- tibble(
  id = integer(), doi = character(), title = character(),
  abstract = character(), published_date = as.Date(character()),
  storage_size = numeric()
)

.schema_dataset_detail <- tibble(
  id = integer(), doi = character(), title = character(),
  abstract = character(), published_date = as.Date(character()),
  storage_size = numeric(), authors = character(),
  keywords = character(), license = character()
)

# == Dataset listing ===========================================================

#' List Dryad datasets
#'
#' @param per_page Number of results per page (default 10, max 100)
#' @param page Page number (default 1)
#' @return tibble: id, doi, title, abstract, published_date, storage_size
dryad_datasets <- function(per_page = 10, page = 1) {
  url <- paste0(.dryad_base, "/datasets?per_page=", per_page, "&page=", page)
  raw <- .fetch_json(url)
  d <- raw$`_embedded`$`stash:datasets`
  if (is.null(d) || length(d) == 0) return(.schema_datasets)

  as_tibble(d) |>
    transmute(
      id = as.integer(identifier),
      doi = as.character(if ("doi" %in% names(d)) doi else NA_character_),
      title = as.character(title),
      abstract = as.character(if ("abstract" %in% names(d)) abstract else NA_character_),
      published_date = tryCatch(as.Date(if ("publicationDate" %in% names(d)) publicationDate else NA_character_), error = function(e) as.Date(NA)),
      storage_size = as.numeric(if ("storageSize" %in% names(d)) storageSize else NA_real_)
    )
}

# == Dataset detail ============================================================

#' Fetch a single Dryad dataset by DOI
#'
#' @param doi Dataset DOI (e.g. "doi:10.5061/dryad.1234")
#' @return tibble: one row with id, doi, title, abstract, published_date,
#'   storage_size, authors, keywords, license
dryad_dataset <- function(doi) {
  url <- paste0(.dryad_base, "/datasets/", utils::URLencode(doi, reserved = TRUE))
  raw <- .fetch_json(url)
  if (is.null(raw) || is.null(raw$identifier)) return(.schema_dataset_detail)

  auth_str <- if (!is.null(raw$authors) && is.data.frame(raw$authors)) {
    fn <- if ("firstName" %in% names(raw$authors)) raw$authors$firstName else ""
    ln <- if ("lastName" %in% names(raw$authors)) raw$authors$lastName else ""
    paste(trimws(paste(fn, ln)), collapse = "; ")
  } else NA_character_

  kw_str <- if (!is.null(raw$keywords)) {
    paste(raw$keywords, collapse = "; ")
  } else NA_character_

  tibble(
    id = as.integer(raw$identifier %||% NA_integer_),
    doi = as.character(raw$doi %||% NA_character_),
    title = as.character(raw$title %||% NA_character_),
    abstract = as.character(raw$abstract %||% NA_character_),
    published_date = tryCatch(as.Date(raw$publicationDate), error = function(e) as.Date(NA)),
    storage_size = as.numeric(raw$storageSize %||% NA_real_),
    authors = auth_str,
    keywords = kw_str,
    license = as.character(raw$license %||% NA_character_)
  )
}

# == Dataset search =============================================================

#' Search Dryad datasets by query
#'
#' @param query Search query string (e.g. "genomics", "ecology")
#' @param per_page Number of results per page (default 10)
#' @param page Page number (default 1)
#' @return tibble: id, doi, title, abstract, published_date, storage_size
dryad_search <- function(query, per_page = 10, page = 1) {
  url <- sprintf("%s/search?q=%s&per_page=%d&page=%d",
                 .dryad_base, utils::URLencode(query, reserved = TRUE),
                 as.integer(per_page), as.integer(page))
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_datasets)
  d <- raw$`_embedded`$`stash:datasets`
  if (is.null(d) || length(d) == 0) return(.schema_datasets)

  as_tibble(d) |>
    transmute(
      id = as.integer(identifier),
      doi = as.character(if ("doi" %in% names(d)) doi else NA_character_),
      title = as.character(title),
      abstract = as.character(if ("abstract" %in% names(d)) abstract else NA_character_),
      published_date = tryCatch(as.Date(if ("publicationDate" %in% names(d)) publicationDate else NA_character_), error = function(e) as.Date(NA)),
      storage_size = as.numeric(if ("storageSize" %in% names(d)) storageSize else NA_real_)
    )
}

#' List files in a Dryad dataset
#'
#' @param doi Dataset DOI (e.g. "doi:10.5061/dryad.1234")
#' @return tibble: path, size, mime_type, status, description
dryad_files <- function(doi) {
  schema <- tibble(path = character(), size = numeric(), mime_type = character(),
                   status = character(), description = character())
  url <- paste0(.dryad_base, "/datasets/", utils::URLencode(doi, reserved = TRUE),
                "/versions/1/files")
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(schema)
  d <- raw$`_embedded`$`stash:files`
  if (is.null(d) || length(d) == 0) return(schema)

  if (is.data.frame(d)) {
    as_tibble(d) |>
      transmute(
        path = as.character(if ("path" %in% names(d)) path else NA_character_),
        size = as.numeric(if ("size" %in% names(d)) size else NA_real_),
        mime_type = as.character(if ("mimeType" %in% names(d)) mimeType else NA_character_),
        status = as.character(if ("status" %in% names(d)) status else NA_character_),
        description = as.character(if ("description" %in% names(d)) description else NA_character_)
      )
  } else {
    tibble(
      path = vapply(d, function(x) x$path %||% NA_character_, character(1)),
      size = vapply(d, function(x) as.numeric(x$size %||% NA_real_), numeric(1)),
      mime_type = vapply(d, function(x) x$mimeType %||% NA_character_, character(1)),
      status = vapply(d, function(x) x$status %||% NA_character_, character(1)),
      description = vapply(d, function(x) x$description %||% NA_character_, character(1))
    )
  }
}

# == Context ===================================================================

#' Generate LLM-friendly context for datadryad.org
#'
#' @return Character string with full function signatures and bodies
dryad_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/datadryad.org.R"
  if (!file.exists(src_file)) {
    cat("# datadryad.org context - source not found\n")
    return(invisible("# datadryad.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

