# proteinatlas.org.R - Self-contained proteinatlas.org client

library(httr2)
library(jsonlite)
library(tibble)


# proteinatlas-org.R
# Self-contained Human Protein Atlas client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required
# Rate limits: unknown (be polite)
# Note: API returns gzip-compressed JSON; httr2 handles decompression.

library(dplyr, warn.conflicts = FALSE)
library(tibble)

# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.hpa_base <- "https://www.proteinatlas.org/api"

`%||%` <- function(a, b) if (is.null(a)) b else a
# -- Fetch helpers -------------------------------------------------------------

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua, `Accept-Encoding` = "gzip") |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_hpa_json <- function(url) {
  tmp <- .fetch(url)
  raw <- readBin(tmp, "raw", file.info(tmp)$size)
  # Check for gzip magic number
  if (length(raw) >= 2 && raw[1] == as.raw(0x1f) && raw[2] == as.raw(0x8b)) {
    txt <- memDecompress(raw, type = "gzip")
    jsonlite::fromJSON(rawToChar(txt))
  } else {
    jsonlite::fromJSON(rawToChar(raw))
  }
}

# == Schemas ===================================================================

.schema_search <- tibble(
  gene = character(), ensembl = character(), uniprot = character()
)

.schema_gene <- tibble(
  gene = character(), ensembl = character(), uniprot = character(),
  gene_description = character(), chromosome = character(),
  protein_class = character()
)

# == Public functions ==========================================================

#' Search Human Protein Atlas by gene name
#'
#' @param query Gene name or search term (e.g. "BRCA1", "TP53")
#' @param columns Comma-separated column codes to include. Default "g,eg,up"
#'   (Gene, Ensembl, Uniprot). Other codes: "gd" (gene description),
#'   "chr" (chromosome), "pc" (protein class), "t" (tissue), "sc" (subcellular)
#' @return tibble: gene, ensembl, uniprot (plus any extra columns requested)
hpa_search <- function(query, columns = "g,eg,up") {
  url <- sprintf("%s/search_download.php?search=%s&format=json&columns=%s",
                 .hpa_base, utils::URLencode(query), columns)
  raw <- tryCatch(.fetch_hpa_json(url), error = function(e) NULL)
  if (is.null(raw) || length(raw) == 0) return(.schema_search)

  df <- as_tibble(raw)
  # Normalize column names to lowercase
  names(df) <- tolower(names(df))

  # Flatten list columns (e.g. uniprot can be a list)
  for (col in names(df)) {
    if (is.list(df[[col]])) {
      df[[col]] <- vapply(df[[col]], function(x) paste(x, collapse = ";"), character(1))
    }
  }

  df
}

#' Fetch Human Protein Atlas gene detail by Ensembl ID
#'
#' @param ensembl_id Ensembl gene ID (e.g. "ENSG00000012048")
#' @param columns Column codes (default "g,eg,up,gd,chr,pc")
#' @return tibble: gene, ensembl, uniprot, gene_description, chromosome,
#'   protein_class
hpa_gene <- function(ensembl_id, columns = "g,eg,up,gd,chr,pc") {
  url <- sprintf("%s/search_download.php?search=%s&format=json&columns=%s",
                 .hpa_base, ensembl_id, columns)
  raw <- tryCatch(.fetch_hpa_json(url), error = function(e) NULL)
  if (is.null(raw) || length(raw) == 0) return(.schema_gene)

  df <- as_tibble(raw)
  names(df) <- tolower(names(df))

  for (col in names(df)) {
    if (is.list(df[[col]])) {
      df[[col]] <- vapply(df[[col]], function(x) paste(x, collapse = ";"), character(1))
    }
  }

  df
}

#' Fetch detailed gene information from Human Protein Atlas
#'
#' Uses the per-gene JSON endpoint to retrieve rich annotation including
#' RNA tissue specificity, subcellular location, disease involvement, etc.
#'
#' @param ensembl_id Ensembl gene ID (e.g. "ENSG00000141510" for TP53)
#' @return tibble: one row with gene, ensembl, description, chromosome,
#'   protein_class, rna_tissue_specificity, subcellular_location,
#'   disease_involvement
hpa_gene_detail <- function(ensembl_id) {
  schema <- tibble(
    gene = character(), ensembl = character(), description = character(),
    chromosome = character(), protein_class = character(),
    rna_tissue_specificity = character(), subcellular_location = character(),
    disease_involvement = character()
  )
  url <- sprintf("https://www.proteinatlas.org/%s.json", ensembl_id)
  raw <- tryCatch(.fetch_hpa_json(url), error = function(e) NULL)
  if (is.null(raw)) return(schema)

  .safe <- function(x) if (is.null(x)) NA_character_ else if (is.list(x) || length(x) > 1) paste(x, collapse = "; ") else as.character(x)

  tibble(
    gene = .safe(raw[["Gene"]]),
    ensembl = .safe(raw[["Ensembl"]]),
    description = .safe(raw[["Gene description"]]),
    chromosome = .safe(raw[["Chromosome"]]),
    protein_class = .safe(raw[["Protein class"]]),
    rna_tissue_specificity = .safe(raw[["RNA tissue specificity"]]),
    subcellular_location = .safe(raw[["Subcellular main location"]]),
    disease_involvement = .safe(raw[["Disease involvement"]])
  )
}

# == Context ===================================================================

#' Generate LLM-friendly context for proteinatlas.org
#'
#' @return Character string with full function signatures and bodies
proteinatlas_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/proteinatlas.org.R"
  if (!file.exists(src_file)) {
    cat("# proteinatlas.org context - source not found\n")
    return(invisible("# proteinatlas.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

