# openlibrary.org.R - Self-contained openlibrary.org client

library(httr2)
library(jsonlite)
library(tibble)
library(dplyr)


# openlibrary-org.R
# Self-contained Open Library API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.olib_base <- "https://openlibrary.org"

`%||%` <- function(a, b) if (is.null(a)) b else a

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))

# == Schemas ===================================================================

.schema_search <- tibble(
  key = character(), title = character(), author_name = character(),
  first_publish_year = integer(), publisher = character(),
  isbn = character(), subject = character(), edition_count = integer()
)

.schema_book <- tibble(
  title = character(), authors = character(), publishers = character(),
  publish_date = character(), number_of_pages = integer(),
  isbn_13 = character(), isbn_10 = character(),
  subjects = character(), cover_url = character()
)


# == Search ====================================================================

#' Search Open Library for books
#'
#' @param query Search query (e.g. "lord of the rings", "machine learning")
#' @param limit Number of results (default 20, max 100)
#' @return tibble: key, title, author_name, first_publish_year, publisher,
#'   isbn, subject, edition_count
olib_search <- function(query, limit = 20) {
  url <- sprintf("%s/search.json?q=%s&limit=%d",
                 .olib_base, utils::URLencode(query), as.integer(limit))
  raw <- tryCatch(.fetch_json(url), error = function(e) {
    message("Open Library search failed: ", e$message)
    return(NULL)
  })
  if (is.null(raw)) return(.schema_search)

  docs <- raw$docs
  if (is.null(docs) || length(docs) == 0) return(.schema_search)

  tibble(
    key                = as.character(docs$key %||% NA_character_),
    title              = as.character(docs$title %||% NA_character_),
    author_name        = vapply(docs$author_name %||% replicate(nrow(docs), NULL), function(x) {
      if (is.null(x) || length(x) == 0) NA_character_ else paste(x, collapse = "; ")
    }, character(1)),
    first_publish_year = as.integer(docs$first_publish_year %||% NA_integer_),
    publisher          = vapply(docs$publisher %||% replicate(nrow(docs), NULL), function(x) {
      if (is.null(x) || length(x) == 0) NA_character_ else paste(head(x, 3), collapse = "; ")
    }, character(1)),
    isbn               = vapply(docs$isbn %||% replicate(nrow(docs), NULL), function(x) {
      if (is.null(x) || length(x) == 0) NA_character_ else x[1]
    }, character(1)),
    subject            = vapply(docs$subject %||% replicate(nrow(docs), NULL), function(x) {
      if (is.null(x) || length(x) == 0) NA_character_ else paste(head(x, 3), collapse = "; ")
    }, character(1)),
    edition_count      = as.integer(docs$edition_count %||% NA_integer_)
  )
}

# == Book by ISBN ==============================================================

#' Get book details by ISBN from Open Library
#'
#' @param isbn ISBN-10 or ISBN-13 (e.g. "9780140328721", "0140328726")
#' @return tibble: title, authors, publishers, publish_date,
#'   number_of_pages, isbn_13, isbn_10, subjects, cover_url
olib_book <- function(isbn) {
  bibkey <- paste0("ISBN:", isbn)
  url <- sprintf("%s/api/books?bibkeys=%s&format=json&jscmd=data",
                 .olib_base, utils::URLencode(bibkey))
  raw <- tryCatch(
    jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE),
    error = function(e) {
      message("Open Library book fetch failed: ", e$message)
      return(NULL)
    }
  )
  if (is.null(raw) || length(raw) == 0) return(.schema_book)

  book <- raw[[1]]
  if (is.null(book)) return(.schema_book)

  authors <- if (!is.null(book$authors) && length(book$authors) > 0) {
    paste(vapply(book$authors, function(a) a$name %||% "", character(1)), collapse = "; ")
  } else NA_character_

  publishers <- if (!is.null(book$publishers) && length(book$publishers) > 0) {
    paste(vapply(book$publishers, function(p) p$name %||% "", character(1)), collapse = "; ")
  } else NA_character_

  subjects <- if (!is.null(book$subjects) && length(book$subjects) > 0) {
    paste(head(vapply(book$subjects, function(s) s$name %||% "", character(1)), 5), collapse = "; ")
  } else NA_character_

  isbn13 <- if (!is.null(book$identifiers$isbn_13) && length(book$identifiers$isbn_13) > 0) book$identifiers$isbn_13[[1]] else NA_character_
  isbn10 <- if (!is.null(book$identifiers$isbn_10) && length(book$identifiers$isbn_10) > 0) book$identifiers$isbn_10[[1]] else NA_character_

  cover <- if (!is.null(book$cover)) book$cover$large %||% book$cover$medium %||% NA_character_ else NA_character_

  tibble(
    title           = as.character(book$title %||% NA_character_),
    authors         = authors,
    publishers      = publishers,
    publish_date    = as.character(book$publish_date %||% NA_character_),
    number_of_pages = as.integer(book$number_of_pages %||% NA_integer_),
    isbn_13         = as.character(isbn13),
    isbn_10         = as.character(isbn10),
    subjects        = subjects,
    cover_url       = as.character(cover)
  )
}

#' Search Open Library by author name
#'
#' @param author Author name (e.g. "Tolkien", "Isaac Asimov")
#' @param limit Number of results (default 20)
#' @return tibble: key, title, author_name, first_publish_year, publisher,
#'   isbn, subject, edition_count
olib_author <- function(author, limit = 20) {
  url <- sprintf("%s/search.json?author=%s&limit=%d",
                 .olib_base, utils::URLencode(author), as.integer(limit))
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$docs) || length(raw$docs) == 0) return(.schema_search)

  docs <- raw$docs
  tibble(
    key                = as.character(docs$key %||% NA_character_),
    title              = as.character(docs$title %||% NA_character_),
    author_name        = vapply(docs$author_name %||% replicate(nrow(docs), NULL), function(x) {
      if (is.null(x) || length(x) == 0) NA_character_ else paste(x, collapse = "; ")
    }, character(1)),
    first_publish_year = as.integer(docs$first_publish_year %||% NA_integer_),
    publisher          = vapply(docs$publisher %||% replicate(nrow(docs), NULL), function(x) {
      if (is.null(x) || length(x) == 0) NA_character_ else paste(head(x, 3), collapse = "; ")
    }, character(1)),
    isbn               = vapply(docs$isbn %||% replicate(nrow(docs), NULL), function(x) {
      if (is.null(x) || length(x) == 0) NA_character_ else x[1]
    }, character(1)),
    subject            = vapply(docs$subject %||% replicate(nrow(docs), NULL), function(x) {
      if (is.null(x) || length(x) == 0) NA_character_ else paste(head(x, 3), collapse = "; ")
    }, character(1)),
    edition_count      = as.integer(docs$edition_count %||% NA_integer_)
  )
}

#' Search Open Library by subject
#'
#' @param subject Subject name (e.g. "science fiction", "history")
#' @param limit Number of results (default 20)
#' @return tibble: key, title, author_name, first_publish_year
olib_subject <- function(subject, limit = 20) {
  url <- sprintf("%s/subjects/%s.json?limit=%d",
                 .olib_base, utils::URLencode(tolower(gsub(" ", "_", subject))),
                 as.integer(limit))
  raw <- tryCatch(
    jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE),
    error = function(e) NULL
  )
  if (is.null(raw)) return(tibble(key = character(), title = character(),
                                   author_name = character(), first_publish_year = integer()))

  works <- raw$works
  if (is.null(works) || length(works) == 0) {
    return(tibble(key = character(), title = character(),
                  author_name = character(), first_publish_year = integer()))
  }

  tibble(
    key = vapply(works, function(w) w$key %||% NA_character_, character(1)),
    title = vapply(works, function(w) w$title %||% NA_character_, character(1)),
    author_name = vapply(works, function(w) {
      if (!is.null(w$authors)) paste(vapply(w$authors, function(a) a$name %||% "", character(1)), collapse = "; ")
      else NA_character_
    }, character(1)),
    first_publish_year = vapply(works, function(w) {
      as.integer(w$first_publish_year %||% NA_integer_)
    }, integer(1))
  )
}

# == Context ===================================================================

#' Generate LLM-friendly context for openlibrary.org
#'
#' @return Character string with full function signatures and bodies
olib_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/openlibrary.org.R"
  if (!file.exists(src_file)) {
    cat("# openlibrary.org context - source not found\n")
    return(invisible("# openlibrary.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

