# flickr.com.R - Self-contained Flickr public feeds client
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required (uses public feeds only)

library(httr2)
library(jsonlite)
library(tibble)
library(dplyr)

`%||%` <- function(a, b) if (is.null(a)) b else a

# == Private utilities =========================================================

.ua <- "support@scrapeable.com"

.flickr_feeds_base <- "https://api.flickr.com/services/feeds"

.fetch_json <- function(url) {
  tmp <- tempfile(fileext = ".json")
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  raw <- readLines(tmp, warn = FALSE)
  txt <- paste(raw, collapse = "\n")
  jsonlite::fromJSON(txt, simplifyVector = TRUE)
}

.parse_feed_items <- function(data) {
  items <- data$items
  if (is.null(items) || length(items) == 0 || nrow(items) == 0) {
    return(tibble(title = character(), link = character(), author = character(),
                  author_id = character(), tags = character(),
                  date_taken = character(), published = character(),
                  image_url = character()))
  }

  # Extract author name from "nobody@flickr.com (\"AuthorName\")" format
  author_clean <- gsub('.*\\("(.+)"\\)', "\\1", items$author)

  # Extract image URL from media$m
  image_url <- if (!is.null(items$media) && !is.null(items$media$m)) {
    items$media$m
  } else {
    rep(NA_character_, nrow(items))
  }

  tibble(
    title = as.character(items$title %||% NA_character_),
    link = as.character(items$link %||% NA_character_),
    author = author_clean,
    author_id = as.character(items$author_id %||% NA_character_),
    tags = as.character(items$tags %||% NA_character_),
    date_taken = as.character(items$date_taken %||% NA_character_),
    published = as.character(items$published %||% NA_character_),
    image_url = as.character(image_url)
  )
}

# == Public functions ==========================================================

#' Search Flickr public photos by tags
#'
#' @param tags Comma-separated tag string (e.g. "nature,landscape")
#' @param tagmode Tag matching mode: "any" (OR) or "all" (AND). Default "any".
#' @return tibble: title, link, author, author_id, tags, date_taken, published, image_url
flickr_search <- function(tags, tagmode = "any") {
  url <- paste0(.flickr_feeds_base,
                "/photos_public.gne?format=json&nojsoncallback=1",
                "&tags=", utils::URLencode(tags),
                "&tagmode=", tagmode)
  data <- .fetch_json(url)
  .parse_feed_items(data)
}

#' Fetch recent public photos from a Flickr user
#'
#' @param user_id Flickr user ID (e.g. "12345678@N00")
#' @return tibble: title, link, author, author_id, tags, date_taken, published, image_url
flickr_user_photos <- function(user_id) {
  url <- paste0(.flickr_feeds_base,
                "/photos_public.gne?format=json&nojsoncallback=1",
                "&id=", utils::URLencode(user_id))
  data <- .fetch_json(url)
  .parse_feed_items(data)
}

#' Fetch recent public photos from Flickr (no filter)
#'
#' @return tibble: title, link, author, author_id, tags, date_taken, published, image_url
flickr_recent <- function() {
  url <- paste0(.flickr_feeds_base,
                "/photos_public.gne?format=json&nojsoncallback=1")
  data <- .fetch_json(url)
  .parse_feed_items(data)
}

#' Fetch Flickr geotagged photos feed
#'
#' @param tags Optional comma-separated tags to filter
#' @return tibble: title, link, author, author_id, tags, date_taken, published, image_url
flickr_geo <- function(tags = NULL) {
  url <- paste0(.flickr_feeds_base,
                "/geo?format=json&nojsoncallback=1")
  if (!is.null(tags)) {
    url <- paste0(url, "&tags=", utils::URLencode(tags))
  }
  data <- .fetch_json(url)
  .parse_feed_items(data)
}

#' List available Flickr public feeds
#'
#' @return tibble: id, name, description
flickr_list <- function() {
  tibble(
    id = c("photos_public", "geo"),
    name = c("Public Photos", "Geotagged Photos"),
    description = c(
      "Recent public photos, filterable by tags or user ID",
      "Recent geotagged public photos"
    )
  )
}

#' Return context: full source of this client
#'
#' @return character: source code of this file
flickr_context <- function() {
  f <- system.file("source", "flickr.com.R", package = "flickr.com")
  if (f == "") {
    f <- tryCatch(
      { env <- sys.frame(0); getSrcFilename(env, full.names = TRUE) },
      error = function(e) ""
    )
  }
  if (f == "" || !file.exists(f)) return("Source not available")
  paste(readLines(f, warn = FALSE), collapse = "\n")
}
