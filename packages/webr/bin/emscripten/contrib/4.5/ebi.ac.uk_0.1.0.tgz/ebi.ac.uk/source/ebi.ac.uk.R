# ebi.ac.uk.R
# Self-contained EBI client covering UniProt Proteins API and ChEMBL API.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required
# Rate limits: unknown (be polite)

library(httr2)
library(jsonlite)
library(dplyr, warn.conflicts = FALSE)
library(tibble)


# == Private utilities =========================================================

`%||%` <- function(a, b) if (is.null(a)) b else a
.ua <- "support@scrapeable.com"
.ebi_base <- "https://www.ebi.ac.uk/proteins/api"
.chembl_base <- "https://www.ebi.ac.uk/chembl/api/data"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua, Accept = "application/json") |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE)
.fetch_json_simple <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = TRUE)


# == Schemas ===================================================================

.schema_protein <- tibble(
  accession = character(), id = character(), gene = character(),
  organism = character(), protein_name = character(),
  existence = character(), sequence_length = integer()
)

.schema_molecule <- tibble(
  molecule_chembl_id = character(), pref_name = character(),
  molecule_type = character(), max_phase = character(),
  formula = character(), mw = numeric(), smiles = character()
)

.schema_target <- tibble(
  target_chembl_id = character(), pref_name = character(),
  target_type = character(), organism = character()
)

.schema_activity <- tibble(
  activity_id = integer(), molecule_chembl_id = character(),
  target_chembl_id = character(), standard_type = character(),
  standard_value = numeric(), standard_units = character(),
  pchembl_value = numeric()
)


# == UniProt Proteins ==========================================================

#' Fetch a single UniProt protein entry by accession
#'
#' @param accession UniProt accession ID (e.g. "P12345", "P38398")
#' @return tibble: one row with accession, id, gene, organism, protein_name,
#'   existence, sequence_length
ebi_protein <- function(accession) {
  url <- sprintf("%s/proteins/%s", .ebi_base, accession)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_protein)

  tibble(
    accession       = as.character(raw$accession %||% NA_character_),
    id              = as.character(raw$id %||% NA_character_),
    gene            = tryCatch(as.character(raw$gene[[1]]$name$value), error = function(e) NA_character_),
    organism        = tryCatch(as.character(raw$organism$names[[1]]$value), error = function(e) NA_character_),
    protein_name    = tryCatch(as.character(raw$protein$recommendedName$fullName$value), error = function(e) NA_character_),
    existence       = as.character(raw$proteinExistence %||% NA_character_),
    sequence_length = as.integer(raw$sequence$length %||% NA_integer_)
  )
}

#' Search UniProt proteins
#'
#' @param query Search query string (gene name, protein name, etc.)
#' @param size Number of results (default 10, max 100)
#' @param offset Starting offset for pagination (default 0)
#' @return tibble: accession, id, gene, organism, protein_name, existence,
#'   sequence_length
ebi_search <- function(query, size = 10, offset = 0) {
  url <- sprintf("%s/proteins?offset=%d&size=%d&gene=%s",
                 .ebi_base, offset, size, utils::URLencode(query))
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || length(raw) == 0) return(.schema_protein)

  results <- if (is.list(raw) && !is.null(raw[[1]]$accession)) raw else list(raw)

  tibble(
    accession       = vapply(results, function(x) x$accession %||% NA_character_, character(1)),
    id              = vapply(results, function(x) x$id %||% NA_character_, character(1)),
    gene            = vapply(results, function(x)
      tryCatch(as.character(x$gene[[1]]$name$value), error = function(e) NA_character_), character(1)),
    organism        = vapply(results, function(x)
      tryCatch(as.character(x$organism$names[[1]]$value), error = function(e) NA_character_), character(1)),
    protein_name    = vapply(results, function(x) {
      v <- tryCatch(x$protein$recommendedName$fullName$value, error = function(e) NULL)
      if (is.null(v) || length(v) == 0) NA_character_ else as.character(v)
    }, character(1)),
    existence       = vapply(results, function(x) x$proteinExistence %||% NA_character_, character(1)),
    sequence_length = vapply(results, function(x) as.integer(x$sequence$length %||% NA_integer_), integer(1))
  )
}

#' Get protein features/annotations from UniProt
#'
#' Returns domain, binding site, active site, and other structural annotations.
#'
#' @param accession UniProt accession ID (e.g. "P38398")
#' @return tibble: accession, type, description, begin, end, evidence
ebi_features <- function(accession) {
  url <- sprintf("%s/features/%s", .ebi_base, accession)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(tibble(accession = character(), type = character(),
                                   description = character(), begin = integer(), end = integer()))

  features <- raw$features
  if (is.null(features) || length(features) == 0) {
    return(tibble(accession = character(), type = character(),
                  description = character(), begin = integer(), end = integer()))
  }

  tibble(
    accession = accession,
    type = vapply(features, function(f) f$type %||% NA_character_, character(1)),
    description = vapply(features, function(f) f$description %||% NA_character_, character(1)),
    begin = vapply(features, function(f) {
      tryCatch(as.integer(f$begin %||% f$location$start$value), error = function(e) NA_integer_)
    }, integer(1)),
    end = vapply(features, function(f) {
      tryCatch(as.integer(f$end %||% f$location$end$value), error = function(e) NA_integer_)
    }, integer(1)),
    evidence = vapply(features, function(f) {
      if (!is.null(f$evidences)) paste(vapply(f$evidences, function(e) e$code %||% "", character(1)), collapse = "; ")
      else NA_character_
    }, character(1))
  )
}

#' Get protein sequence as a string
#'
#' @param accession UniProt accession ID
#' @return tibble: accession, length, sequence, checksum
ebi_sequence <- function(accession) {
  url <- sprintf("%s/proteins/%s", .ebi_base, accession)
  full <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(full)) return(tibble(accession = character(), length = integer(),
                                    sequence = character(), checksum = character()))

  tibble(
    accession = accession,
    length = as.integer(full$sequence$length %||% NA_integer_),
    sequence = as.character(full$sequence$sequence %||% NA_character_),
    checksum = as.character(full$sequence$crc64 %||% NA_character_)
  )
}


# == ChEMBL ===================================================================

#' Fetch a single ChEMBL molecule by ID
#'
#' @param id ChEMBL molecule ID (e.g. "CHEMBL25" for aspirin)
#' @return tibble: one row with molecule_chembl_id, pref_name, molecule_type,
#'   max_phase, formula, mw, smiles
chembl_molecule <- function(id) {
  url <- sprintf("%s/molecule/%s.json", .chembl_base, id)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_molecule)

  props <- raw$molecule_properties
  structs <- raw$molecule_structures

  tibble(
    molecule_chembl_id = as.character(raw$molecule_chembl_id %||% NA_character_),
    pref_name          = as.character(raw$pref_name %||% NA_character_),
    molecule_type      = as.character(raw$molecule_type %||% NA_character_),
    max_phase          = as.character(raw$max_phase %||% NA_character_),
    formula            = as.character(props$full_molformula %||% NA_character_),
    mw                 = as.numeric(props$full_mwt %||% NA_real_),
    smiles             = as.character(structs$canonical_smiles %||% NA_character_)
  )
}

#' Search ChEMBL molecules by name
#'
#' @param query Search query (e.g. "aspirin", "ibuprofen")
#' @param limit Max results to return (default 10)
#' @return tibble: molecule_chembl_id, pref_name, molecule_type, max_phase,
#'   formula, mw, smiles
chembl_search <- function(query, limit = 10) {
  url <- sprintf("%s/molecule/search.json?q=%s&limit=%d",
                 .chembl_base, utils::URLencode(query), limit)
  raw <- tryCatch(.fetch_json_simple(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$molecules)) return(.schema_molecule)

  mols <- raw$molecules
  if (length(mols) == 0 || nrow(mols) == 0) return(.schema_molecule)

  tibble(
    molecule_chembl_id = as.character(mols$molecule_chembl_id),
    pref_name          = as.character(mols$pref_name),
    molecule_type      = as.character(mols$molecule_type),
    max_phase          = as.character(mols$max_phase),
    formula            = as.character(mols$molecule_properties$full_molformula),
    mw                 = as.numeric(mols$molecule_properties$full_mwt),
    smiles             = as.character(mols$molecule_structures$canonical_smiles)
  )
}

#' Fetch a single ChEMBL target by ID
#'
#' @param id ChEMBL target ID (e.g. "CHEMBL240")
#' @return tibble: one row with target_chembl_id, pref_name, target_type, organism
chembl_target <- function(id) {
  url <- sprintf("%s/target/%s.json", .chembl_base, id)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_target)

  tibble(
    target_chembl_id = as.character(raw$target_chembl_id %||% NA_character_),
    pref_name        = as.character(raw$pref_name %||% NA_character_),
    target_type      = as.character(raw$target_type %||% NA_character_),
    organism         = as.character(raw$organism %||% NA_character_)
  )
}

#' Fetch ChEMBL bioactivity data for a molecule
#'
#' @param molecule_id ChEMBL molecule ID (e.g. "CHEMBL25")
#' @param limit Max results (default 10)
#' @return tibble: activity_id, molecule_chembl_id, target_chembl_id,
#'   standard_type, standard_value, standard_units, pchembl_value
chembl_activities <- function(molecule_id, limit = 10) {
  url <- sprintf("%s/activity.json?molecule_chembl_id=%s&limit=%d",
                 .chembl_base, molecule_id, limit)
  raw <- tryCatch(.fetch_json_simple(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$activities)) return(.schema_activity)

  acts <- raw$activities
  if (length(acts) == 0 || nrow(acts) == 0) return(.schema_activity)

  tibble(
    activity_id        = as.integer(acts$activity_id),
    molecule_chembl_id = as.character(acts$molecule_chembl_id),
    target_chembl_id   = as.character(acts$target_chembl_id),
    standard_type      = as.character(acts$standard_type),
    standard_value     = as.numeric(acts$standard_value),
    standard_units     = as.character(acts$standard_units),
    pchembl_value      = as.numeric(acts$pchembl_value)
  )
}


# == Context ===================================================================

#' Generate LLM-friendly context for ebi.ac.uk
#'
#' @return Character string with full function signatures and bodies
ebi_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/ebi.ac.uk.R"
  if (!file.exists(src_file)) {
    cat("# ebi.ac.uk context - source not found\n")
    return(invisible("# ebi.ac.uk context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}
