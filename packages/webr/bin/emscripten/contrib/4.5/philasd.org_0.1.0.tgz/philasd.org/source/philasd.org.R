# philasd.org.R - Self-contained Philadelphia School District client
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble, readxl
# Auth: none required
# Note: Data is in ZIP archives containing Excel files with complex headers

library(httr2)
library(jsonlite)
library(tibble)
library(dplyr)
library(readxl)

`%||%` <- function(a, b) if (is.null(a)) b else a

# == Private utilities =========================================================

.ua <- "support@scrapeable.com"

.psd_base <- "https://cdn.philasd.org/offices/performance/Open_Data"

.fetch_file <- function(url, ext = ".zip") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_zip_excel <- function(url, sheet = 1, skip = 0) {
  f <- .fetch_file(url, ext = ".zip")
  d <- tempfile()
  dir.create(d)
  utils::unzip(f, exdir = d)
  xlsx_files <- list.files(d, pattern = "\\.xlsx$", full.names = TRUE, recursive = TRUE)
  if (length(xlsx_files) == 0) {
    xls_files <- list.files(d, pattern = "\\.xls$", full.names = TRUE, recursive = TRUE)
    csv_files <- list.files(d, pattern = "\\.csv$", full.names = TRUE, recursive = TRUE)
    if (length(csv_files) > 0) {
      return(lapply(csv_files, function(cf) {
        tryCatch(utils::read.csv(cf, stringsAsFactors = FALSE) |> as_tibble(),
                 error = function(e) tibble())
      }))
    }
    if (length(xls_files) > 0) xlsx_files <- xls_files
  }
  if (length(xlsx_files) == 0) return(list(tibble()))
  lapply(xlsx_files, function(xf) {
    tryCatch(readxl::read_excel(xf, sheet = sheet, skip = skip) |> as_tibble(),
             error = function(e) tibble())
  })
}

# == Dataset definitions =======================================================

.psd_datasets <- tibble(
  id = c("pssa_2016_2017", "pssa_2015_2016", "pssa_2014_2015",
         "pssa_2013_2014", "pssa_2012_2013", "pssa_2011_2012",
         "pssa_2010_2011", "pssa_2009_2010", "pssa_all_years"),
  name = c("PSSA & Keystone 2016-17", "PSSA & Keystone 2015-16",
           "PSSA & Keystone 2014-15", "PSSA & Keystone 2013-14",
           "PSSA & Keystone 2012-13", "PSSA 2011-12",
           "PSSA 2010-11", "PSSA 2009-10", "PSSA & Keystone All Years"),
  url = c(
    paste0(.psd_base, "/School_Performance/PSSA_Keystone/2016_2017_PSSA_Keystone_All_Data.zip"),
    paste0(.psd_base, "/School_Performance/PSSA_Keystone/2015_2016_PSSA_Keystone_All_Data.zip"),
    paste0(.psd_base, "/School_Performance/PSSA_Keystone/2014_2015_PSSA_Keystone_All_Data.zip"),
    paste0(.psd_base, "/School_Performance/PSSA_Keystone/2013_2014_PSSA_Keystone_All_Data.zip"),
    paste0(.psd_base, "/School_Performance/PSSA_Keystone/2012_2013_PSSA_Keystone_All_Data.zip"),
    paste0(.psd_base, "/School_Performance/PSSA_Keystone/2011_2012_PSSA_All_Data.zip"),
    paste0(.psd_base, "/School_Performance/PSSA_Keystone/2010_2011_PSSA_All_Data.zip"),
    paste0(.psd_base, "/School_Performance/PSSA_Keystone/2009_2010_PSSA_All_Data.zip"),
    paste0(.psd_base, "/School_Performance/PSSA_Keystone/PSSA_Keystone_All_Years.zip")
  ),
  category = rep("pssa_keystone", 9)
)

# == Public functions ==========================================================

#' List available Philadelphia School District datasets
#'
#' @return tibble: id, name, url, category
psd_list <- function() {
  .psd_datasets
}

#' List files inside a PSSA/Keystone ZIP archive
#'
#' @param dataset_id Dataset id from psd_list()
#' @return tibble: Name, Length, Date (contents of ZIP)
psd_zip_contents <- function(dataset_id) {
  match <- .psd_datasets |> filter(.data$id == !!dataset_id)
  if (nrow(match) == 0) {
    stop("Unknown dataset: ", dataset_id, call. = FALSE)
  }
  f <- .fetch_file(match$url[1], ext = ".zip")
  utils::unzip(f, list = TRUE) |> as_tibble()
}

#' Download and extract a PSSA dataset from ZIP archive
#'
#' Returns a list of tibbles, one per Excel file found in the ZIP.
#' Note: These Excel files have complex multi-row headers. Use
#' the sheet and skip parameters to navigate.
#'
#' @param dataset_id Dataset id from psd_list()
#' @param sheet Sheet name or number to read (default 1)
#' @param skip Number of header rows to skip (default 0)
#' @return list of tibbles: one per Excel file in the archive
psd_data <- function(dataset_id, sheet = 1, skip = 0) {
  match <- .psd_datasets |> filter(.data$id == !!dataset_id)
  if (nrow(match) == 0) {
    stop("Unknown dataset: ", dataset_id, call. = FALSE)
  }
  .fetch_zip_excel(match$url[1], sheet = sheet, skip = skip)
}

#' List sheets in the Excel files of a PSSA dataset
#'
#' @param dataset_id Dataset id from psd_list()
#' @return named list: filename -> vector of sheet names
psd_sheets <- function(dataset_id) {
  match <- .psd_datasets |> filter(.data$id == !!dataset_id)
  if (nrow(match) == 0) stop("Unknown dataset: ", dataset_id, call. = FALSE)
  f <- .fetch_file(match$url[1], ext = ".zip")
  d <- tempfile(); dir.create(d)
  utils::unzip(f, exdir = d)
  xlsx_files <- list.files(d, pattern = "\\.xlsx?$", full.names = TRUE, recursive = TRUE)
  result <- lapply(xlsx_files, function(xf) {
    tryCatch(readxl::excel_sheets(xf), error = function(e) character(0))
  })
  names(result) <- basename(xlsx_files)
  result
}

#' Return context: full source of this client
#'
#' @return character: source code of this file
psd_context <- function() {
  f <- system.file("source", "philasd.org.R", package = "philasd.org")
  if (f == "") {
    f <- tryCatch(
      { env <- sys.frame(0); getSrcFilename(env, full.names = TRUE) },
      error = function(e) ""
    )
  }
  if (f == "" || !file.exists(f)) return("Source not available")
  paste(readLines(f, warn = FALSE), collapse = "\n")
}
