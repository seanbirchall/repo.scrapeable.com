# americorps.gov.R
# Self-contained AmeriCorps Open Data (Socrata SODA) client.
# All public functions return tibbles.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required (public Socrata portal)
# Rate limits: standard Socrata throttling; pass app_token to increase
# Docs: https://dev.socrata.com/docs/queries/

library(httr2)
library(jsonlite)
library(dplyr, warn.conflicts = FALSE)
library(tibble)

`%||%` <- function(x, y) if (is.null(x)) y else x

# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.acorps_base <- "https://data.americorps.gov"

# -- SODA query engine ---------------------------------------------------------

._soda_query <- function(view_id, where = NULL, select = NULL, group = NULL,
                         order = NULL, limit = 1000, offset = 0,
                         token = NULL, max_results = NULL) {
  all_data <- list()
  current_offset <- offset
  page_size <- min(limit, 50000)

  repeat {
    params <- list(`$limit` = page_size, `$offset` = current_offset)
    if (!is.null(where))  params[["$where"]]  <- where
    if (!is.null(select)) params[["$select"]] <- select
    if (!is.null(group))  params[["$group"]]  <- group
    if (!is.null(order))  params[["$order"]]  <- order

    query <- paste(
      names(params),
      vapply(params, function(v) utils::URLencode(as.character(v), reserved = TRUE),
             character(1)),
      sep = "=", collapse = "&"
    )
    url <- paste0(.acorps_base, "/resource/", view_id, ".json?", query)
    if (!is.null(token)) url <- paste0(url, "&$$app_token=", token)

    tmp <- tempfile(fileext = ".json")
    tryCatch({
      httr2::request(url) |>
        httr2::req_headers(`User-Agent` = .ua) |>
        httr2::req_perform(path = tmp)
    }, error = function(e) {
      warning("SODA request failed for ", view_id, ": ", conditionMessage(e))
      return(NULL)
    })

    if (!file.exists(tmp)) break
    raw <- tryCatch(jsonlite::fromJSON(tmp), error = function(e) NULL)
    if (is.null(raw) || length(raw) == 0 || (is.data.frame(raw) && nrow(raw) == 0)) break
    all_data[[length(all_data) + 1]] <- as_tibble(raw)

    n_so_far <- sum(vapply(all_data, nrow, integer(1)))
    if (!is.null(max_results) && n_so_far >= max_results) break
    if (is.data.frame(raw) && nrow(raw) < page_size) break
    current_offset <- current_offset + page_size
  }

  if (length(all_data) == 0) return(tibble())
  result <- bind_rows(all_data)
  if (!is.null(max_results)) result <- head(result, max_results)
  result
}

.fetch_json <- function(url) {
  tmp <- tempfile(fileext = ".json")
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  jsonlite::fromJSON(tmp, simplifyVector = FALSE)
}

# == Dataset catalog ===========================================================

.acorps_catalog <- tibble::tribble(
  ~view_id,     ~name,                                                              ~category,
  "yie5-ur4v",  "AmeriCorps NCCC Deployments (legacy)",                             "deployments",
  "45t9-x5kj",  "AmeriCorps NCCC Traditional Deployments",                          "deployments",
  "5d3h-y6uy",  "AmeriCorps NCCC Forest Deployments",                               "deployments",
  "c8jn-su9n",  "AmeriCorps NCCC FEMA Deployments",                                 "deployments",
  "kusw-dg5a",  "AmeriCorps NCCC Southern Region Traditional Deployments",           "deployments",
  "eqsg-p2xa",  "AmeriCorps NCCC Pacific Region Traditional Deployments",            "deployments",
  "m4cu-73zi",  "AmeriCorps NCCC Southwest Region Traditional Deployments",          "deployments",
  "xuki-piwn",  "Segal Education Award: Detailed Payments by Institution 1994-2023", "education_award",
  "dz6i-y5ak",  "Segal Education Award: Payments by State",                          "education_award",
  "26pv-trba",  "Segal Education Award: Payments and Alumni by Institution",          "education_award",
  "thgj-sd6i",  "Segal Education Award: Detailed Payments by Institution 2019",       "education_award",
  "dxxz-mepu",  "Segal Education Award: Detailed Payments by Institution 2020",       "education_award",
  "a97a-g8k4",  "Segal Education Award: Detailed Payments by Institution (legacy)",   "education_award",
  "8t8t-a6ry",  "Segal Education Award: Payments and Alumni by Institution 2020",     "education_award",
  "7kf8-4txu",  "Segal Education Award: Payments and Alumni by Institution 2019",     "education_award",
  "gujh-zj6b",  "2024 AmeriCorps Member Exit Survey",                                "member_survey",
  "frpm-n3u5",  "2023 AmeriCorps Member Exit Survey",                                "member_survey",
  "59ia-vsnv",  "2022 AmeriCorps Member Exit Survey",                                "member_survey",
  "58uq-h8je",  "2021 AmeriCorps Member Exit Survey",                                "member_survey",
  "tnxs-meph",  "2020 AmeriCorps Member Exit Survey",                                "member_survey",
  "3s9n-2btu",  "2019 AmeriCorps Member Exit Survey",                                "member_survey",
  "sypt-sh4u",  "2018 AmeriCorps Member Exit Survey",                                "member_survey",
  "tpbh-nswq",  "2017 AmeriCorps Member Exit Survey",                                "member_survey",
  "wqhv-fm5d",  "2016 AmeriCorps Member Exit Survey",                                "member_survey",
  "a63n-jsfz",  "AmeriCorps Member Exit Survey 01/01/2018-12/31/2018",               "member_survey",
  "rhng-qtzw",  "CEV Findings: National Rates of All Measures (2017-2023)",           "civic_engagement",
  "bhmf-84dy",  "CEV Findings: National Rates by Demographics (2017-2023)",           "civic_engagement",
  "4r6x-re58",  "CEV Findings: State-Level Rates (2017-2023)",                        "civic_engagement",
  "9zzx-8cwf",  "2023 CEV Findings: Volunteering Toplines",                           "civic_engagement",
  "twy4-5nxu",  "2017 CEV Data",                                                      "civic_engagement",
  "a6ak-yd7k",  "2019 CEV Data",                                                      "civic_engagement",
  "n3gv-uwex",  "2021 CEV Data",                                                      "civic_engagement",
  "be5g-4c5r",  "2023 CEV Data",                                                      "civic_engagement",
  "i9xs-fvag",  "AmeriCorps Participant Demographics Data",                            "demographics",
  "as6e-6nns",  "AmeriCorps Member Race and Ethnicity National Figures",               "demographics",
  "hznm-uizi",  "AmeriCorps Research Grantee Dataset",                                 "research",
  "c88b-pc22",  "Employers of National Service",                                       "employers",
  "f3y6-ew2i",  "Open Data Platform Asset Views and Downloads",                        "platform",
  "izv6-as2d",  "NSCHC Rule Change Data",                                              "compliance",
  "et85-j49w",  "Criminal History Check - Recurring Access",                           "compliance",
  "yhps-cx97",  "State Profile Geospatial Data",                                       "geospatial"
)


# == Discovery =================================================================

#' List all AmeriCorps open datasets
#'
#' Returns a hardcoded catalog of all available Socrata datasets on
#' data.americorps.gov with view IDs, names, and categories.
#'
#' @param category Optional filter: "deployments", "education_award",
#'   "member_survey", "civic_engagement", "demographics", "research",
#'   "employers", "platform", "compliance", "geospatial"
#' @return tibble: view_id, name, category
acorps_list <- function(category = NULL) {
  out <- .acorps_catalog
  if (!is.null(category)) {
    out <- out |> filter(.data$category == .env$category)
  }
  out
}

#' Search AmeriCorps datasets by keyword
#'
#' Searches dataset names in the local catalog by keyword (case-insensitive).
#'
#' @param query Search string (matched against name)
#' @return tibble: view_id, name, category
acorps_search <- function(query) {
  .acorps_catalog |>
    filter(grepl(query, name, ignore.case = TRUE))
}

#' Get column metadata for an AmeriCorps dataset
#'
#' @param view_id Socrata 4x4 view identifier (e.g. "yie5-ur4v")
#' @return tibble: field_name, name, datatype, description
acorps_columns <- function(view_id) {
  url <- sprintf("%s/api/views/%s.json", .acorps_base, view_id)
  raw <- tryCatch(.fetch_json(url), error = function(e) {
    warning("Could not fetch metadata for ", view_id, ": ", conditionMessage(e))
    return(list())
  })
  cols <- raw$columns
  if (is.null(cols) || length(cols) == 0)
    return(tibble(field_name = character(), name = character(),
                  datatype = character(), description = character()))
  bind_rows(lapply(cols, function(c) {
    tibble(
      field_name  = c$fieldName %||% NA_character_,
      name        = c$name %||% NA_character_,
      datatype    = c$dataTypeName %||% NA_character_,
      description = c$description %||% NA_character_
    )
  }))
}


# == Generic SODA access =======================================================

#' Query any AmeriCorps Socrata dataset
#'
#' Generic SODA query interface for data.americorps.gov.
#'
#' @param view_id Socrata 4x4 view identifier (e.g. "yie5-ur4v")
#' @param limit Max rows to return (default 1000)
#' @param where SoQL WHERE clause (e.g. "year='2024'")
#' @param select SoQL SELECT clause
#' @param group SoQL GROUP BY clause
#' @param order SoQL ORDER BY clause
#' @param offset Row offset for pagination
#' @param token Optional Socrata app token
#' @return tibble of query results
acorps_view <- function(view_id, limit = 1000, where = NULL, select = NULL,
                        group = NULL, order = NULL, offset = 0, token = NULL) {
  ._soda_query(view_id, where = where, select = select, group = group,
               order = order, limit = limit, offset = offset,
               token = token, max_results = limit)
}


# == NCCC Deployments ==========================================================

#' AmeriCorps NCCC traditional deployments
#'
#' Current and recent NCCC team deployments across the United States.
#'
#' @param year Filter by program year (e.g. "2024")
#' @param state Two-letter state abbreviation (e.g. "CA")
#' @param campus Campus name filter (partial match via SoQL LIKE)
#' @param limit Max rows (default 1000)
#' @param token Optional Socrata app token
#' @return tibble: year, campus, corps, team, nbr_of_corps_members, start_date,
#'   end_date, sponsor, project_description, stabbr, ...
acorps_deployments <- function(year = NULL, state = NULL, campus = NULL,
                               limit = 1000, token = NULL) {
  parts <- character()
  if (!is.null(year))   parts <- c(parts, sprintf("year='%s'", year))
  if (!is.null(state))  parts <- c(parts, sprintf("stabbr='%s'", state))
  if (!is.null(campus)) parts <- c(parts, sprintf("campus LIKE '%%%s%%'", campus))
  where <- if (length(parts) > 0) paste(parts, collapse = " AND ") else NULL
  ._soda_query("45t9-x5kj", where = where, limit = limit,
               token = token, max_results = limit)
}

#' AmeriCorps NCCC forest deployments
#'
#' @param year Filter by program year
#' @param limit Max rows (default 1000)
#' @param token Optional Socrata app token
#' @return tibble of forest corps deployment records
acorps_forest_deployments <- function(year = NULL, limit = 1000, token = NULL) {
  where <- if (!is.null(year)) sprintf("year='%s'", year) else NULL
  ._soda_query("5d3h-y6uy", where = where, limit = limit,
               token = token, max_results = limit)
}

#' AmeriCorps NCCC FEMA deployments
#'
#' @param year Filter by program year
#' @param limit Max rows (default 1000)
#' @param token Optional Socrata app token
#' @return tibble of FEMA deployment records
acorps_fema_deployments <- function(year = NULL, limit = 1000, token = NULL) {
  where <- if (!is.null(year)) sprintf("year='%s'", year) else NULL
  ._soda_query("c8jn-su9n", where = where, limit = limit,
               token = token, max_results = limit)
}


# == Education Awards ==========================================================

#' Segal AmeriCorps Education Award payments by institution (1994-2023)
#'
#' @param state Two-letter state abbreviation filter
#' @param year Fiscal year filter (e.g. "2020")
#' @param institution Institution name filter (partial match)
#' @param limit Max rows (default 1000)
#' @param token Optional Socrata app token
#' @return tibble: institution, system, campus, state, year,
#'   earned_award_type, payment_type, total_payments
acorps_education_awards <- function(state = NULL, year = NULL,
                                    institution = NULL, limit = 1000,
                                    token = NULL) {
  parts <- character()
  if (!is.null(state)) parts <- c(parts, sprintf("state='%s'", state))
  if (!is.null(year))  parts <- c(parts, sprintf("year='%s'", year))
  if (!is.null(institution))
    parts <- c(parts, sprintf("institution LIKE '%%%s%%'", toupper(institution)))
  where <- if (length(parts) > 0) paste(parts, collapse = " AND ") else NULL
  ._soda_query("xuki-piwn", where = where, limit = limit,
               token = token, max_results = limit)
}

#' Segal Education Award payments by state
#'
#' Aggregate payments and alumni counts by state/territory.
#'
#' @param state Location name filter (e.g. "California")
#' @param limit Max rows (default 100)
#' @param token Optional Socrata app token
#' @return tibble: location, all_payments, education_payments, loan_payments,
#'   all_individuals, individuals_education, individuals_loan
acorps_education_awards_by_state <- function(state = NULL, limit = 100,
                                             token = NULL) {
  where <- if (!is.null(state)) sprintf("location='%s'", state) else NULL
  ._soda_query("dz6i-y5ak", where = where, limit = limit,
               token = token, max_results = limit)
}


# == Member Exit Surveys =======================================================

#' AmeriCorps Member Exit Survey data
#'
#' Fetches member exit survey data for a given year. Available years:
#' 2016-2024.
#'
#' @param year Survey year (character or numeric, e.g. 2023). Default: 2024.
#' @param limit Max rows (default 1000)
#' @param where Optional SoQL WHERE clause
#' @param token Optional Socrata app token
#' @return tibble of survey responses
acorps_member_survey <- function(year = 2024, limit = 1000, where = NULL,
                                 token = NULL) {
  ids <- c(
    "2024" = "gujh-zj6b", "2023" = "frpm-n3u5", "2022" = "59ia-vsnv",
    "2021" = "58uq-h8je", "2020" = "tnxs-meph", "2019" = "3s9n-2btu",
    "2018" = "sypt-sh4u", "2017" = "tpbh-nswq", "2016" = "wqhv-fm5d"
  )
  yr <- as.character(year)
  if (!yr %in% names(ids)) {
    stop("No member exit survey for year ", yr,
         ". Available: ", paste(names(ids), collapse = ", "))
  }
  ._soda_query(ids[[yr]], where = where, limit = limit,
               token = token, max_results = limit)
}


# == Civic Engagement & Volunteering ===========================================

#' CEV national rates of civic engagement measures (2017-2023)
#'
#' National rates of formal volunteering, informal helping, charitable giving,
#' and other civic engagement measures from the Current Population Survey.
#'
#' @param limit Max rows (default 100)
#' @param token Optional Socrata app token
#' @return tibble: year, national_formal_volunteering,
#'   national_informal_helping, national_charitable_giving, ...
acorps_cev_national <- function(limit = 100, token = NULL) {
  ._soda_query("rhng-qtzw", limit = limit, token = token, max_results = limit)
}

#' CEV national rates by demographics (2017-2023)
#'
#' National civic engagement rates broken down by demographic groups.
#'
#' @param limit Max rows (default 1000)
#' @param token Optional Socrata app token
#' @return tibble with demographic breakdowns of civic engagement measures
acorps_cev_demographics <- function(limit = 1000, token = NULL) {
  ._soda_query("bhmf-84dy", limit = limit, token = token, max_results = limit)
}

#' CEV state-level rates (2017-2023)
#'
#' State-level rates of all civic engagement measures.
#'
#' @param state Two-letter state abbreviation (e.g. "AL", "CA")
#' @param limit Max rows (default 1000)
#' @param token Optional Socrata app token
#' @return tibble with state-level civic engagement data
acorps_cev_states <- function(state = NULL, limit = 1000, token = NULL) {
  where <- if (!is.null(state)) sprintf("state='%s'", state) else NULL
  ._soda_query("4r6x-re58", where = where, limit = limit,
               token = token, max_results = limit)
}


# == Demographics ==============================================================

#' AmeriCorps participant demographics data
#'
#' Odds-ratio analysis comparing AmeriCorps member/volunteer demographics
#' to U.S. Census population estimates.
#'
#' @param program Program name filter (e.g. "AmeriCorps State and National")
#' @param state State name filter
#' @param limit Max rows (default 1000)
#' @param token Optional Socrata app token
#' @return tibble: geographic_level, demographic_category, demographic_group,
#'   program, state, odds_ratio_estimate, representation, ...
acorps_demographics <- function(program = NULL, state = NULL, limit = 1000,
                                token = NULL) {
  parts <- character()
  if (!is.null(program)) parts <- c(parts, sprintf("program='%s'", program))
  if (!is.null(state))   parts <- c(parts, sprintf("state='%s'", state))
  where <- if (length(parts) > 0) paste(parts, collapse = " AND ") else NULL
  ._soda_query("i9xs-fvag", where = where, limit = limit,
               token = token, max_results = limit)
}


# == Research Grants ===========================================================

#' AmeriCorps research grantee dataset
#'
#' Grants to researchers at institutions of higher education for studies
#' on civic engagement, volunteering, and national service.
#'
#' @param state State name filter (e.g. "California")
#' @param year Grant year filter
#' @param limit Max rows (default 1000)
#' @param token Optional Socrata app token
#' @return tibble: year, grant_status, university, title, background,
#'   research_approach, city, state, ...
acorps_research_grants <- function(state = NULL, year = NULL, limit = 1000,
                                   token = NULL) {
  parts <- character()
  if (!is.null(state)) parts <- c(parts, sprintf("state='%s'", state))
  if (!is.null(year))  parts <- c(parts, sprintf("year='%s'", year))
  where <- if (length(parts) > 0) paste(parts, collapse = " AND ") else NULL
  ._soda_query("hznm-uizi", where = where, limit = limit,
               token = token, max_results = limit)
}


# == Employers of National Service =============================================

#' Employers of national service
#'
#' Organizations that connect AmeriCorps and Peace Corps alumni with employers.
#'
#' @param category Employer category filter (e.g. "Private Sector",
#'   "Institutions of Higher Education", "Nonprofit")
#' @param limit Max rows (default 1000)
#' @param token Optional Socrata app token
#' @return tibble: name_of_employer, employer_category, geocoded_column
acorps_employers <- function(category = NULL, limit = 1000, token = NULL) {
  where <- if (!is.null(category)) {
    sprintf("employer_category='%s'", category)
  } else NULL
  ._soda_query("c88b-pc22", where = where, limit = limit,
               token = token, max_results = limit)
}


# == Compliance ================================================================

#' Criminal history check recurring access data
#'
#' Types of checks required, prices, and processing times by state/territory.
#'
#' @param limit Max rows (default 100)
#' @param token Optional Socrata app token
#' @return tibble of criminal history check requirements by state
acorps_criminal_history_checks <- function(limit = 100, token = NULL) {
  ._soda_query("et85-j49w", limit = limit, token = token, max_results = limit)
}


# == Context ===================================================================

#' Return full source of all public functions in this file
#'
#' Reads its own source file and extracts all public function bodies
#' (with roxygen comments). Useful for LLM context injection.
#'
#' @return character string of all public function source code (printed and
#'   returned invisibly)
acorps_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/americorps.gov.R"
  if (!file.exists(src_file)) {
    cat("# americorps.gov context - source not found\n")
    return(invisible("# americorps.gov context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) -
        nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- paste(c(rox, body), collapse = "\n")
  }
  out <- paste(blocks, collapse = "\n\n")
  cat(out, "\n")
  invisible(out)
}
