# foia.gov.R - Self-contained foia.gov client

library(httr2)
library(jsonlite)
library(tibble)
library(dplyr)


# foia-gov.R
# Self-contained FOIA.gov API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: api_key (DEMO_KEY works for testing). Register at https://api.data.gov/signup/
# Rate limits: DEMO_KEY = 30/hr, registered = 1000/hr


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.foia_base <- "https://api.foia.gov/api"

`%||%` <- function(a, b) if (is.null(a)) b else a
# -- Fetch helpers -------------------------------------------------------------

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))

# == Schemas ===================================================================

.schema_agencies <- tibble(
  id = integer(), name = character(), abbreviation = character(),
  description = character()
)

.schema_requests <- tibble(
  agency = character(), year = integer(),
  received = integer(), processed = integer(),
  pending_start = integer(), pending_end = integer()
)

.schema_components <- tibble(
  id = integer(), agency_name = character(), title = character(),
  abbreviation = character(), website = character()
)

# == Agency components =========================================================


#' Fetch FOIA agency components
#'
#' Returns all federal agency components registered with FOIA.gov.
#'
#' @param api_key API key for api.data.gov. DEMO_KEY works for testing.
#'   Register free at https://api.data.gov/signup/
#' @return tibble: id, agency_name, title, abbreviation, website
foia_agencies <- function(api_key = NULL) {
  api_key <- api_key %||% "DEMO_KEY"
  url <- sprintf("%s/agency_components?api_key=%s", .foia_base, api_key)
  raw <- .fetch_json(url)
  d <- raw$data
  if (is.null(d) || length(d) == 0) return(.schema_components)

  if (is.data.frame(d) && "attributes" %in% names(d)) {
    attrs <- d$attributes
    tibble(
      id = as.integer(d$id),
      agency_name = NA_character_,
      title = as.character(attrs$title %||% NA_character_),
      abbreviation = as.character(attrs$abbreviation %||% NA_character_),
      website = as.character(attrs$website %||% NA_character_)
    )
  } else if (is.list(d) && !is.data.frame(d)) {
    rows <- lapply(d, function(x) {
      tibble(
        id = as.integer(x$id %||% NA),
        agency_name = as.character(x$attributes$title %||% NA),
        title = as.character(x$attributes$title %||% NA),
        abbreviation = as.character(x$attributes$abbreviation %||% NA),
        website = as.character(x$attributes$website %||% NA)
      )
    })
    bind_rows(rows)
  } else {
    .schema_components
  }
}

# == FOIA annual report data ===================================================

#' Fetch FOIA annual report request data
#'
#' Retrieves FOIA request statistics from annual reports for a specific
#' agency component.
#'
#' @param agency_abbreviation Agency abbreviation (e.g. "DOJ", "DHS", "EPA")
#' @param year Fiscal year (e.g. 2023)
#' @param api_key API key for api.data.gov. DEMO_KEY works for testing.
#' @return tibble: agency, year, received, processed, pending_start, pending_end
foia_requests <- function(agency_abbreviation, year = 2023, api_key = NULL) {
  api_key <- api_key %||% "DEMO_KEY"
  url <- sprintf(
    "%s/annual_foia_report/request/%s/%d?api_key=%s",
    .foia_base, agency_abbreviation, as.integer(year), api_key
  )
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_requests)

  # The response structure varies; try to extract top-level stats

  tibble(
    agency = as.character(agency_abbreviation),
    year = as.integer(year),
    received = as.integer(raw$request_received %||% NA),
    processed = as.integer(raw$request_processed %||% NA),
    pending_start = as.integer(raw$pending_start_of_year %||% NA),
    pending_end = as.integer(raw$pending_end_of_year %||% NA)
  )
}

# == Agency listing =============================================================

#' List all FOIA agencies (top-level, not components)
#'
#' @param api_key API key for api.data.gov. DEMO_KEY works for testing.
#' @return tibble: id, name, abbreviation, description
foia_agency_list <- function(api_key = NULL) {
  api_key <- api_key %||% "DEMO_KEY"
  url <- sprintf("%s/agency_components?api_key=%s", .foia_base, api_key)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$data)) return(.schema_agencies)
  d <- raw$data
  if (length(d) == 0) return(.schema_agencies)

  if (is.data.frame(d) && "relationships" %in% names(d)) {
    # JSON:API format - extract agency info from relationships
    rels <- d$relationships
    if (!is.null(rels$agency) && is.data.frame(rels$agency$data)) {
      agency_data <- rels$agency$data
      tibble(
        id = as.integer(agency_data$id),
        name = NA_character_,
        abbreviation = NA_character_,
        description = NA_character_
      ) |> distinct(id, .keep_all = TRUE)
    } else {
      # Fall back to component-level info
      attrs <- d$attributes
      tibble(
        id = as.integer(d$id),
        name = as.character(attrs$title %||% NA_character_),
        abbreviation = as.character(attrs$abbreviation %||% NA_character_),
        description = as.character(attrs$description %||% NA_character_)
      )
    }
  } else {
    .schema_agencies
  }
}

# == Context ===================================================================

#' Generate LLM-friendly context for foia.gov
#'
#' @return Character string with full function signatures and bodies
foia_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/foia.gov.R"
  if (!file.exists(src_file)) {
    cat("# foia.gov context - source not found\n")
    return(invisible("# foia.gov context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

