# data.cityofchicago.org.R - Self-contained data.cityofchicago.org client

library(httr2)
library(jsonlite)
library(tibble)
library(dplyr)


# data-cityofchicago-org.R
# Self-contained Chicago Open Data (Socrata SODA) client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required (app tokens optional for higher rate limits)
# Rate limits: 1000 requests/hour without app token


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.chi_base <- "https://data.cityofchicago.org"
# -- Fetch helpers -------------------------------------------------------------

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))

`%||%` <- function(a, b) if (is.null(a)) b else a

# == Schemas ===================================================================

.schema_datasets <- tibble(
  id = character(), name = character(), description = character(),
  category = character(), type = character(),
  updated_at = as.POSIXct(character()), view_count = integer()
)

.schema_query <- tibble()



# == Dataset discovery =========================================================

#' List available datasets on Chicago Open Data
#'
#' Returns a catalog of datasets available on data.cityofchicago.org.
#' Filter by category to narrow results.
#'
#' @param limit Number of datasets to return (default 50, max 200)
#' @param category Optional category filter (e.g. "Public Safety")
#' @return tibble: id, name, description, category, type, updated_at, view_count
chi_datasets <- function(limit = 50, category = NULL) {
  url <- sprintf("%s/api/views?limit=%d", .chi_base, limit)
  raw <- .fetch_json(url)
  if (is.null(raw) || length(raw) == 0) return(.schema_datasets)
  if (!is.data.frame(raw)) return(.schema_datasets)

  df <- as_tibble(raw)
  result <- df |>
    transmute(
      id          = as.character(id),
      name        = as.character(name),
      description = as.character(description %||% NA),
      category    = as.character(category %||% NA),
      type        = as.character(displayType %||% NA),
      updated_at  = as.POSIXct(as.numeric(viewLastModified %||% NA),
                                origin = "1970-01-01", tz = "UTC"),
      view_count  = as.integer(viewCount %||% NA)
    )

  if (!is.null(category)) {
    result <- result |> filter(grepl(!!category, .data$category, ignore.case = TRUE))
  }
  result
}


# == Query a dataset ===========================================================

#' Query a Socrata dataset on Chicago Open Data
#'
#' Runs a SoQL query against a specific dataset. Uses the SODA 2.0 API.
#'
#' @param dataset_id Socrata dataset identifier (e.g. "ijzp-q8t2")
#' @param where Optional SoQL WHERE clause (e.g. "primary_type='THEFT'")
#' @param select Optional SoQL SELECT clause (e.g. "date, primary_type")
#' @param order Optional SoQL ORDER BY clause (e.g. "date DESC")
#' @param limit Number of rows to return (default 1000, max 50000)
#' @param offset Offset for pagination (default 0)
#' @return tibble with columns from the dataset
chi_query <- function(dataset_id, where = NULL, select = NULL,
                      order = NULL, limit = 1000, offset = 0) {
  params <- list(`$limit` = limit, `$offset` = offset)
  if (!is.null(where))  params[["$where"]]  <- where
  if (!is.null(select)) params[["$select"]] <- select
  if (!is.null(order))  params[["$order"]]  <- order

  query_str <- paste(names(params), utils::URLencode(as.character(params), reserved = TRUE),
                     sep = "=", collapse = "&")
  url <- sprintf("%s/resource/%s.json?%s", .chi_base, dataset_id, query_str)
  raw <- .fetch_json(url)
  if (is.null(raw) || length(raw) == 0) return(tibble())
  as_tibble(raw)
}


# == Dataset metadata ==========================================================

#' Get metadata for a specific dataset on Chicago Open Data
#'
#' @param dataset_id Socrata dataset identifier (e.g. "ijzp-q8t2")
#' @return tibble: id, name, description, category, type, updated_at,
#'   row_count, column_count, download_count
chi_metadata <- function(dataset_id) {
  schema <- tibble(id = character(), name = character(), description = character(),
                   category = character(), type = character(),
                   updated_at = as.POSIXct(character()),
                   row_count = integer(), column_count = integer(),
                   download_count = integer())
  url <- sprintf("%s/api/views/%s.json", .chi_base, dataset_id)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$id)) return(schema)

  tibble(
    id = as.character(raw$id %||% NA_character_),
    name = as.character(raw$name %||% NA_character_),
    description = as.character(raw$description %||% NA_character_),
    category = as.character(raw$category %||% NA_character_),
    type = as.character(raw$displayType %||% NA_character_),
    updated_at = as.POSIXct(as.numeric(raw$viewLastModified %||% NA),
                            origin = "1970-01-01", tz = "UTC"),
    row_count = as.integer(raw$rowCount %||% NA_integer_),
    column_count = as.integer(length(raw$columns %||% list())),
    download_count = as.integer(raw$downloadCount %||% NA_integer_)
  )
}

#' Get row count for a dataset query using SoQL
#'
#' @param dataset_id Socrata dataset identifier
#' @param where Optional SoQL WHERE clause to filter
#' @return integer: total number of matching rows
chi_count <- function(dataset_id, where = NULL) {
  params <- list(`$select` = "count(*)")
  if (!is.null(where)) params[["$where"]] <- where
  query_str <- paste(names(params), utils::URLencode(as.character(params), reserved = TRUE),
                     sep = "=", collapse = "&")
  url <- sprintf("%s/resource/%s.json?%s", .chi_base, dataset_id, query_str)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || length(raw) == 0) return(NA_integer_)
  as.integer(raw[[1]][[1]])
}

# == Context ===================================================================

#' Generate LLM-friendly context for data.cityofchicago.org
#'
#' @return Character string with full function signatures and bodies
cityofchicago_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/data.cityofchicago.org.R"
  if (!file.exists(src_file)) {
    cat("# data.cityofchicago.org context - source not found\n")
    return(invisible("# data.cityofchicago.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

