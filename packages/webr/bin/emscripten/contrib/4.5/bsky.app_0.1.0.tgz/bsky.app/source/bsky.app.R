# bsky.app.R - Self-contained bsky.app client

library(httr2)
library(jsonlite)
library(tibble)


# bsky.R
# Self-contained Bluesky (AT Protocol) public API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required for public endpoints
# Rate limits: generous for public API


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.bsky_base <- "https://api.bsky.app/xrpc"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = TRUE)

# == Schemas ===================================================================

.schema_posts <- tibble(
  uri = character(), cid = character(), author_handle = character(),
  author_name = character(), text = character(),
  created_at = as.POSIXct(character()), reply_count = integer(),
  repost_count = integer(), like_count = integer()
)

.schema_users <- tibble(
  did = character(), handle = character(), display_name = character(),
  description = character(), followers_count = integer(),
  follows_count = integer(), posts_count = integer(),
  created_at = as.POSIXct(character())
)

.schema_profile <- tibble(
  did = character(), handle = character(), display_name = character(),
  description = character(), followers_count = integer(),
  follows_count = integer(), posts_count = integer(),
  created_at = as.POSIXct(character())
)

`%||%` <- function(x, y) if (is.null(x)) y else x

# == Public functions ==========================================================

#' Search Bluesky posts
#'
#' @param query Search query
#' @param limit Max results (default 25, max 100)
#' @param sort Sort order: "top" or "latest" (default "top")
#' @return tibble: uri, cid, author_handle, author_name, text,
#'   created_at, reply_count, repost_count, like_count
bsky_search_posts <- function(query, limit = 25, sort = "top") {
  url <- sprintf(
    "%s/app.bsky.feed.searchPosts?q=%s&limit=%d&sort=%s",
    .bsky_base, utils::URLencode(query, reserved = TRUE),
    as.integer(limit), sort
  )
  raw <- .fetch_json(url)
  posts <- raw$posts
  if (is.null(posts) || length(posts) == 0 ||
      (is.data.frame(posts) && nrow(posts) == 0)) return(.schema_posts)

  tibble(
    uri = as.character(posts$uri),
    cid = as.character(posts$cid),
    author_handle = as.character(posts$author$handle),
    author_name = as.character(posts$author$displayName %||% NA_character_),
    text = as.character(posts$record$text %||% NA_character_),
    created_at = as.POSIXct(posts$record$createdAt, format = "%Y-%m-%dT%H:%M:%OS", tz = "UTC"),
    reply_count = as.integer(posts$replyCount %||% NA_integer_),
    repost_count = as.integer(posts$repostCount %||% NA_integer_),
    like_count = as.integer(posts$likeCount %||% NA_integer_)
  )
}

#' Search Bluesky users
#'
#' @param query Search query
#' @param limit Max results (default 25, max 100)
#' @return tibble: did, handle, display_name, description, followers_count,
#'   follows_count, posts_count, created_at
bsky_search_users <- function(query, limit = 25) {
  url <- sprintf(
    "%s/app.bsky.actor.searchActors?q=%s&limit=%d",
    .bsky_base, utils::URLencode(query, reserved = TRUE), as.integer(limit)
  )
  raw <- .fetch_json(url)
  actors <- raw$actors
  if (is.null(actors) || length(actors) == 0 ||
      (is.data.frame(actors) && nrow(actors) == 0)) return(.schema_users)

  tibble(
    did = as.character(actors$did),
    handle = as.character(actors$handle),
    display_name = as.character(actors$displayName %||% NA_character_),
    description = as.character(substr(actors$description %||% NA_character_, 1, 200)),
    followers_count = as.integer(actors$followersCount %||% NA_integer_),
    follows_count = as.integer(actors$followsCount %||% NA_integer_),
    posts_count = as.integer(actors$postsCount %||% NA_integer_),
    created_at = as.POSIXct(actors$createdAt %||% NA_character_, format = "%Y-%m-%dT%H:%M:%OS", tz = "UTC")
  )
}

#' Get a Bluesky user profile
#'
#' @param handle User handle (e.g. "jay.bsky.team") or DID
#' @return tibble: one row with did, handle, display_name, description,
#'   followers_count, follows_count, posts_count, created_at
bsky_profile <- function(handle) {
  url <- sprintf(
    "%s/app.bsky.actor.getProfile?actor=%s",
    .bsky_base, utils::URLencode(handle, reserved = TRUE)
  )
  raw <- .fetch_json(url)
  if (length(raw) == 0) return(.schema_profile)

  tibble(
    did = as.character(raw$did),
    handle = as.character(raw$handle),
    display_name = as.character(raw$displayName %||% NA_character_),
    description = as.character(raw$description %||% NA_character_),
    followers_count = as.integer(raw$followersCount %||% NA_integer_),
    follows_count = as.integer(raw$followsCount %||% NA_integer_),
    posts_count = as.integer(raw$postsCount %||% NA_integer_),
    created_at = as.POSIXct(raw$createdAt %||% NA_character_, format = "%Y-%m-%dT%H:%M:%OS", tz = "UTC")
  )
}

# == Context ===================================================================

#' Generate LLM-friendly context for bsky.app
#'
#' @return Character string with full function signatures and bodies
bsky_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/bsky.app.R"
  if (!file.exists(src_file)) {
    cat("# bsky.app context - source not found\n")
    return(invisible("# bsky.app context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

