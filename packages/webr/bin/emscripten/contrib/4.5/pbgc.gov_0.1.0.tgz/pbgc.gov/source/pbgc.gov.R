# pbgc.gov.R - Self-contained PBGC (Pension Benefit Guaranty Corporation) client
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble, readxl
# Auth: none required

library(httr2)
library(jsonlite)
library(tibble)
library(dplyr)
library(readxl)

`%||%` <- function(a, b) if (is.null(a)) b else a

# == Private utilities =========================================================

.ua <- "support@scrapeable.com"

.pbgc_base <- "https://www.pbgc.gov"

.fetch_excel <- function(url, ext = ".xlsx") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

# == Schemas ===================================================================

.schema_trusteed <- tibble(
  case_number = character(), sponsor_name = character(), plan_name = character(),
  ein = character(), plan_number = numeric(), city = character(), state = character(),
  termination_date = as.Date(character()), trusteeship_date = as.Date(character()),
  participants = numeric()
)

.schema_multiemployer <- tibble(
  plan_name = character(), admin_city = character(), admin_state = character(),
  sponsor_name = character(), phone = character(), effective_date = character(),
  plan_id = character(), ein = character(), pn = character(),
  participant_count = numeric()
)

# == Public functions ==========================================================

#' List PBGC datasets
#'
#' @return tibble: id, name, description, url, format
pbgc_list <- function() {
  tibble(
    id = c("trusteed_plans", "multiemployer_plans"),
    name = c("Single-Employer Plans Trusteed by PBGC",
             "Multiemployer Pension Plans"),
    description = c(
      "All single-employer defined benefit pension plans trusteed by PBGC since 1974",
      "Active multiemployer pension plans insured by PBGC"
    ),
    url = c(
      paste0(.pbgc_base, "/sites/default/files/trusteedplans.xlsx"),
      paste0(.pbgc_base, "/sites/default/files/legacy/docs/open/multiemployerlist.xlsx")
    ),
    format = c("xlsx", "xlsx")
  )
}

#' Fetch PBGC trusteed single-employer plans
#'
#' @param state Optional state abbreviation to filter (e.g. "PA", "NY")
#' @return tibble: case_number, sponsor_name, plan_name, ein, plan_number,
#'   city, state, termination_date, trusteeship_date, participants
pbgc_trusteed_plans <- function(state = NULL) {
  url <- paste0(.pbgc_base, "/sites/default/files/trusteedplans.xlsx")
  f <- .fetch_excel(url)
  raw <- tryCatch(readxl::read_excel(f), error = function(e) return(.schema_trusteed))
  if (nrow(raw) == 0) return(.schema_trusteed)

  out <- tibble(
    case_number = as.character(raw[[1]]),
    sponsor_name = as.character(raw[[2]]),
    plan_name = as.character(raw[[3]]),
    ein = as.character(raw[[4]]),
    plan_number = suppressWarnings(as.numeric(raw[[5]])),
    city = as.character(raw[[6]]),
    state = as.character(raw[[7]]),
    termination_date = suppressWarnings(as.Date(raw[[8]])),
    trusteeship_date = suppressWarnings(as.Date(raw[[9]])),
    participants = suppressWarnings(as.numeric(raw[[10]]))
  )

  if (!is.null(state)) {
    out <- out |> filter(.data$state == !!state)
  }
  out
}

#' Fetch PBGC multiemployer pension plans
#'
#' @param state Optional state abbreviation to filter
#' @return tibble: plan_name, admin_city, admin_state, sponsor_name, phone,
#'   effective_date, plan_id, ein, pn, participant_count
pbgc_multiemployer_plans <- function(state = NULL) {
  url <- paste0(.pbgc_base, "/sites/default/files/legacy/docs/open/multiemployerlist.xlsx")
  f <- .fetch_excel(url)
  raw <- tryCatch(readxl::read_excel(f), error = function(e) return(.schema_multiemployer))
  if (nrow(raw) == 0) return(.schema_multiemployer)

  out <- tibble(
    plan_name = as.character(raw[[1]]),
    admin_city = as.character(raw[[2]]),
    admin_state = as.character(raw[[3]]),
    sponsor_name = as.character(raw[[4]]),
    phone = as.character(raw[[5]]),
    effective_date = as.character(raw[[6]]),
    plan_id = as.character(raw[[7]]),
    ein = as.character(raw[[8]]),
    pn = as.character(raw[[9]]),
    participant_count = suppressWarnings(as.numeric(raw[[10]]))
  )

  if (!is.null(state)) {
    out <- out |> filter(.data$admin_state == !!state)
  }
  out
}

#' Search PBGC trusteed plans by sponsor or plan name
#'
#' @param query Search string (case-insensitive, partial match)
#' @return tibble: same columns as pbgc_trusteed_plans()
pbgc_search <- function(query) {
  plans <- pbgc_trusteed_plans()
  pattern <- tolower(query)
  plans |> filter(
    grepl(pattern, tolower(sponsor_name)) |
    grepl(pattern, tolower(plan_name))
  )
}

#' Return context: full source of this client
#'
#' @return character: source code of this file
pbgc_context <- function() {
  f <- system.file("source", "pbgc.gov.R", package = "pbgc.gov")
  if (f == "") {
    f <- tryCatch(
      { env <- sys.frame(0); getSrcFilename(env, full.names = TRUE) },
      error = function(e) ""
    )
  }
  if (f == "" || !file.exists(f)) return("Source not available")
  paste(readLines(f, warn = FALSE), collapse = "\n")
}
