# nominatim.org.R - Self-contained nominatim.org client

library(httr2)
library(jsonlite)
library(tibble)


# nominatim-org.R
# Self-contained Nominatim geocoding client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required (User-Agent required per TOS)
# API: https://nominatim.openstreetmap.org


.ua <- "scrapeable.com (support@scrapeable.com)"
.nom_base <- "https://nominatim.openstreetmap.org"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |> httr2::req_headers(`User-Agent` = .ua) |> httr2::req_perform(path = tmp)
  tmp
}
.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = TRUE)
`%||%` <- function(a, b) if (is.null(a) || length(a) == 0) b else a

.schema_geocode <- tibble(
  place_id = integer(), osm_id = character(), display_name = character(),
  latitude = numeric(), longitude = numeric(), type = character(),
  importance = numeric()
)


#' Forward geocode — search for places by name
#'
#' @param query Place name (e.g. "New York", "Eiffel Tower")
#' @param limit Max results (default 5, max 50)
#' @param countrycodes Limit to countries (e.g. "us,ca")
#' @return tibble: place_id, osm_id, display_name, latitude, longitude, type, importance
nom_search <- function(query, limit = 5, countrycodes = NULL) {
  url <- sprintf("%s/search?q=%s&format=json&limit=%d",
                 .nom_base, utils::URLencode(query, reserved = TRUE), limit)
  if (!is.null(countrycodes)) url <- paste0(url, "&countrycodes=", countrycodes)
  raw <- tryCatch(.fetch_json(url), error = function(e) { warning("Nominatim error: ", e$message); NULL })
  if (is.null(raw) || nrow(raw) == 0) return(.schema_geocode)
  tibble(place_id = as.integer(raw$place_id), osm_id = as.character(raw$osm_id),
         display_name = as.character(raw$display_name),
         latitude = as.numeric(raw$lat), longitude = as.numeric(raw$lon),
         type = as.character(raw$type), importance = as.numeric(raw$importance))
}

#' Reverse geocode — coordinates to address
#'
#' @param latitude Latitude
#' @param longitude Longitude
#' @return tibble: one row with place_id, osm_id, display_name, latitude, longitude, type, importance
nom_reverse <- function(latitude, longitude) {
  url <- sprintf("%s/reverse?lat=%s&lon=%s&format=json", .nom_base, latitude, longitude)
  raw <- tryCatch(.fetch_json(url), error = function(e) { warning("Nominatim error: ", e$message); NULL })
  if (is.null(raw)) return(.schema_geocode)
  tibble(place_id = as.integer(raw$place_id), osm_id = as.character(raw$osm_id),
         display_name = as.character(raw$display_name),
         latitude = as.numeric(raw$lat), longitude = as.numeric(raw$lon),
         type = as.character(raw$type %||% NA_character_), importance = as.numeric(raw$importance %||% NA_real_))
}

#' Generate context
#' @return Character string (invisibly)
nom_context <- function() {
  .build_context("nominatim.org", header_lines = c(
    "# nominatim.org - OpenStreetMap Geocoding Client for R",
    "# Auth: none (User-Agent required per TOS)",
    "# Forward + reverse geocoding. Rate limit: 1 req/sec."
  ))
}

# == Context ===================================================================

#' Generate LLM-friendly context for nominatim.org
#'
#' @return Character string with full function signatures and bodies
nominatim_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/nominatim.org.R"
  if (!file.exists(src_file)) {
    cat("# nominatim.org context - source not found\n")
    return(invisible("# nominatim.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

