# riksbank.se.R - Self-contained riksbank.se client

library(httr2)
library(jsonlite)
library(tibble)
library(dplyr)


# riksbank-se.R
# Self-contained Riksbank (Swedish central bank) SWEA API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required
# Rate limits: unknown, be courteous


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.riksbank_base <- "https://api.riksbank.se/swea/v1"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua, Accept = "application/json") |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))

# == Schemas ===================================================================

.schema_observations <- tibble(
  date = as.Date(character()), value = numeric(), series = character()
)

.schema_series <- tibble(
  seriesid = character(), name = character(), description = character()
)


# == Observations ==============================================================

#' Fetch observations for a Riksbank SWEA series
#'
#' @param series Series ID (e.g. "SEKUSDPMI", "SEKEURPMI", "SECBREPOEFF")
#' @param from Start date ("YYYY-MM-DD")
#' @param to End date ("YYYY-MM-DD")
#' @return tibble: date (Date), value (numeric), series (character)
riksbank_observations <- function(series, from = "2024-01-01",
                                  to = format(Sys.Date(), "%Y-%m-%d")) {
  url <- sprintf("%s/Observations/%s/%s/%s", .riksbank_base, series, from, to)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || length(raw) == 0) return(.schema_observations)
  # API returns a list of objects with date and value
  if (is.data.frame(raw)) {
    df <- as_tibble(raw)
  } else {
    df <- bind_rows(lapply(raw, as_tibble))
  }
  date_col <- intersect(c("date", "Date", "period"), names(df))
  value_col <- intersect(c("value", "Value", "average"), names(df))
  if (length(date_col) == 0 || length(value_col) == 0) return(.schema_observations)
  tibble(
    date = as.Date(df[[date_col[1]]]),
    value = suppressWarnings(as.numeric(df[[value_col[1]]])),
    series = series
  )
}

# == Series listing ============================================================

#' List all available Riksbank SWEA series
#'
#' @return tibble: seriesid (character), name (character), description (character)
riksbank_series <- function() {
  url <- sprintf("%s/Series", .riksbank_base)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || length(raw) == 0) return(.schema_series)
  if (is.data.frame(raw)) {
    df <- as_tibble(raw)
  } else {
    df <- bind_rows(lapply(raw, as_tibble))
  }
  # Normalize column names
  names(df) <- tolower(names(df))
  id_col <- intersect(c("seriesid", "id", "series_id", "key"), names(df))
  name_col <- intersect(c("name", "seriesname", "title", "longnameen"), names(df))
  desc_col <- intersect(c("description", "descriptionen", "source"), names(df))
  tibble(
    seriesid = if (length(id_col) > 0) as.character(df[[id_col[1]]]) else NA_character_,
    name = if (length(name_col) > 0) as.character(df[[name_col[1]]]) else NA_character_,
    description = if (length(desc_col) > 0) as.character(df[[desc_col[1]]]) else NA_character_
  )
}
`%||%` <- function(x, y) if (is.null(x)) y else x

# == Context ===================================================================

#' Generate LLM-friendly context for riksbank.se
#'
#' @return Character string with full function signatures and bodies
riksbank_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/riksbank.se.R"
  if (!file.exists(src_file)) {
    cat("# riksbank.se context - source not found\n")
    return(invisible("# riksbank.se context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

