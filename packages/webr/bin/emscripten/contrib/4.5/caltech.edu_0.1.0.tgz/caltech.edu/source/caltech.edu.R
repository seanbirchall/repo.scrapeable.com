# exoplanetarchive.ipac.caltech.edu.R - Self-contained exoplanetarchive.ipac.caltech.edu client

library(httr2)
library(jsonlite)
library(tibble)
library(dplyr)


.ua <- "support@scrapeable.com"

.fetch_json <- function(url) {
  tmp <- tempfile(fileext = ".json")
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  jsonlite::fromJSON(tmp, simplifyVector = FALSE)
}

`%||%` <- function(a, b) if (is.null(a)) b else a

.exo_base <- "https://exoplanetarchive.ipac.caltech.edu/TAP/sync"

.exo_query <- function(query) {
  url <- sprintf("%s?query=%s&format=json", .exo_base, utils::URLencode(query, reserved = TRUE))
  tryCatch(.fetch_json(url), error = function(e) list())
}

# == Schemas ===================================================================

.schema_planets <- tibble(
  pl_name = character(), hostname = character(), disc_year = integer(),
  mass_earth = numeric(), radius_earth = numeric(),
  orbital_period = numeric(), distance_pc = numeric()
)

#' Query confirmed exoplanets
#'
#' @param where SQL WHERE clause (optional, e.g. "disc_year>2020")
#' @param top Number of results (default 50)
#' @return tibble: pl_name, hostname, disc_year, mass_earth, radius_earth,
#'   orbital_period, distance_pc
exo_planets <- function(where = NULL, top = 50L) {
  q <- sprintf("SELECT TOP %d pl_name,hostname,disc_year,pl_bmasse,pl_rade,pl_orbper,sy_dist FROM ps WHERE default_flag=1", as.integer(top))
  if (!is.null(where)) q <- paste(q, "AND", where)
  raw <- .exo_query(q)
  if (length(raw) == 0) return(.schema_planets)
  tibble(
    pl_name = vapply(raw, function(x) x$pl_name %||% NA_character_, character(1)),
    hostname = vapply(raw, function(x) x$hostname %||% NA_character_, character(1)),
    disc_year = vapply(raw, function(x) as.integer(x$disc_year %||% NA_integer_), integer(1)),
    mass_earth = vapply(raw, function(x) as.numeric(x$pl_bmasse %||% NA_real_), numeric(1)),
    radius_earth = vapply(raw, function(x) as.numeric(x$pl_rade %||% NA_real_), numeric(1)),
    orbital_period = vapply(raw, function(x) as.numeric(x$pl_orbper %||% NA_real_), numeric(1)),
    distance_pc = vapply(raw, function(x) as.numeric(x$sy_dist %||% NA_real_), numeric(1))
  )
}

#' Get host star properties for exoplanet systems
#'
#' @param where SQL WHERE clause (optional, e.g. "st_spectype LIKE 'G%'")
#' @param top Number of results (default 50)
#' @return tibble: hostname, st_spectype, st_teff, st_rad, st_mass, st_met, sy_dist
exo_stars <- function(where = NULL, top = 50L) {
  schema <- tibble(hostname = character(), st_spectype = character(),
                   st_teff = numeric(), st_rad = numeric(), st_mass = numeric(),
                   st_met = numeric(), sy_dist = numeric())
  q <- sprintf("SELECT DISTINCT TOP %d hostname,st_spectype,st_teff,st_rad,st_mass,st_met,sy_dist FROM ps WHERE default_flag=1", as.integer(top))
  if (!is.null(where)) q <- paste(q, "AND", where)
  raw <- .exo_query(q)
  if (length(raw) == 0) return(schema)
  tibble(
    hostname = vapply(raw, function(x) x$hostname %||% NA_character_, character(1)),
    st_spectype = vapply(raw, function(x) x$st_spectype %||% NA_character_, character(1)),
    st_teff = vapply(raw, function(x) as.numeric(x$st_teff %||% NA_real_), numeric(1)),
    st_rad = vapply(raw, function(x) as.numeric(x$st_rad %||% NA_real_), numeric(1)),
    st_mass = vapply(raw, function(x) as.numeric(x$st_mass %||% NA_real_), numeric(1)),
    st_met = vapply(raw, function(x) as.numeric(x$st_met %||% NA_real_), numeric(1)),
    sy_dist = vapply(raw, function(x) as.numeric(x$sy_dist %||% NA_real_), numeric(1))
  )
}

#' Find potentially habitable exoplanets
#'
#' Returns Earth-like planets: radius 0.5-2 Earth radii, orbital period
#' allowing temperate conditions, around Sun-like stars.
#'
#' @param top Number of results (default 50)
#' @return tibble: pl_name, hostname, disc_year, mass_earth, radius_earth,
#'   orbital_period, st_teff, distance_pc
exo_habitable <- function(top = 50L) {
  schema <- tibble(pl_name = character(), hostname = character(),
                   disc_year = integer(), mass_earth = numeric(),
                   radius_earth = numeric(), orbital_period = numeric(),
                   st_teff = numeric(), distance_pc = numeric())
  q <- sprintf(
    "SELECT TOP %d pl_name,hostname,disc_year,pl_bmasse,pl_rade,pl_orbper,st_teff,sy_dist FROM ps WHERE default_flag=1 AND pl_rade>=0.5 AND pl_rade<=2.0 AND pl_orbper>10 ORDER BY pl_rade ASC",
    as.integer(top)
  )
  raw <- .exo_query(q)
  if (length(raw) == 0) return(schema)
  tibble(
    pl_name = vapply(raw, function(x) x$pl_name %||% NA_character_, character(1)),
    hostname = vapply(raw, function(x) x$hostname %||% NA_character_, character(1)),
    disc_year = vapply(raw, function(x) as.integer(x$disc_year %||% NA_integer_), integer(1)),
    mass_earth = vapply(raw, function(x) as.numeric(x$pl_bmasse %||% NA_real_), numeric(1)),
    radius_earth = vapply(raw, function(x) as.numeric(x$pl_rade %||% NA_real_), numeric(1)),
    orbital_period = vapply(raw, function(x) as.numeric(x$pl_orbper %||% NA_real_), numeric(1)),
    st_teff = vapply(raw, function(x) as.numeric(x$st_teff %||% NA_real_), numeric(1)),
    distance_pc = vapply(raw, function(x) as.numeric(x$sy_dist %||% NA_real_), numeric(1))
  )
}

#' Get discovery statistics by year and method
#'
#' @param top Number of years to return (default 30)
#' @return tibble: disc_year, discoverymethod, count
exo_discoveries <- function(top = 30L) {
  schema <- tibble(disc_year = integer(), discoverymethod = character(), count = integer())
  q <- sprintf(
    "SELECT TOP %d disc_year,discoverymethod,count(*) as cnt FROM ps WHERE default_flag=1 GROUP BY disc_year,discoverymethod ORDER BY disc_year DESC",
    as.integer(top)
  )
  raw <- .exo_query(q)
  if (length(raw) == 0) return(schema)
  tibble(
    disc_year = vapply(raw, function(x) as.integer(x$disc_year %||% NA_integer_), integer(1)),
    discoverymethod = vapply(raw, function(x) x$discoverymethod %||% NA_character_, character(1)),
    count = vapply(raw, function(x) as.integer(x$cnt %||% NA_integer_), integer(1))
  )
}

# == Context ===================================================================

#' Generate LLM-friendly context for exoplanetarchive.ipac.caltech.edu
#'
#' @return Character string with full function signatures and bodies
exoplanetarchive_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/exoplanetarchive.ipac.caltech.edu.R"
  if (!file.exists(src_file)) {
    cat("# exoplanetarchive.ipac.caltech.edu context - source not found\n")
    return(invisible("# exoplanetarchive.ipac.caltech.edu context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

