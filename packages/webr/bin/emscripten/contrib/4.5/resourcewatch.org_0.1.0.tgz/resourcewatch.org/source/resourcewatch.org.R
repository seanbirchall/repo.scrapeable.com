# resourcewatch.org.R - Self-contained resourcewatch.org client

library(httr2)
library(jsonlite)
library(tibble)


# resourcewatch.R
# Self-contained Resource Watch API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required
# Rate limits: not documented, be respectful


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.rw_base <- "https://api.resourcewatch.org/v1"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))

# == Schemas ===================================================================

.schema_datasets <- tibble(
  id = character(), name = character(), subtitle = character(),
  provider = character(), connectorType = character(),
  published = logical(), env = character()
)

.schema_dataset_detail <- tibble(
  id = character(), name = character(), subtitle = character(),
  description = character(), provider = character(),
  connectorType = character(), tableName = character(),
  published = logical()
)

# == Dataset listing ===========================================================

#' List Resource Watch datasets
#'
#' @param page_size Number of results (default 10)
#' @param page Page number (default 1)
#' @return tibble: id, name, subtitle, provider, connectorType, published, env
rw_datasets <- function(page_size = 10, page = 1) {
  url <- paste0(.rw_base, "/dataset?page[size]=", page_size, "&page[number]=", page)
  raw <- .fetch_json(url)
  d <- raw$data
  if (is.null(d) || length(d) == 0) return(.schema_datasets)

  attrs <- d$attributes
  if (is.null(attrs)) return(.schema_datasets)

  tibble(
    id = as.character(d$id),
    name = as.character(attrs$name %||% NA_character_),
    subtitle = as.character(if ("subtitle" %in% names(attrs)) attrs$subtitle else NA_character_),
    provider = as.character(if ("provider" %in% names(attrs)) attrs$provider else NA_character_),
    connectorType = as.character(if ("connectorType" %in% names(attrs)) attrs$connectorType else NA_character_),
    published = as.logical(if ("published" %in% names(attrs)) attrs$published else NA),
    env = as.character(if ("env" %in% names(attrs)) attrs$env else NA_character_)
  )
}

# == Dataset detail ============================================================

#' Fetch a single Resource Watch dataset by ID
#'
#' @param id Dataset ID string
#' @return tibble: one row with id, name, subtitle, description, provider,
#'   connectorType, tableName, published
rw_dataset <- function(id) {
  url <- paste0(.rw_base, "/dataset/", id)
  raw <- .fetch_json(url)
  d <- raw$data
  if (is.null(d) || is.null(d$id)) return(.schema_dataset_detail)
  a <- d$attributes

  tibble(
    id = as.character(d$id),
    name = as.character(a$name %||% NA_character_),
    subtitle = as.character(a$subtitle %||% NA_character_),
    description = as.character(a$description %||% NA_character_),
    provider = as.character(a$provider %||% NA_character_),
    connectorType = as.character(a$connectorType %||% NA_character_),
    tableName = as.character(a$tableName %||% NA_character_),
    published = as.logical(a$published %||% NA)
  )
}

# == Context ===================================================================

#' Generate LLM-friendly context for resourcewatch.org
#'
#' @return Character string with full function signatures and bodies
rw_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/resourcewatch.org.R"
  if (!file.exists(src_file)) {
    cat("# resourcewatch.org context - source not found\n")
    return(invisible("# resourcewatch.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

