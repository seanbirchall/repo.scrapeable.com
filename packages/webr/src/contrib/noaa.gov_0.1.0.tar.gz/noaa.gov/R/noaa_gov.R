# noaa.gov.R
# Self-contained NOAA client.
# Covers: Tides & Currents, Global Monitoring Lab (CO2/CH4), and Space Weather.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required



# == Private utilities =========================================================

`%||%` <- function(a, b) if (is.null(a)) b else a
.ua <- "support@scrapeable.com"
.base <- "https://api.tidesandcurrents.noaa.gov/api/prod/datagetter"
.gml_base <- "https://gml.noaa.gov/webdata/ccgg/trends"
.swpc_base <- "https://services.swpc.noaa.gov/products"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))
.fetch_json_nested <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE)


# == Schemas ===================================================================

.schema_trend <- tibble(
  date = as.Date(character()), smoothed = numeric(), trend = numeric()
)

.schema_annual <- tibble(
  year = integer(), mean = numeric(), unc = numeric()
)

.schema_monthly <- tibble(
  year = integer(), month = integer(), decimal = numeric(),
  average = numeric(), average_unc = numeric(),
  trend = numeric(), trend_unc = numeric()
)

.schema_plasma <- tibble(
  time_tag = as.POSIXct(character()), density = numeric(),
  speed = numeric(), temperature = numeric()
)

.schema_mag <- tibble(
  time_tag = as.POSIXct(character()), bx_gsm = numeric(),
  by_gsm = numeric(), bz_gsm = numeric(),
  lon_gsm = numeric(), lat_gsm = numeric(), bt = numeric()
)

.schema_kp <- tibble(
  time_tag = as.POSIXct(character()), kp = numeric(),
  a_running = numeric(), station_count = integer()
)

.schema_alerts <- tibble(
  product_id = character(), issue_datetime = as.POSIXct(character()),
  message = character()
)



#' Get tide predictions for a station
#' @param station Station ID (e.g. '9414290' for San Francisco)
#' @param begin_date Start date YYYYMMDD
#' @param end_date End date YYYYMMDD
#' @return tibble of tide predictions
tides_predictions <- function(station, begin_date = format(Sys.Date(), "%Y%m%d"),
                              end_date = format(Sys.Date() + 1, "%Y%m%d")) {
  url <- sprintf("%s?station=%s&begin_date=%s&end_date=%s&product=predictions&datum=MLLW&units=metric&time_zone=gmt&application=scrapeable&format=json",
                 .base, station, begin_date, end_date)
  raw <- .fetch_json(url)
  preds <- raw$predictions
  if (length(preds) == 0) return(tibble::tibble(time = character(), value = numeric()))
  tibble::tibble(
    time = vapply(preds, function(x) x$t %||% NA_character_, character(1)),
    value = vapply(preds, function(x) as.numeric(x$v %||% NA), numeric(1))
  )
}


#' Get water levels for a station
#' @param station Station ID
#' @param begin_date Start date YYYYMMDD
#' @param end_date End date YYYYMMDD
#' @return tibble of water levels
tides_water_levels <- function(station, begin_date = format(Sys.Date() - 1, "%Y%m%d"),
                               end_date = format(Sys.Date(), "%Y%m%d")) {
  url <- sprintf("%s?station=%s&begin_date=%s&end_date=%s&product=water_level&datum=MLLW&units=metric&time_zone=gmt&application=scrapeable&format=json",
                 .base, station, begin_date, end_date)
  raw <- .fetch_json(url)
  data <- raw$data
  if (length(data) == 0) return(tibble::tibble(time = character(), value = numeric()))
  tibble::tibble(
    time = vapply(data, function(x) x$t %||% NA_character_, character(1)),
    value = vapply(data, function(x) as.numeric(x$v %||% NA), numeric(1)),
    quality = vapply(data, function(x) x$q %||% NA_character_, character(1))
  )
}


#' List NOAA tide stations
#' @return tibble of stations
tides_stations <- function() {
  url <- "https://api.tidesandcurrents.noaa.gov/mdapi/prod/webapi/stations.json"
  raw <- .fetch_json(url)
  stns <- raw$stations
  if (length(stns) == 0) return(tibble::tibble(id = character(), name = character()))
  tibble::tibble(
    id = vapply(stns, function(x) x$id %||% NA_character_, character(1)),
    name = vapply(stns, function(x) x$name %||% NA_character_, character(1)),
    state = vapply(stns, function(x) x$state %||% NA_character_, character(1)),
    latitude = vapply(stns, function(x) as.numeric(x$lat %||% NA), numeric(1)),
    longitude = vapply(stns, function(x) as.numeric(x$lng %||% NA), numeric(1))
  )
}



#' Fetch daily global CO2 trend data
#'
#' Smoothed and trend values from NOAA GML. Updated daily.
#'
#' @return tibble: date (Date), smoothed (numeric ppm), trend (numeric ppm)
co2_global_trend <- function() {
  f <- .fetch_csv(paste0(.gml_base, "/co2/co2_trend_gl.csv"))
  raw <- read.csv(f, comment.char = "#", stringsAsFactors = FALSE)
  if (nrow(raw) == 0) return(.schema_trend)
  raw |>
    as_tibble() |>
    transmute(
      date     = as.Date(sprintf("%04d-%02d-%02d", as.integer(year), as.integer(month), as.integer(day))),
      smoothed = as.numeric(smoothed),
      trend    = as.numeric(trend)
    )
}


#' Fetch annual global mean CO2
#'
#' @return tibble: year (integer), mean (numeric ppm), unc (numeric)
co2_annual <- function() {
  f <- .fetch_csv(paste0(.gml_base, "/co2/co2_annmean_gl.csv"))
  raw <- read.csv(f, comment.char = "#", stringsAsFactors = FALSE)
  if (nrow(raw) == 0) return(.schema_annual)
  raw |>
    as_tibble() |>
    transmute(
      year = as.integer(year),
      mean = as.numeric(mean),
      unc  = as.numeric(unc)
    )
}


#' Fetch monthly global CO2 data
#'
#' @return tibble: year, month, decimal, average, average_unc, trend, trend_unc
co2_monthly <- function() {
  f <- .fetch_csv(paste0(.gml_base, "/co2/co2_mm_gl.csv"))
  raw <- read.csv(f, comment.char = "#", stringsAsFactors = FALSE)
  if (nrow(raw) == 0) return(.schema_monthly)
  raw |>
    as_tibble() |>
    transmute(
      year        = as.integer(year),
      month       = as.integer(month),
      decimal     = as.numeric(decimal),
      average     = as.numeric(average),
      average_unc = as.numeric(average_unc),
      trend       = as.numeric(trend),
      trend_unc   = as.numeric(trend_unc)
    )
}


#' Fetch monthly global CH4 (methane) data
#'
#' @return tibble: year, month, decimal, average, average_unc, trend, trend_unc
co2_ch4_monthly <- function() {
  f <- .fetch_csv(paste0(.gml_base, "/ch4/ch4_mm_gl.csv"))
  raw <- read.csv(f, comment.char = "#", stringsAsFactors = FALSE)
  if (nrow(raw) == 0) return(.schema_monthly)
  # ch4 csv may have blank rows
  raw <- raw[!is.na(raw$year) & raw$year != "", ]
  raw |>
    as_tibble() |>
    transmute(
      year        = as.integer(year),
      month       = as.integer(month),
      decimal     = as.numeric(decimal),
      average     = as.numeric(average),
      average_unc = as.numeric(average_unc),
      trend       = as.numeric(trend),
      trend_unc   = as.numeric(trend_unc)
    )
}


#' Fetch NOAA SWPC solar wind plasma data
#'
#' Returns solar wind plasma measurements (density, speed, temperature)
#' from the DSCOVR satellite. Available in 2-hour, 6-hour, 1-day,
#' 3-day, and 7-day windows.
#'
#' @param days Time window: 0.08 (2hr), 0.25 (6hr), 1, 3, or 7 (default 7)
#' @return tibble: time_tag (POSIXct), density (numeric), speed (numeric),
#'   temperature (numeric)
swpc_plasma <- function(days = 7) {
  slug <- switch(as.character(days),
    "0.08" = "2-hour", "0.25" = "6-hour",
    "1" = "1-day", "3" = "3-day", "7" = "7-day",
    stop("days must be one of: 0.08, 0.25, 1, 3, 7")
  )
  url <- sprintf("%s/solar-wind/plasma-%s.json", .swpc_base, slug)
  raw <- .fetch_json(url)
  df <- .parse_swpc_array(raw)
  if (nrow(df) == 0) return(.schema_plasma)

  df |>
    transmute(
      time_tag    = as.POSIXct(time_tag, format = "%Y-%m-%d %H:%M:%S", tz = "UTC"),
      density     = as.numeric(density),
      speed       = as.numeric(speed),
      temperature = as.numeric(temperature)
    )
}


#' Fetch NOAA SWPC solar wind magnetic field data
#'
#' Returns interplanetary magnetic field (IMF) measurements in GSM
#' coordinates from the DSCOVR satellite.
#'
#' @param days Time window: 0.08 (2hr), 0.25 (6hr), 1, 3, or 7 (default 7)
#' @return tibble: time_tag (POSIXct), bx_gsm, by_gsm, bz_gsm, lon_gsm,
#'   lat_gsm, bt (all numeric, nT)
swpc_mag <- function(days = 7) {
  slug <- switch(as.character(days),
    "0.08" = "2-hour", "0.25" = "6-hour",
    "1" = "1-day", "3" = "3-day", "7" = "7-day",
    stop("days must be one of: 0.08, 0.25, 1, 3, 7")
  )
  url <- sprintf("%s/solar-wind/mag-%s.json", .swpc_base, slug)
  raw <- .fetch_json(url)
  df <- .parse_swpc_array(raw)
  if (nrow(df) == 0) return(.schema_mag)

  df |>
    transmute(
      time_tag = as.POSIXct(time_tag, format = "%Y-%m-%d %H:%M:%S", tz = "UTC"),
      bx_gsm   = as.numeric(bx_gsm),
      by_gsm   = as.numeric(by_gsm),
      bz_gsm   = as.numeric(bz_gsm),
      lon_gsm  = as.numeric(lon_gsm),
      lat_gsm  = as.numeric(lat_gsm),
      bt       = as.numeric(bt)
    )
}


#' Fetch NOAA planetary Kp index
#'
#' Returns the planetary K-index (Kp), a measure of geomagnetic storm
#' intensity on a 0-9 scale. Values >= 5 indicate geomagnetic storms.
#'
#' @return tibble: time_tag (POSIXct), kp (numeric), a_running (numeric),
#'   station_count (integer)
swpc_kp_index <- function() {
  url <- sprintf("%s/noaa-planetary-k-index.json", .swpc_base)
  raw <- .fetch_json(url)
  df <- .parse_swpc_array(raw)
  if (nrow(df) == 0) return(.schema_kp)

  df |>
    transmute(
      time_tag      = as.POSIXct(time_tag, format = "%Y-%m-%d %H:%M:%S", tz = "UTC"),
      kp            = as.numeric(Kp),
      a_running     = as.numeric(a_running),
      station_count = as.integer(station_count)
    )
}


#' Fetch NOAA space weather alerts
#'
#' Returns recent space weather alerts, watches, and warnings issued
#' by the Space Weather Prediction Center.
#'
#' @return tibble: product_id (character), issue_datetime (POSIXct),
#'   message (character)
swpc_alerts <- function() {
  url <- sprintf("%s/alerts.json", .swpc_base)
  raw <- .fetch_json(url)
  if (length(raw) == 0) return(.schema_alerts)

  rows <- lapply(raw, function(x) {
    tibble(
      product_id     = as.character(x$product_id %||% NA),
      issue_datetime = as.POSIXct(x$issue_datetime %||% NA,
                                  format = "%Y-%m-%d %H:%M:%S", tz = "UTC"),
      message        = as.character(x$message %||% NA)
    )
  })
  bind_rows(rows)
}


# == Context ===================================================================

#' Generate LLM-friendly context for noaa.gov
#'
#' @return Character string with full function signatures and bodies
noaa_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/noaa.gov.R"
  if (!file.exists(src_file)) {
    cat("# noaa.gov context - source not found\n")
    return(invisible("# noaa.gov context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

