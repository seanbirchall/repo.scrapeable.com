# == Schemas ===================================================================

.schema_exim <- tibble(
  fiscal_year = integer(), unique_id = character(), deal_number = character(),
  decision = character(), decision_date = as.Date(character()),
  country = character(), program = character(), policy_type = character(),
  product_description = character(), term = character(),
  primary_exporter = character(), exporter_state = character(),
  approved_amount = numeric(), disbursed_amount = numeric(),
  small_business_amount = numeric()
)

# == Public functions ==========================================================

#' List EXIM Bank authorizations
#'
#' Returns all EXIM Bank authorizations. Data covers FY2007-present.
#'
#' @param fiscal_year Optional integer; filter to a specific fiscal year.
#' @param country Optional character; filter to a specific country (case-insensitive partial match).
#' @param program Optional character; filter by program type (e.g. "Guarantee", "Insurance", "Loan", "Working Capital").
#' @param limit Maximum rows to return (default 500).
#' @return tibble of EXIM authorizations
#' @export
exim_list <- function(fiscal_year = NULL, country = NULL, program = NULL, limit = 500) {
  df <- .exim_load()

  if (!is.null(fiscal_year)) {
    df <- df |> filter(`Fiscal Year` == as.integer(fiscal_year))
  }
  if (!is.null(country)) {
    df <- df |> filter(grepl(country, Country, ignore.case = TRUE))
  }
  if (!is.null(program)) {
    df <- df |> filter(grepl(program, Program, ignore.case = TRUE))
  }

  df |> head(limit)
}

#' Search EXIM Bank authorizations
#'
#' Free-text search across exporter name, product description, borrower, and country.
#'
#' @param query Character string to search for (case-insensitive).
#' @param fiscal_year Optional integer; filter to a specific fiscal year.
#' @param limit Maximum rows to return (default 100).
#' @return tibble of matching EXIM authorizations
#' @export
exim_search <- function(query, fiscal_year = NULL, limit = 100) {
  df <- .exim_load()

  if (!is.null(fiscal_year)) {
    df <- df |> filter(`Fiscal Year` == as.integer(fiscal_year))
  }

  pattern <- query
  df <- df |>
    filter(
      grepl(pattern, `Primary Exporter` %||% "", ignore.case = TRUE) |
      grepl(pattern, `Product Description` %||% "", ignore.case = TRUE) |
      grepl(pattern, `Primary Borrower` %||% "", ignore.case = TRUE) |
      grepl(pattern, Country %||% "", ignore.case = TRUE) |
      grepl(pattern, `Primary Applicant` %||% "", ignore.case = TRUE)
    )

  df |> head(limit)
}

#' Summarize EXIM authorizations by country
#'
#' @param fiscal_year Optional integer; filter to a specific fiscal year.
#' @param top_n Number of top countries to show (default 20).
#' @return tibble: country, n_deals, total_approved, total_disbursed
#' @export
exim_by_country <- function(fiscal_year = NULL, top_n = 20) {
  df <- .exim_load()

  if (!is.null(fiscal_year)) {
    df <- df |> filter(`Fiscal Year` == as.integer(fiscal_year))
  }

  df |>
    group_by(country = Country) |>
    summarise(
      n_deals = n(),
      total_approved = sum(`Approved/Declined Amount`, na.rm = TRUE),
      total_disbursed = sum(`Disbursed/Shipped Amount`, na.rm = TRUE),
      .groups = "drop"
    ) |>
    arrange(desc(total_approved)) |>
    head(top_n)
}

#' Summarize EXIM authorizations by fiscal year
#'
#' @return tibble: fiscal_year, n_deals, total_approved, total_disbursed
#' @export
exim_by_year <- function() {
  df <- .exim_load()

  df |>
    group_by(fiscal_year = `Fiscal Year`) |>
    summarise(
      n_deals = n(),
      total_approved = sum(`Approved/Declined Amount`, na.rm = TRUE),
      total_disbursed = sum(`Disbursed/Shipped Amount`, na.rm = TRUE),
      .groups = "drop"
    ) |>
    arrange(fiscal_year)
}

#' Summarize EXIM authorizations by program
#'
#' @param fiscal_year Optional integer; filter to a specific fiscal year.
#' @return tibble: program, n_deals, total_approved
#' @export
exim_by_program <- function(fiscal_year = NULL) {
  df <- .exim_load()

  if (!is.null(fiscal_year)) {
    df <- df |> filter(`Fiscal Year` == as.integer(fiscal_year))
  }

  df |>
    group_by(program = Program) |>
    summarise(
      n_deals = n(),
      total_approved = sum(`Approved/Declined Amount`, na.rm = TRUE),
      .groups = "drop"
    ) |>
    arrange(desc(total_approved))
}

# == Context ===================================================================

#' Show EXIM client context for LLM use
#'
#' @return Invisibly returns context string
#' @export
exim_context <- function() {
  .build_context("exim.gov")
}
