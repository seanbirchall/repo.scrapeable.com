# rdap.org.R - Self-contained rdap.org client



# rdap-org.R
# Self-contained RDAP (Registration Data Access Protocol) client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.rdap_base <- "https://rdap.org"

`%||%` <- function(a, b) if (is.null(a)) b else a

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE)

# -- RDAP entity parser -------------------------------------------------------

.parse_entities <- function(entities) {
  if (is.null(entities) || length(entities) == 0) return(tibble(role = character(), name = character()))
  rows <- lapply(entities, function(e) {
    roles <- paste(unlist(e$roles %||% list()), collapse = ", ")
    name <- tryCatch({
      vcard <- e$vcardArray
      if (!is.null(vcard) && length(vcard) >= 2) {
        fn_entry <- Filter(function(x) x[[1]] == "fn", vcard[[2]])
        if (length(fn_entry) > 0) fn_entry[[1]][[4]] else e$handle %||% NA_character_
      } else e$handle %||% NA_character_
    }, error = function(err) e$handle %||% NA_character_)
    tibble(role = roles, name = as.character(name))
  })
  bind_rows(rows)
}

# == Schemas ===================================================================

.schema_domain <- tibble(
  name = character(), handle = character(), status = character(),
  registrar = character(), registration = as.Date(character()),
  expiration = as.Date(character()), last_changed = as.Date(character()),
  nameservers = character()
)

.schema_ip <- tibble(
  handle = character(), name = character(), type = character(),
  start_address = character(), end_address = character(),
  country = character(), status = character()
)

.schema_autnum <- tibble(
  handle = character(), name = character(), type = character(),
  start_autnum = integer(), end_autnum = integer(),
  country = character(), status = character()
)


# == Domain Lookup =============================================================

#' RDAP domain lookup
#'
#' Queries RDAP for domain registration information.
#'
#' @param domain Domain name (e.g. "example.com", "google.com")
#' @return tibble: name, handle, status, registrar, registration,
#'   expiration, last_changed, nameservers
rdap_domain <- function(domain) {
  url <- sprintf("%s/domain/%s", .rdap_base, utils::URLencode(domain))
  raw <- tryCatch(.fetch_json(url), error = function(e) {
    message("RDAP domain lookup failed: ", e$message)
    return(NULL)
  })
  if (is.null(raw)) return(.schema_domain)

  statuses <- paste(unlist(raw$status %||% list()), collapse = ", ")
  ns_list <- if (!is.null(raw$nameservers)) {
    paste(vapply(raw$nameservers, function(n) n$ldhName %||% "", character(1)), collapse = ", ")
  } else NA_character_

  events <- raw$events %||% list()
  get_event <- function(action) {
    for (e in events) {
      if (identical(e$eventAction, action)) return(tryCatch(as.Date(e$eventDate), error = function(err) as.Date(NA)))
    }
    as.Date(NA)
  }

  registrar <- tryCatch({
    ents <- raw$entities %||% list()
    reg_ent <- Filter(function(e) "registrar" %in% unlist(e$roles %||% list()), ents)
    if (length(reg_ent) > 0) {
      vc <- reg_ent[[1]]$vcardArray
      if (!is.null(vc) && length(vc) >= 2) {
        fn_entry <- Filter(function(x) x[[1]] == "fn", vc[[2]])
        if (length(fn_entry) > 0) fn_entry[[1]][[4]] else reg_ent[[1]]$handle %||% NA_character_
      } else reg_ent[[1]]$handle %||% NA_character_
    } else NA_character_
  }, error = function(e) NA_character_)

  tibble(
    name         = as.character(raw$ldhName %||% NA_character_),
    handle       = as.character(raw$handle %||% NA_character_),
    status       = statuses,
    registrar    = as.character(registrar),
    registration = get_event("registration"),
    expiration   = get_event("expiration"),
    last_changed = get_event("last changed"),
    nameservers  = as.character(ns_list)
  )
}

# == IP Lookup =================================================================

#' RDAP IP address/network lookup
#'
#' @param ip IP address or CIDR block (e.g. "8.8.8.8", "192.168.1.0/24")
#' @return tibble: handle, name, type, start_address, end_address,
#'   country, status
rdap_ip <- function(ip) {
  url <- sprintf("%s/ip/%s", .rdap_base, utils::URLencode(ip))
  raw <- tryCatch(.fetch_json(url), error = function(e) {
    message("RDAP IP lookup failed: ", e$message)
    return(NULL)
  })
  if (is.null(raw)) return(.schema_ip)

  tibble(
    handle        = as.character(raw$handle %||% NA_character_),
    name          = as.character(raw$name %||% NA_character_),
    type          = as.character(raw$type %||% NA_character_),
    start_address = as.character(raw$startAddress %||% NA_character_),
    end_address   = as.character(raw$endAddress %||% NA_character_),
    country       = as.character(raw$country %||% NA_character_),
    status        = paste(unlist(raw$status %||% list()), collapse = ", ")
  )
}

# == ASN Lookup ================================================================

#' RDAP autonomous system number lookup
#'
#' @param asn Autonomous System Number (e.g. 15169 or "15169")
#' @return tibble: handle, name, type, start_autnum, end_autnum,
#'   country, status
rdap_autnum <- function(asn) {
  url <- sprintf("%s/autnum/%s", .rdap_base, as.character(asn))
  raw <- tryCatch(.fetch_json(url), error = function(e) {
    message("RDAP autnum lookup failed: ", e$message)
    return(NULL)
  })
  if (is.null(raw)) return(.schema_autnum)

  tibble(
    handle       = as.character(raw$handle %||% NA_character_),
    name         = as.character(raw$name %||% NA_character_),
    type         = as.character(raw$type %||% NA_character_),
    start_autnum = as.integer(raw$startAutnum %||% NA_integer_),
    end_autnum   = as.integer(raw$endAutnum %||% NA_integer_),
    country      = as.character(raw$country %||% NA_character_),
    status       = paste(unlist(raw$status %||% list()), collapse = ", ")
  )
}

# == Context ===================================================================

#' Generate LLM-friendly context for rdap.org
#'
#' @return Character string with full function signatures and bodies
rdap_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/rdap.org.R"
  if (!file.exists(src_file)) {
    cat("# rdap.org context - source not found\n")
    return(invisible("# rdap.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

