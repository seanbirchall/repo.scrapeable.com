# bundlephobia.com.R - Self-contained bundlephobia.com client



# bundlephobia-com.R
# Self-contained Bundlephobia API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required.
# Rate limits: unknown — be polite.


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.bundlephobia_base <- "https://bundlephobia.com/api"
# -- Fetch helpers -------------------------------------------------------------

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))


# == Schemas ===================================================================

.schema_size <- tibble(
  name = character(), version = character(), description = character(),
  size = integer(), gzip = integer(), dependency_count = integer(),
  has_side_effects = logical(), repository = character()
)

# == Size ======================================================================

#' Get npm package bundle size from Bundlephobia
#'
#' Returns the minified and gzipped bundle size for an npm package,
#' plus dependency count and metadata.
#'
#' @param package npm package name (e.g. "react", "lodash", "express")
#' @return tibble: name (character), version (character), description (character),
#'   size (integer), gzip (integer), dependency_count (integer),
#'   has_side_effects (logical), repository (character)
bundlephobia_size <- function(package) {
  url <- paste0(.bundlephobia_base, "/size?package=", utils::URLencode(package))
  raw <- tryCatch(.fetch_json(url), error = function(e) {
    warning("Failed to fetch bundle size for '", package, "': ", e$message)
    return(NULL)
  })
  if (is.null(raw)) return(.schema_size)

  tibble(
    name             = as.character(raw$name %||% NA_character_),
    version          = as.character(raw$version %||% NA_character_),
    description      = as.character(raw$description %||% NA_character_),
    size             = as.integer(raw$size %||% NA_integer_),
    gzip             = as.integer(raw$gzip %||% NA_integer_),
    dependency_count = as.integer(raw$dependencyCount %||% NA_integer_),
    has_side_effects = as.logical(raw$hasSideEffects %||% NA),
    repository       = as.character(raw$repository %||% NA_character_)
  )
}
`%||%` <- function(a, b) if (is.null(a)) b else a

# == History ==================================================================

#' Get bundle size history across versions for an npm package
#'
#' Returns size data for each published version of a package, useful for
#' tracking how bundle size has changed over time.
#'
#' @param package npm package name (e.g. "react", "lodash")
#' @return tibble: name, version, size, gzip
bundlephobia_history <- function(package) {
  url <- paste0(.bundlephobia_base, "/package-history?package=", utils::URLencode(package))
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || length(raw) == 0) {
    return(tibble(name = character(), version = character(),
                  size = integer(), gzip = integer()))
  }

  # raw is a named list: version -> {size, gzip}
  if (is.list(raw) && !is.data.frame(raw)) {
    versions <- names(raw)
    rows <- lapply(seq_along(raw), function(i) {
      v <- raw[[i]]
      tibble(
        name = package,
        version = versions[i],
        size = as.integer(v$size %||% NA_integer_),
        gzip = as.integer(v$gzip %||% NA_integer_)
      )
    })
    bind_rows(rows)
  } else {
    tibble(name = character(), version = character(),
           size = integer(), gzip = integer())
  }
}

#' Compare bundle sizes of multiple npm packages
#'
#' @param packages Character vector of npm package names
#' @return tibble: name, version, description, size, gzip,
#'   dependency_count, has_side_effects, repository
bundlephobia_compare <- function(packages) {
  rows <- lapply(packages, function(pkg) {
    tryCatch(bundlephobia_size(pkg), error = function(e) NULL)
  })
  rows <- rows[!vapply(rows, is.null, logical(1))]
  if (length(rows) == 0) return(.schema_size)
  bind_rows(rows)
}

# == Context ===================================================================

#' Generate LLM-friendly context for bundlephobia.com
#'
#' @return Character string with full function signatures and bodies
bundlephobia_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/bundlephobia.com.R"
  if (!file.exists(src_file)) {
    cat("# bundlephobia.com context - source not found\n")
    return(invisible("# bundlephobia.com context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

