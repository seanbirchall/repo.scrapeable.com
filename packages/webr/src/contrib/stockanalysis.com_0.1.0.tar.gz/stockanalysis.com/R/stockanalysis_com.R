# stockanalysis.com.R - Self-contained stockanalysis.com client




# stockanalysis-com.R
# Self-contained Stock Analysis financial data client.
# All public functions return tibbles with typed columns.
#
# Dependencies: httr2, xml2, dplyr, tidyr, tibble
# Auth: none required (HTML scraping)
# Rate limits: undocumented, be polite (~1 req/sec)
# Coverage: income, balance sheet, cash flow, ratios for US public companies


# == Private utilities =========================================================

`%||%` <- function(x, y) if (is.null(x)) y else x
.ua <- "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
.sa_base <- "https://stockanalysis.com/stocks"
# -- Scraping engine -----------------------------------------------------------

.sa_fetch_table <- function(ticker, page) {
  url <- sprintf("%s/%s/%s/", .sa_base, tolower(ticker), page)

  tmp <- tempfile(fileext = ".html")
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)

  doc <- xml2::read_html(tmp)
  tables <- xml2::xml_find_all(doc, ".//table")
  if (length(tables) == 0) return(tibble())

  tbl <- tables[[1]]
  rows <- xml2::xml_find_all(tbl, ".//tr")
  if (length(rows) < 3) return(tibble())

  # Parse all rows
  cells <- lapply(rows, function(r) {
    xml2::xml_text(xml2::xml_find_all(r, ".//td|.//th"), trim = TRUE)
  })

  # Row 1 = period labels (TTM, FY 2025, FY 2024, ...)
  # Row 2 = period ending dates
  # Row 3+ = metrics
  header <- cells[[1]]
  if (length(header) < 2) return(tibble())

  # Extract year columns (skip first which is the metric name)
  year_labels <- header[-1]
  n_cols <- length(year_labels)

  # Parse data rows (skip header rows 1-2)
  data_rows <- cells[-(1:2)]
  if (length(data_rows) == 0) return(tibble())

  # Build tibble: one row per metric-year combination (long format)
  results <- lapply(data_rows, function(r) {
    if (length(r) < 2) return(NULL)
    metric <- r[1]
    if (metric == "" || is.na(metric)) return(NULL)
    vals <- r[-1]
    # Pad if needed
    length(vals) <- n_cols

    tibble(
      metric = metric,
      period = year_labels[seq_along(vals)],
      value_raw = vals
    )
  })

  df <- bind_rows(results)
  if (nrow(df) == 0) return(tibble())

  # Clean values: remove $, %, commas, handle (negative), convert
  df |>
    mutate(
      ticker = toupper(ticker),
      # Extract fiscal year from period label
      fiscal_year = as.integer(gsub(".*?(\\d{4}).*", "\\1", period)),
      is_ttm = period == "TTM",
      # Clean numeric values
      value = gsub("[$,%]", "", value_raw),
      value = gsub("\\((.+)\\)", "-\\1", value),  # (123) -> -123
      value = gsub(",", "", value),
      value = ifelse(value %in% c("-", "n/a", "N/A", ""), NA_character_, value),
      value = as.numeric(value)
    ) |>
    select(ticker, metric, period, fiscal_year, is_ttm, value)
}


# == Schemas ===================================================================

.schema_financials <- tibble(
  ticker = character(), metric = character(), period = character(),
  fiscal_year = integer(), is_ttm = logical(), value = numeric()
)



# == Financial statements ======================================================

#' Fetch income statement data
#'
#' Scrapes the income statement page. Returns metrics like Revenue,
#' Cost of Revenue, Gross Profit, Operating Income, Net Income, EPS, etc.
#'
#' @param ticker Stock ticker (e.g. "AAPL", "MSFT")
#' @return tibble: ticker, metric, period, fiscal_year, is_ttm, value
sa_income <- function(ticker) {
  .sa_fetch_table(ticker, "financials")
}

#' Fetch quarterly income statement
#'
#' @param ticker Stock ticker
#' @return tibble: ticker, metric, period, fiscal_year, is_ttm, value
sa_income_quarterly <- function(ticker) {
  .sa_fetch_table(ticker, "financials/?p=quarterly")
}

#' Fetch balance sheet data
#'
#' @param ticker Stock ticker
#' @return tibble: ticker, metric, period, fiscal_year, is_ttm, value
sa_balance <- function(ticker) {
  .sa_fetch_table(ticker, "financials/balance-sheet")
}

#' Fetch quarterly balance sheet
#'
#' @param ticker Stock ticker
#' @return tibble: ticker, metric, period, fiscal_year, is_ttm, value
sa_balance_quarterly <- function(ticker) {
  .sa_fetch_table(ticker, "financials/balance-sheet/?p=quarterly")
}

#' Fetch cash flow statement
#'
#' @param ticker Stock ticker
#' @return tibble: ticker, metric, period, fiscal_year, is_ttm, value
sa_cashflow <- function(ticker) {
  .sa_fetch_table(ticker, "financials/cash-flow-statement")
}

#' Fetch quarterly cash flow statement
#'
#' @param ticker Stock ticker
#' @return tibble: ticker, metric, period, fiscal_year, is_ttm, value
sa_cashflow_quarterly <- function(ticker) {
  .sa_fetch_table(ticker, "financials/cash-flow-statement/?p=quarterly")
}

#' Fetch financial ratios
#'
#' PE, PB, PS, dividend yield, margins, returns, etc.
#'
#' @param ticker Stock ticker
#' @return tibble: ticker, metric, period, fiscal_year, is_ttm, value
sa_ratios <- function(ticker) {
  .sa_fetch_table(ticker, "financials/ratios")
}


# == Convenience: all financials ===============================================

#' Fetch all financial statements for a ticker
#'
#' Combines income, balance sheet, and cash flow into one tibble.
#' Makes 3 HTTP requests.
#'
#' @param ticker Stock ticker
#' @param quarterly If TRUE, fetch quarterly data instead of annual
#' @return tibble: ticker, metric, period, fiscal_year, is_ttm, value, statement
sa_financials <- function(ticker, quarterly = FALSE) {
  if (quarterly) {
    inc <- tryCatch(sa_income_quarterly(ticker), error = function(e) NULL)
    bal <- tryCatch(sa_balance_quarterly(ticker), error = function(e) NULL)
    cf  <- tryCatch(sa_cashflow_quarterly(ticker), error = function(e) NULL)
  } else {
    inc <- tryCatch(sa_income(ticker), error = function(e) NULL)
    bal <- tryCatch(sa_balance(ticker), error = function(e) NULL)
    cf  <- tryCatch(sa_cashflow(ticker), error = function(e) NULL)
  }

  bind_rows(
    if (!is.null(inc) && nrow(inc) > 0) mutate(inc, statement = "income") else NULL,
    if (!is.null(bal) && nrow(bal) > 0) mutate(bal, statement = "balance") else NULL,
    if (!is.null(cf) && nrow(cf) > 0)  mutate(cf, statement = "cashflow") else NULL
  )
}


# == Context ===================================================================

#' Generate LLM-friendly context for stockanalysis.com
#'
#' @return Character string with full function signatures and bodies
sa_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/stockanalysis.com.R"
  if (!file.exists(src_file)) {
    cat("# stockanalysis.com context - source not found\n")
    return(invisible("# stockanalysis.com context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

