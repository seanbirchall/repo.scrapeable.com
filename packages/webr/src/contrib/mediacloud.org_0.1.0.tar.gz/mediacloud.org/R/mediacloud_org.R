# mediacloud.org.R - Self-contained mediacloud.org client


`%||%` <- function(a, b) if (is.null(a)) b else a


# mediacloud.R
# Self-contained Media Cloud API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required for search overview
# Rate limits: not documented, be respectful


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.mc_base <- "https://search.mediacloud.org/api"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))

# == Schemas ===================================================================

.schema_search <- tibble(
  query = character(), date_range = character(),
  total = integer(), matches_per_day = character()
)

# == Search ====================================================================

#' Search Media Cloud for news coverage overview
#'
#' @param query Search query (e.g. "climate change", "elections")
#' @param date_range Date range as "YYYY-MM-DD..YYYY-MM-DD"
#'   (e.g. "2025-01-01..2025-03-31")
#' @return tibble: query, date_range, total, matches_per_day
mc_search <- function(query, date_range) {
  url <- paste0(.mc_base, "/search/overview?q=", utils::URLencode(query),
                "&dt=", date_range)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_search)

  total <- as.integer(raw$total %||% raw$`relevant` %||% NA_integer_)
  mpd <- if (!is.null(raw$dailyCounts) || !is.null(raw$`matches_per_day`)) {
    counts <- raw$dailyCounts %||% raw$`matches_per_day`
    if (is.data.frame(counts)) {
      paste(apply(counts, 1, function(r) paste(r, collapse = ":")), collapse = "; ")
    } else if (is.list(counts)) {
      paste(names(counts), unlist(counts), sep = ":", collapse = "; ")
    } else as.character(counts)
  } else NA_character_

  tibble(
    query = query,
    date_range = date_range,
    total = total,
    matches_per_day = mpd
  )
}

# == Context ===================================================================

#' Generate LLM-friendly context for mediacloud.org
#'
#' @return Character string with full function signatures and bodies
mc_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/mediacloud.org.R"
  if (!file.exists(src_file)) {
    cat("# mediacloud.org context - source not found\n")
    return(invisible("# mediacloud.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

