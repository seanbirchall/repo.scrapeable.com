# == Public functions ==========================================================

#' List available Philadelphia School District datasets
#'
#' @return tibble: id, name, url, category
#' @export
psd_list <- function() {
  .psd_datasets
}

#' List files inside a PSSA/Keystone ZIP archive
#'
#' @param dataset_id Dataset id from psd_list()
#' @return tibble: Name, Length, Date (contents of ZIP)
#' @export
psd_zip_contents <- function(dataset_id) {
  match <- .psd_datasets |> filter(.data$id == !!dataset_id)
  if (nrow(match) == 0) {
    stop("Unknown dataset: ", dataset_id, call. = FALSE)
  }
  f <- .fetch_file(match$url[1], ext = ".zip")
  utils::unzip(f, list = TRUE) |> as_tibble()
}

#' Download and extract a PSSA dataset from ZIP archive
#'
#' Returns a list of tibbles, one per Excel file found in the ZIP.
#' Note: These Excel files have complex multi-row headers. Use
#' the sheet and skip parameters to navigate.
#'
#' @param dataset_id Dataset id from psd_list()
#' @param sheet Sheet name or number to read (default 1)
#' @param skip Number of header rows to skip (default 0)
#' @return list of tibbles: one per Excel file in the archive
#' @export
psd_data <- function(dataset_id, sheet = 1, skip = 0) {
  match <- .psd_datasets |> filter(.data$id == !!dataset_id)
  if (nrow(match) == 0) {
    stop("Unknown dataset: ", dataset_id, call. = FALSE)
  }
  .fetch_zip_excel(match$url[1], sheet = sheet, skip = skip)
}

#' List sheets in the Excel files of a PSSA dataset
#'
#' @param dataset_id Dataset id from psd_list()
#' @return named list: filename -> vector of sheet names
#' @export
psd_sheets <- function(dataset_id) {
  match <- .psd_datasets |> filter(.data$id == !!dataset_id)
  if (nrow(match) == 0) stop("Unknown dataset: ", dataset_id, call. = FALSE)
  f <- .fetch_file(match$url[1], ext = ".zip")
  d <- tempfile(); dir.create(d)
  utils::unzip(f, exdir = d)
  xlsx_files <- list.files(d, pattern = "\\.xlsx?$", full.names = TRUE, recursive = TRUE)
  result <- lapply(xlsx_files, function(xf) {
    tryCatch(readxl::excel_sheets(xf), error = function(e) character(0))
  })
  names(result) <- basename(xlsx_files)
  result
}

#' Return context: full source of this client
#'
#' @return character: source code of this file
#' @export
psd_context <- function() {
  f <- system.file("source", "philasd.org.R", package = "philasd.org")
  if (f == "") {
    f <- tryCatch(
      { env <- sys.frame(0); getSrcFilename(env, full.names = TRUE) },
      error = function(e) ""
    )
  }
  if (f == "" || !file.exists(f)) return("Source not available")
  paste(readLines(f, warn = FALSE), collapse = "\n")
}
