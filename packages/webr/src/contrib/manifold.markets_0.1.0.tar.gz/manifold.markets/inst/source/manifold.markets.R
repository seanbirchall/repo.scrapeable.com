# manifold.markets.R - Self-contained manifold.markets client

library(httr2)
library(jsonlite)
library(tibble)
library(dplyr)


# manifold.R
# Self-contained Manifold Markets API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required for public endpoints
# Rate limits: generous


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.mfld_base <- "https://api.manifold.markets/v0"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = TRUE)

# == Schemas ===================================================================

.schema_markets <- tibble(
  id = character(), question = character(), url = character(),
  probability = numeric(), volume = numeric(),
  creator_username = character(), mechanism = character(),
  created_time = as.POSIXct(character()), close_time = as.POSIXct(character()),
  is_resolved = logical()
)

.schema_market <- tibble(
  id = character(), question = character(), url = character(),
  probability = numeric(), volume = numeric(),
  creator_username = character(), mechanism = character(),
  description = character(), is_resolved = logical(),
  total_liquidity = numeric()
)


`%||%` <- function(x, y) if (is.null(x)) y else x

# == Public functions ==========================================================

#' List Manifold Markets prediction markets
#'
#' @param limit Max results (default 10, max 1000)
#' @param term Search term to filter markets
#' @return tibble: id, question, url, probability, volume, creator_username,
#'   mechanism, created_time, close_time, is_resolved
mfld_markets <- function(limit = 10, term = NULL) {
  params <- list(limit = limit)
  if (!is.null(term)) params$term <- utils::URLencode(term, reserved = TRUE)
  qstr <- paste(names(params), params, sep = "=", collapse = "&")
  url <- paste0(.mfld_base, "/search-markets?", qstr)
  raw <- .fetch_json(url)
  if (length(raw) == 0 || (is.data.frame(raw) && nrow(raw) == 0)) return(.schema_markets)

  tibble(
    id = as.character(raw$id),
    question = as.character(raw$question),
    url = as.character(raw$url %||% NA_character_),
    probability = as.numeric(raw$probability %||% NA_real_),
    volume = as.numeric(raw$volume %||% NA_real_),
    creator_username = as.character(raw$creatorUsername %||% NA_character_),
    mechanism = as.character(raw$mechanism %||% NA_character_),
    created_time = as.POSIXct(as.numeric(raw$createdTime %||% NA_real_) / 1000, origin = "1970-01-01"),
    close_time = as.POSIXct(as.numeric(raw$closeTime %||% NA_real_) / 1000, origin = "1970-01-01"),
    is_resolved = as.logical(raw$isResolved %||% NA)
  )
}

#' Get a single Manifold market by ID
#'
#' @param id Market ID or slug
#' @return tibble: one row with id, question, url, probability, volume,
#'   creator_username, mechanism, description, is_resolved, total_liquidity
mfld_market <- function(id) {
  url <- paste0(.mfld_base, "/market/", id)
  raw <- .fetch_json(url)
  if (length(raw) == 0) return(.schema_market)

  tibble(
    id = as.character(raw$id),
    question = as.character(raw$question),
    url = as.character(raw$url %||% NA_character_),
    probability = as.numeric(raw$probability %||% NA_real_),
    volume = as.numeric(raw$volume %||% NA_real_),
    creator_username = as.character(raw$creatorUsername %||% NA_character_),
    mechanism = as.character(raw$mechanism %||% NA_character_),
    description = as.character(raw$textDescription %||% NA_character_),
    is_resolved = as.logical(raw$isResolved %||% NA),
    total_liquidity = as.numeric(raw$totalLiquidity %||% NA_real_)
  )
}

#' List Manifold groups (topics/categories)
#'
#' @param available_to_anyone If TRUE, only public groups (default TRUE)
#' @return tibble: id, name, slug, total_members
mfld_groups <- function(available_to_anyone = TRUE) {
  schema <- tibble(id = character(), name = character(), slug = character(),
                   total_members = integer())
  url <- paste0(.mfld_base, "/groups")
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || length(raw) == 0) return(schema)
  if (!is.data.frame(raw)) return(schema)

  as_tibble(raw) |>
    transmute(
      id = as.character(id),
      name = as.character(if ("name" %in% names(raw)) name else NA_character_),
      slug = as.character(if ("slug" %in% names(raw)) slug else NA_character_),
      total_members = as.integer(if ("totalMembers" %in% names(raw)) totalMembers else NA_integer_)
    )
}

#' Get a Manifold user profile by username
#'
#' @param username Manifold username
#' @return tibble: id, name, username, created_time, balance, total_deposits, profit_cached
mfld_user <- function(username) {
  schema <- tibble(id = character(), name = character(), username = character(),
                   created_time = as.POSIXct(character()), balance = numeric(),
                   total_deposits = numeric(), profit_cached = numeric())
  url <- paste0(.mfld_base, "/user/", utils::URLencode(username))
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$id)) return(schema)

  tibble(
    id = as.character(raw$id),
    name = as.character(raw$name %||% NA_character_),
    username = as.character(raw$username %||% NA_character_),
    created_time = as.POSIXct(as.numeric(raw$createdTime %||% NA_real_) / 1000, origin = "1970-01-01"),
    balance = as.numeric(raw$balance %||% NA_real_),
    total_deposits = as.numeric(raw$totalDeposits %||% NA_real_),
    profit_cached = as.numeric(raw$profitCached %||% list(allTime = NA_real_)$allTime %||% NA_real_)
  )
}

# == Context ===================================================================

#' Generate LLM-friendly context for manifold.markets
#'
#' @return Character string with full function signatures and bodies
mfld_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/manifold.markets.R"
  if (!file.exists(src_file)) {
    cat("# manifold.markets context - source not found\n")
    return(invisible("# manifold.markets context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

