# gutenberg.org.R - Self-contained gutenberg.org client




.ua <- "support@scrapeable.com"
.base <- "https://gutendex.com"

.fetch_json <- function(url) {
  tmp <- tempfile(fileext = ".json")
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  jsonlite::fromJSON(tmp, simplifyVector = FALSE)
}


#' Search Project Gutenberg books
#'
#' @param query Search term
#' @param page Page number (default 1)
#' @return tibble of matching books
guten_search <- function(query, page = 1L) {
  url <- sprintf("%s/books?search=%s&page=%d", .base,
                 utils::URLencode(query, reserved = TRUE), page)
  raw <- .fetch_json(url)
  results <- raw$results
  if (length(results) == 0) return(tibble::tibble(id = integer(), title = character(), authors = character()))
  tibble::tibble(
    id = vapply(results, function(x) x$id %||% NA_integer_, integer(1)),
    title = vapply(results, function(x) x$title %||% NA_character_, character(1)),
    authors = vapply(results, function(x) {
      if (length(x$authors) > 0) paste(vapply(x$authors, function(a) a$name %||% "", character(1)), collapse = "; ")
      else NA_character_
    }, character(1)),
    languages = vapply(results, function(x) paste(unlist(x$languages), collapse = ", "), character(1)),
    download_count = vapply(results, function(x) x$download_count %||% NA_integer_, integer(1))
  )
}

#' Get a specific Gutenberg book
#'
#' @param book_id Gutenberg book ID
#' @return tibble with one row of book metadata
guten_book <- function(book_id) {
  url <- sprintf("%s/books/%d", .base, as.integer(book_id))
  raw <- .fetch_json(url)
  tibble::tibble(
    id = raw$id %||% NA_integer_,
    title = raw$title %||% NA_character_,
    authors = if (length(raw$authors) > 0) paste(vapply(raw$authors, function(a) a$name, character(1)), collapse = "; ") else NA_character_,
    subjects = if (length(raw$subjects) > 0) paste(unlist(raw$subjects), collapse = "; ") else NA_character_,
    languages = paste(unlist(raw$languages), collapse = ", "),
    download_count = raw$download_count %||% NA_integer_
  )
}

# == Context ===================================================================

#' Generate LLM-friendly context for gutenberg.org
#'
#' @return Character string with full function signatures and bodies
guten_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/gutenberg.org.R"
  if (!file.exists(src_file)) {
    cat("# gutenberg.org context - source not found\n")
    return(invisible("# gutenberg.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

