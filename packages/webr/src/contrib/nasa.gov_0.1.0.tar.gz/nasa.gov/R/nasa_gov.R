# nasa.gov.R
# Self-contained NASA client.
# Covers: GISS temperature data and NASA Technical Reports Server (NTRS).
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required



# == Private utilities =========================================================

`%||%` <- function(a, b) if (is.null(a)) b else a
.ua <- "support@scrapeable.com"
.giss_base <- "https://data.giss.nasa.gov/gistemp/tabledata_v4"
.ntrs_base <- "https://ntrs.nasa.gov/api"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))


# == Schemas ===================================================================

.schema_global_temp <- tibble(
  year = integer(), jan = numeric(), feb = numeric(), mar = numeric(),
  apr = numeric(), may = numeric(), jun = numeric(), jul = numeric(),
  aug = numeric(), sep = numeric(), oct = numeric(), nov = numeric(),
  dec = numeric(), j_d = numeric(), d_n = numeric(), djf = numeric(),
  mam = numeric(), jja = numeric(), son = numeric()
)

.schema_citations <- tibble(
  id = character(), title = character(), sti_type = character(),
  distribution = character(), created = as.Date(character()),
  authors = character()
)




#' Download and parse GISTEMP global temperature anomalies
#'
#' Fetches the GLB.Ts+dSST.csv file from NASA GISS, which contains monthly
#' global mean surface temperature anomalies (degrees C) relative to the
#' 1951-1980 base period.
#'
#' @param dataset One of "global" (land+ocean), "land", "southern", "northern".
#'   Default "global".
#' @return tibble with year and monthly/seasonal temperature anomaly columns
giss_global_temp <- function(dataset = "global") {
  file_map <- list(
    global   = "GLB.Ts+dSST.csv",
    land     = "GLB.Ts.csv",
    northern = "NH.Ts+dSST.csv",
    southern = "SH.Ts+dSST.csv"
  )
  fname <- file_map[[dataset]]
  if (is.null(fname)) stop("dataset must be one of: global, land, northern, southern")

  url <- paste0(.giss_base, "/", fname)
  tmp <- .fetch(url, ext = ".csv")
  raw_lines <- readLines(tmp, warn = FALSE)

  # Find the header row (starts with "Year")
  header_idx <- grep("^Year", raw_lines)[1]
  if (is.na(header_idx)) stop("Could not find header row in CSV")

  # Read from header row, replacing *** with NA
  data_lines <- raw_lines[header_idx:length(raw_lines)]
  data_lines <- gsub("\\*\\*\\*", "NA", data_lines)

  # Remove any trailing non-data lines (like "Year" appearing again)

  con <- textConnection(data_lines)
  df <- tryCatch(
    read.csv(con, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  close(con)

  if (is.null(df) || nrow(df) == 0) return(.schema_global_temp)

  # Clean column names
  names(df) <- tolower(names(df))
  names(df) <- gsub("-", "_", names(df))

  # Remove non-numeric year rows

  df <- df[grepl("^\\d{4}$", trimws(df$year)), , drop = FALSE]

  df <- as_tibble(df) |>
    mutate(
      year = as.integer(year),
      across(-year, ~ suppressWarnings(as.numeric(.x)))
    )

  df
}


#' Download GISTEMP zonal mean temperature anomalies
#'
#' Fetches ZonAnn.Ts+dSST.csv from NASA GISS, which contains annual
#' zonal mean surface temperature anomalies by latitude band.
#'
#' @param dataset One of "combined" (land+ocean) or "land". Default "combined".
#' @return tibble: year, glob, nhem, shem, and latitude band columns
giss_zonal_temp <- function(dataset = "combined") {
  file_map <- list(
    combined = "ZonAnn.Ts+dSST.csv",
    land     = "ZonAnn.Ts.csv"
  )
  fname <- file_map[[dataset]]
  if (is.null(fname)) stop("dataset must be one of: combined, land")

  url <- paste0(.giss_base, "/", fname)
  tmp <- .fetch(url, ext = ".csv")
  raw_lines <- readLines(tmp, warn = FALSE)

  header_idx <- grep("^Year", raw_lines)[1]
  if (is.na(header_idx)) stop("Could not find header row in CSV")

  data_lines <- raw_lines[header_idx:length(raw_lines)]
  data_lines <- gsub("\\*\\*\\*", "NA", data_lines)

  con <- textConnection(data_lines)
  df <- tryCatch(
    read.csv(con, stringsAsFactors = FALSE, check.names = FALSE),
    error = function(e) NULL
  )
  close(con)

  if (is.null(df) || nrow(df) == 0) return(tibble(year = integer(), glob = numeric()))

  names(df) <- tolower(names(df))
  names(df) <- gsub("-", "_", names(df))
  df <- df[grepl("^\\d{4}$", trimws(df$year)), , drop = FALSE]

  as_tibble(df) |>
    mutate(
      year = as.integer(year),
      across(-year, ~ suppressWarnings(as.numeric(.x)))
    )
}


#' Get GISTEMP temperature anomaly for a specific year
#'
#' @param year Integer year (e.g. 2023)
#' @param dataset One of "global", "land", "northern", "southern". Default "global".
#' @return tibble with one row of monthly anomalies for that year
giss_year <- function(year, dataset = "global") {
  df <- giss_global_temp(dataset = dataset)
  df[df$year == as.integer(year), , drop = FALSE]
}


#' Get GISTEMP trend summary (first and last decade averages)
#'
#' Computes average anomalies for the first and last full decades in the dataset,
#' useful for quick trend assessment.
#'
#' @param dataset One of "global", "land", "northern", "southern". Default "global".
#' @return tibble: period, avg_annual_anomaly
giss_trend <- function(dataset = "global") {
  df <- giss_global_temp(dataset = dataset)
  if (nrow(df) == 0) return(tibble(period = character(), avg_annual_anomaly = numeric()))

  # Use j_d (Jan-Dec annual mean) if available
  annual_col <- if ("j_d" %in% names(df)) "j_d" else if ("d_n" %in% names(df)) "d_n" else NULL
  if (is.null(annual_col)) return(tibble(period = character(), avg_annual_anomaly = numeric()))

  min_yr <- min(df$year, na.rm = TRUE)
  max_yr <- max(df$year, na.rm = TRUE)

  first_decade <- df[df$year >= min_yr & df$year < min_yr + 10, ]
  last_decade <- df[df$year > max_yr - 10 & df$year <= max_yr, ]

  tibble(
    period = c(
      paste0(min_yr, "-", min_yr + 9),
      paste0(max_yr - 9, "-", max_yr)
    ),
    avg_annual_anomaly = c(
      mean(first_decade[[annual_col]], na.rm = TRUE),
      mean(last_decade[[annual_col]], na.rm = TRUE)
    )
  )
}


#' Search NASA Technical Reports Server
#'
#' @param query Search query string
#' @param page_size Results per page (default 25)
#' @param page Page number (0-indexed, default 0)
#' @return tibble: id, title, sti_type, distribution, created, authors
ntrs_search <- function(query, page_size = 25, page = 0) {
  body <- list(
    query = query,
    page = list(size = page_size, from = page * page_size)
  )
  raw <- .ntrs_post("/citations/search", body)
  df <- raw$results
  if (is.null(df) || !is.data.frame(df) || nrow(df) == 0) return(.schema_citations)

  auth_strs <- vapply(seq_len(nrow(df)), function(i) {
    auths <- df$authorAffiliations[[i]]
    if (is.null(auths) || !is.data.frame(auths) || nrow(auths) == 0) return(NA_character_)
    paste(vapply(seq_len(nrow(auths)), function(j) {
      tryCatch(auths$meta$author$name[j] %||% NA_character_,
               error = function(e) NA_character_)
    }, character(1)), collapse = "; ")
  }, character(1))

  tibble(
    id = as.character(df$id),
    title = as.character(df$title),
    sti_type = as.character(df$stiType),
    distribution = as.character(df$distribution),
    created = tryCatch(as.Date(substr(df$created, 1, 10)),
                       error = function(e) rep(as.Date(NA), nrow(df))),
    authors = auth_strs
  )
}


#' Fetch a single NTRS citation by ID
#'
#' @param id NTRS citation ID
#' @return tibble: single row with citation details
ntrs_citation <- function(id) {
  url <- sprintf("%s/citations/%s", .ntrs_base, as.character(id))
  raw <- .fetch_json(url)
  if (is.null(raw)) return(.schema_citations)

  auths <- raw$authorAffiliations
  auth_str <- if (!is.null(auths) && length(auths) > 0) {
    if (is.data.frame(auths)) {
      paste(vapply(seq_len(nrow(auths)), function(i) {
        tryCatch(auths$meta[[i]]$author$name %||% NA_character_,
                 error = function(e) NA_character_)
      }, character(1)), collapse = "; ")
    } else {
      paste(vapply(auths, function(a) a$meta$author$name %||% NA_character_, character(1)), collapse = "; ")
    }
  } else NA_character_

  tibble(
    id = as.character(raw$id %||% NA),
    title = as.character(raw$title %||% NA),
    sti_type = as.character(raw$stiType %||% NA),
    distribution = as.character(raw$distribution %||% NA),
    created = tryCatch(as.Date(substr(raw$created %||% "", 1, 10)),
                       error = function(e) as.Date(NA)),
    authors = auth_str
  )
}


#' Search NASA Technical Reports by center
#'
#' @param center NASA center code (e.g., "JPL", "GSFC", "ARC", "MSFC")
#' @param page_size Results per page (default 25)
#' @return tibble: id, title, sti_type, distribution, created, authors
ntrs_by_center <- function(center, page_size = 25) {
  body <- list(
    center = center,
    page = list(size = page_size, from = 0)
  )
  raw <- tryCatch(.ntrs_post("/citations/search", body), error = function(e) NULL)
  if (is.null(raw)) return(.schema_citations)
  df <- raw$results
  if (is.null(df) || !is.data.frame(df) || nrow(df) == 0) return(.schema_citations)

  auth_strs <- vapply(seq_len(nrow(df)), function(i) {
    auths <- df$authorAffiliations[[i]]
    if (is.null(auths) || !is.data.frame(auths) || nrow(auths) == 0) return(NA_character_)
    paste(vapply(seq_len(nrow(auths)), function(j) {
      tryCatch(auths$meta$author$name[j] %||% NA_character_,
               error = function(e) NA_character_)
    }, character(1)), collapse = "; ")
  }, character(1))

  tibble(
    id = as.character(df$id),
    title = as.character(df$title),
    sti_type = as.character(df$stiType),
    distribution = as.character(df$distribution),
    created = tryCatch(as.Date(substr(df$created, 1, 10)),
                       error = function(e) rep(as.Date(NA), nrow(df))),
    authors = auth_strs
  )
}


#' Get recent NASA Technical Reports
#'
#' @param page_size Number of results (default 25)
#' @param type STI type filter: "TECHNICAL_REPORT", "CONFERENCE_PAPER", "REPRINT", etc.
#' @return tibble: id, title, sti_type, distribution, created, authors
ntrs_recent <- function(page_size = 25, type = NULL) {
  body <- list(
    page = list(size = page_size, from = 0)
  )
  if (!is.null(type)) body$stiType <- type
  raw <- tryCatch(.ntrs_post("/citations/search", body), error = function(e) NULL)
  if (is.null(raw)) return(.schema_citations)
  df <- raw$results
  if (is.null(df) || !is.data.frame(df) || nrow(df) == 0) return(.schema_citations)

  auth_strs <- vapply(seq_len(nrow(df)), function(i) {
    auths <- df$authorAffiliations[[i]]
    if (is.null(auths) || !is.data.frame(auths) || nrow(auths) == 0) return(NA_character_)
    paste(vapply(seq_len(nrow(auths)), function(j) {
      tryCatch(auths$meta$author$name[j] %||% NA_character_,
               error = function(e) NA_character_)
    }, character(1)), collapse = "; ")
  }, character(1))

  tibble(
    id = as.character(df$id),
    title = as.character(df$title),
    sti_type = as.character(df$stiType),
    distribution = as.character(df$distribution),
    created = tryCatch(as.Date(substr(df$created, 1, 10)),
                       error = function(e) rep(as.Date(NA), nrow(df))),
    authors = auth_strs
  )
}


# == Context ===================================================================

#' Generate LLM-friendly context for nasa.gov
#'
#' @return Character string with full function signatures and bodies
nasa_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/nasa.gov.R"
  if (!file.exists(src_file)) {
    cat("# nasa.gov context - source not found\n")
    return(invisible("# nasa.gov context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

