# norges-bank.no.R - Self-contained norges-bank.no client


`%||%` <- function(a, b) if (is.null(a)) b else a

.ua <- "support@scrapeable.com"
.nb_base <- "https://data.norges-bank.no/api/data"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE)

#' Get Norges Bank exchange rates
#' @param currency Currency code (e.g. 'USD', 'EUR')
#' @param frequency 'B' for business daily, 'M' for monthly
#' @return tibble of exchange rates
nb_exchange_rates <- function(currency = "USD", frequency = "B") {
  url <- sprintf("%s/EXR/%s.%s.NOK.SP?format=sdmx-json&lastNObservations=100",
                 .nb_base, frequency, currency)
  raw <- .fetch_json(url)
  ds <- raw$data$dataSets
  if (length(ds) == 0 || length(ds[[1]]$series) == 0) return(tibble::tibble(date = character(), value = numeric()))
  obs <- ds[[1]]$series[[1]]$observations
  if (length(obs) == 0) return(tibble::tibble(date = character(), value = numeric()))
  dims <- raw$data$structure$dimensions$observation
  time_vals <- dims[[1]]$values
  tibble::tibble(
    date = vapply(seq_along(obs), function(i) {
      idx <- as.integer(names(obs)[i]) + 1
      if (idx <= length(time_vals)) time_vals[[idx]]$id else NA_character_
    }, character(1)),
    value = vapply(obs, function(x) as.numeric(x[[1]]), numeric(1)),
    currency = currency
  )
}

#' Get Norges Bank key policy rate
#' @return tibble of key policy rates
nb_policy_rate <- function() {
  url <- sprintf("%s/IR/B..KPRA?format=sdmx-json&lastNObservations=50", .nb_base)
  raw <- .fetch_json(url)
  ds <- raw$data$dataSets
  if (length(ds) == 0 || length(ds[[1]]$series) == 0) return(tibble::tibble(date = character(), rate = numeric()))
  obs <- ds[[1]]$series[[1]]$observations
  dims <- raw$data$structure$dimensions$observation
  time_vals <- dims[[1]]$values
  tibble::tibble(
    date = vapply(seq_along(obs), function(i) {
      idx <- as.integer(names(obs)[i]) + 1
      if (idx <= length(time_vals)) time_vals[[idx]]$id else NA_character_
    }, character(1)),
    rate = vapply(obs, function(x) as.numeric(x[[1]]), numeric(1))
  )
}

#' Get multiple Norges Bank exchange rates
#'
#' Returns recent exchange rates for multiple currencies against NOK.
#'
#' @param currencies Character vector of currency codes (default: c("USD", "EUR", "GBP"))
#' @param n Last N observations (default 20)
#' @return tibble: date, value, currency
nb_multi_rates <- function(currencies = c("USD", "EUR", "GBP"), n = 20) {
  schema <- tibble(date = character(), value = numeric(), currency = character())
  results <- lapply(currencies, function(cur) {
    tryCatch(nb_exchange_rates(cur, frequency = "B"), error = function(e) schema)
  })
  bind_rows(results)
}

# == Context ===================================================================

#' Generate LLM-friendly context for norges-bank.no
#'
#' @return Character string with full function signatures and bodies
nb_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/norges-bank.no.R"
  if (!file.exists(src_file)) {
    cat("# norges-bank.no context - source not found\n")
    return(invisible("# norges-bank.no context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

