# encodeproject.org.R - Self-contained encodeproject.org client



# encodeproject-org.R
# Self-contained ENCODE Project API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required
# Rate limits: be polite (no official limit published)


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.encode_base <- "https://www.encodeproject.org"

`%||%` <- function(a, b) if (is.null(a)) b else a
# -- Fetch helpers -------------------------------------------------------------

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua, Accept = "application/json") |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE)

# == Schemas ===================================================================

.schema_search <- tibble(
  accession = character(), type = character(), description = character(),
  assay_title = character(), biosample_summary = character(),
  lab = character(), status = character(), date_released = as.Date(character())
)

.schema_experiment <- tibble(
  accession = character(), type = character(), description = character(),
  assay_title = character(), biosample_summary = character(),
  target = character(), lab = character(), status = character(),
  date_released = as.Date(character()), files_count = integer()
)

.schema_files <- tibble(
  accession = character(), file_format = character(),
  output_type = character(), assembly = character(),
  file_size = numeric(), href = character(), status = character()
)

# == Search ====================================================================


#' Search ENCODE experiments and other objects
#'
#' Full-text search across the ENCODE portal. Returns experiments,
#' biosamples, antibodies, and other object types.
#'
#' @param type Object type: "Experiment", "Biosample", "AntibodyLot",
#'   "GeneticModification", etc. (default "Experiment")
#' @param query Free-text search query (e.g. "CTCF", "ChIP-seq")
#' @param assay Assay type (e.g. "ChIP-seq", "RNA-seq", "ATAC-seq")
#' @param organism Organism (e.g. "Homo sapiens", "Mus musculus")
#' @param limit Max results (default 25, max 200)
#' @return tibble: accession, type, description, assay_title,
#'   biosample_summary, lab, status, date_released
encode_search <- function(type = "Experiment", query = NULL, assay = NULL,
                          organism = NULL, limit = 25) {
  params <- list(
    type = type,
    searchTerm = query,
    assay_title = assay,
    replicates.library.biosample.donor.organism.scientific_name = organism,
    limit = as.integer(limit),
    format = "json"
  )
  params <- params[!vapply(params, is.null, logical(1))]
  query_str <- paste(names(params), utils::URLencode(as.character(params), reserved = TRUE),
                     sep = "=", collapse = "&")
  url <- sprintf("%s/search/?%s", .encode_base, query_str)
  raw <- .fetch_json(url)
  g <- raw[["@graph"]]
  if (is.null(g) || length(g) == 0) return(.schema_search)

  rows <- lapply(g, function(x) {
    tibble(
      accession = as.character(x$accession %||% NA),
      type = as.character(if (!is.null(x[["@type"]])) x[["@type"]][1] else NA),
      description = as.character(x$description %||% NA),
      assay_title = as.character(x$assay_title %||% NA),
      biosample_summary = as.character(x$biosample_summary %||% NA),
      lab = as.character(if (!is.null(x$lab)) x$lab$title %||% x$lab else NA),
      status = as.character(x$status %||% NA),
      date_released = tryCatch(as.Date(x$date_released %||% NA_character_), error = function(e) as.Date(NA))
    )
  })
  bind_rows(rows)
}

# == Experiment detail =========================================================

#' Fetch a single ENCODE experiment by accession
#'
#' @param accession ENCODE accession (e.g. "ENCSR000AEG")
#' @return tibble: one row with accession, type, description, assay_title,
#'   biosample_summary, target, lab, status, date_released, files_count
encode_experiment <- function(accession) {
  url <- sprintf("%s/experiments/%s/?format=json", .encode_base, accession)
  x <- .fetch_json(url)
  if (is.null(x) || is.null(x$accession)) return(.schema_experiment)

  tibble(
    accession = as.character(x$accession),
    type = as.character(if (!is.null(x[["@type"]])) x[["@type"]][1] else NA),
    description = as.character(x$description %||% NA),
    assay_title = as.character(x$assay_title %||% NA),
    biosample_summary = as.character(x$biosample_summary %||% NA),
    target = as.character(if (!is.null(x$target)) x$target$label %||% x$target else NA),
    lab = as.character(if (!is.null(x$lab)) x$lab$title %||% x$lab else NA),
    status = as.character(x$status %||% NA),
    date_released = tryCatch(as.Date(x$date_released %||% NA_character_), error = function(e) as.Date(NA)),
    files_count = as.integer(length(x$files %||% list()))
  )
}

# == Experiment files ==========================================================

#' List files for an ENCODE experiment
#'
#' @param accession ENCODE experiment accession
#' @param file_format Filter by format: "bam", "bigWig", "fastq", "bed", etc.
#' @return tibble: accession, file_format, output_type, assembly, file_size, href, status
encode_files <- function(accession, file_format = NULL) {
  params <- list(
    type = "File",
    dataset = sprintf("/experiments/%s/", accession),
    limit = "all",
    format = "json"
  )
  if (!is.null(file_format)) params$file_format <- file_format
  query_str <- paste(names(params), utils::URLencode(as.character(params), reserved = TRUE),
                     sep = "=", collapse = "&")
  url <- sprintf("%s/search/?%s", .encode_base, query_str)
  raw <- .fetch_json(url)
  g <- raw[["@graph"]]
  if (is.null(g) || length(g) == 0) return(.schema_files)

  rows <- lapply(g, function(x) {
    tibble(
      accession = as.character(x$accession %||% NA),
      file_format = as.character(x$file_format %||% NA),
      output_type = as.character(x$output_type %||% NA),
      assembly = as.character(x$assembly %||% NA),
      file_size = as.numeric(x$file_size %||% NA),
      href = as.character(x$href %||% NA),
      status = as.character(x$status %||% NA)
    )
  })
  bind_rows(rows)
}

# == Biosamples ================================================================

#' Search ENCODE biosamples
#'
#' @param organism Organism (e.g. "Homo sapiens", "Mus musculus")
#' @param query Free-text search query
#' @param limit Max results (default 25)
#' @return tibble: accession, biosample_type, organism, summary, source, status
encode_biosamples <- function(organism = "Homo sapiens", query = NULL, limit = 25) {
  schema <- tibble(accession = character(), biosample_type = character(),
                   organism = character(), summary = character(),
                   source = character(), status = character())
  params <- list(
    type = "Biosample",
    `organism.scientific_name` = organism,
    searchTerm = query,
    limit = as.integer(limit),
    format = "json"
  )
  params <- params[!vapply(params, is.null, logical(1))]
  query_str <- paste(names(params), utils::URLencode(as.character(params), reserved = TRUE),
                     sep = "=", collapse = "&")
  url <- sprintf("%s/search/?%s", .encode_base, query_str)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(schema)
  g <- raw[["@graph"]]
  if (is.null(g) || length(g) == 0) return(schema)

  rows <- lapply(g, function(x) {
    tibble(
      accession = as.character(x$accession %||% NA),
      biosample_type = as.character(if (!is.null(x$biosample_ontology)) x$biosample_ontology$classification %||% NA else NA),
      organism = as.character(if (!is.null(x$organism)) x$organism$scientific_name %||% NA else NA),
      summary = as.character(x$summary %||% NA),
      source = as.character(if (!is.null(x$source)) x$source$title %||% x$source else NA),
      status = as.character(x$status %||% NA)
    )
  })
  bind_rows(rows)
}

# == Context ===================================================================

#' Generate LLM-friendly context for encodeproject.org
#'
#' @return Character string with full function signatures and bodies
encode_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/encodeproject.org.R"
  if (!file.exists(src_file)) {
    cat("# encodeproject.org context - source not found\n")
    return(invisible("# encodeproject.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

