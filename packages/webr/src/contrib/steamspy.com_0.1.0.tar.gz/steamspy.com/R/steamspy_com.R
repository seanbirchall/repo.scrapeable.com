# steamspy.com.R - Self-contained steamspy.com client



# steamspy-com.R
# Self-contained SteamSpy API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none
# Rate limits: 4 requests per second


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.steam_base <- "https://steamspy.com/api.php"

`%||%` <- function(a, b) if (is.null(a) || length(a) == 0 || identical(a, "")) b else a

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE)

# -- Parser for named-list (top100/genre) responses ---------------------------

.parse_app_list <- function(raw) {
  if (is.null(raw) || length(raw) == 0) return(.schema_app)
  rows <- lapply(raw, function(x) {
    tibble(
      appid          = as.integer(x$appid %||% NA),
      name           = as.character(x$name %||% NA),
      developer      = as.character(x$developer %||% NA),
      publisher      = as.character(x$publisher %||% NA),
      positive       = as.integer(x$positive %||% NA),
      negative       = as.integer(x$negative %||% NA),
      owners         = as.character(x$owners %||% NA),
      average_forever = as.integer(x$average_forever %||% NA),
      average_2weeks = as.integer(x$average_2weeks %||% NA),
      price          = as.integer(x$price %||% NA),
      initialprice   = as.integer(x$initialprice %||% NA),
      discount       = as.integer(x$discount %||% NA),
      ccu            = as.integer(x$ccu %||% NA)
    )
  })
  bind_rows(rows)
}

# == Schemas ===================================================================

.schema_app <- tibble(
  appid = integer(), name = character(), developer = character(),
  publisher = character(), positive = integer(), negative = integer(),
  owners = character(), average_forever = integer(),
  average_2weeks = integer(), price = integer(),
  initialprice = integer(), discount = integer(), ccu = integer()
)

.schema_app_detail <- tibble(
  appid = integer(), name = character(), developer = character(),
  publisher = character(), positive = integer(), negative = integer(),
  owners = character(), average_forever = integer(),
  average_2weeks = integer(), median_forever = integer(),
  median_2weeks = integer(), price = integer(), initialprice = integer(),
  discount = integer(), ccu = integer(), genre = character(),
  languages = character()
)


# == Public functions ==========================================================

#' Get detailed information for a Steam app
#'
#' @param appid Steam application ID (e.g. 730 for CS:GO, 570 for Dota 2)
#' @return tibble with one row: appid, name, developer, publisher, positive,
#'   negative, owners, average_forever, average_2weeks, median_forever,
#'   median_2weeks, price, initialprice, discount, ccu, genre, languages
steam_app <- function(appid) {
  url <- sprintf("%s?request=appdetails&appid=%s", .steam_base, appid)
  raw <- .fetch_json(url)
  if (is.null(raw) || length(raw) == 0) return(.schema_app_detail)

  tibble(
    appid          = as.integer(raw$appid %||% NA),
    name           = as.character(raw$name %||% NA),
    developer      = as.character(raw$developer %||% NA),
    publisher      = as.character(raw$publisher %||% NA),
    positive       = as.integer(raw$positive %||% NA),
    negative       = as.integer(raw$negative %||% NA),
    owners         = as.character(raw$owners %||% NA),
    average_forever = as.integer(raw$average_forever %||% NA),
    average_2weeks = as.integer(raw$average_2weeks %||% NA),
    median_forever = as.integer(raw$median_forever %||% NA),
    median_2weeks  = as.integer(raw$median_2weeks %||% NA),
    price          = as.integer(raw$price %||% NA),
    initialprice   = as.integer(raw$initialprice %||% NA),
    discount       = as.integer(raw$discount %||% NA),
    ccu            = as.integer(raw$ccu %||% NA),
    genre          = as.character(raw$genre %||% NA),
    languages      = as.character(raw$languages %||% NA)
  )
}

#' Get top 100 games by current players in last 2 weeks
#'
#' @return tibble: appid, name, developer, publisher, positive, negative,
#'   owners, average_forever, average_2weeks, price, initialprice, discount, ccu
steam_top100 <- function() {
  url <- sprintf("%s?request=top100in2weeks", .steam_base)
  raw <- .fetch_json(url)
  .parse_app_list(raw)
}

#' Get games by genre
#'
#' @param genre Genre name (e.g. "Action", "RPG", "Strategy", "Indie",
#'   "Adventure", "Simulation", "Racing", "Sports")
#' @return tibble: appid, name, developer, publisher, positive, negative,
#'   owners, average_forever, average_2weeks, price, initialprice, discount, ccu
steam_genre <- function(genre) {
  url <- sprintf("%s?request=genre&genre=%s", .steam_base,
                 utils::URLencode(genre, reserved = TRUE))
  raw <- .fetch_json(url)
  .parse_app_list(raw)
}

# == Context ===================================================================

#' Generate LLM-friendly context for the steamspy.com package
#'
#' @return Character string (invisibly), also printed
steam_context <- function() {
  .build_context("steamspy.com", header_lines = c(
    "# steamspy.com - SteamSpy Game Statistics Client for R",
    "# Dependencies: httr2, jsonlite, dplyr, tibble",
    "# Auth: none",
    "# Rate limit: 4 requests per second",
    "# All functions return tibbles with typed columns.",
    "#",
    "# Common appids: 730 (CS:GO), 570 (Dota 2), 440 (TF2),",
    "#   578080 (PUBG), 271590 (GTA V), 1172470 (Apex Legends)",
    "# Genres: Action, RPG, Strategy, Indie, Adventure, Simulation,",
    "#   Racing, Sports, Free To Play, Early Access"
  ))
}

# == Context ===================================================================

#' Generate LLM-friendly context for steamspy.com
#'
#' @return Character string with full function signatures and bodies
steamspy_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/steamspy.com.R"
  if (!file.exists(src_file)) {
    cat("# steamspy.com context - source not found\n")
    return(invisible("# steamspy.com context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

