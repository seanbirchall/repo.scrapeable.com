# == Public functions ==========================================================

#' List executive orders from the Federal Register
#'
#' @param president President slug: "donald-trump", "joe-biden", "barack-obama",
#'   "george-w-bush", "william-j-clinton". Default NULL returns all.
#' @param per_page Results per page (max 1000). Default 100.
#' @param page Page number. Default 1.
#' @param year Optional signing year filter (integer).
#' @return tibble: eo_number, title, signing_date, publication_date,
#'   citation, document_number, president, html_url, pdf_url
#' @export
usag_executive_orders <- function(president = NULL, per_page = 100, page = 1, year = NULL) {
  fields <- c("title", "executive_order_number", "signing_date",
               "publication_date", "citation", "document_number",
               "html_url", "pdf_url")
  field_params <- paste0("fields%5B%5D=", fields, collapse = "&")

  url <- sprintf(
    "%s/documents.json?conditions%%5Bpresidential_document_type%%5D=executive_order&conditions%%5Btype%%5D=PRESDOCU&%s&per_page=%d&page=%d&order=executive_order",
    .usag_fr_base, field_params, as.integer(min(per_page, 1000)), as.integer(page)
  )

  if (!is.null(president)) {
    url <- paste0(url, "&conditions%5Bpresident%5D=", utils::URLencode(president))
  }

  if (!is.null(year)) {
    url <- paste0(url, "&conditions%5Bsigning_date%5D%5Byear%5D=", as.integer(year))
  }

  raw <- tryCatch(.usag_fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_eo)

  pres_label <- president %||% NA_character_
  out <- .parse_eo_results(raw$results, president = pres_label)

  attr(out, "count") <- raw$count %||% NA_integer_
  attr(out, "total_pages") <- raw$total_pages %||% NA_integer_
  out
}

#' Get all executive orders for a president (auto-paginates)
#'
#' @param president President slug (required)
#' @param year Optional signing year filter
#' @return tibble: all executive orders for the given president
#' @export
usag_all_executive_orders <- function(president, year = NULL) {
  page <- 1
  all_results <- list()

  repeat {
    chunk <- usag_executive_orders(president = president, per_page = 1000, page = page, year = year)
    if (nrow(chunk) == 0) break
    all_results[[page]] <- chunk
    total_pages <- attr(chunk, "total_pages") %||% 1
    if (page >= total_pages) break
    page <- page + 1
  }

  if (length(all_results) == 0) return(.schema_eo)
  bind_rows(all_results)
}

#' Real-time analytics for all U.S. government websites
#'
#' @return tibble with one row: active_users, pageviews, taken_at
#' @export
usag_realtime <- function() {
  url <- sprintf("%s/realtime.json", .usag_analytics_base)
  raw <- tryCatch(.usag_fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$data)) return(.schema_realtime)

  d <- raw$data
  if (is.data.frame(d)) {
    au <- as.integer(d$activeUsers[1] %||% NA)
    pv <- as.integer(d$pageviews[1] %||% NA)
  } else if (is.list(d) && length(d) > 0) {
    au <- as.integer(d[[1]]$activeUsers %||% d[[1]][["activeUsers"]] %||% NA)
    pv <- as.integer(d[[1]]$pageviews %||% d[[1]][["pageviews"]] %||% NA)
  } else {
    return(.schema_realtime)
  }

  tibble(
    active_users = au,
    pageviews = pv,
    taken_at = as.character(raw$taken_at %||% NA_character_)
  )
}

#' Top pages being viewed right now on government websites
#'
#' @return tibble: page_title, active_users
#' @export
usag_top_pages <- function() {
  url <- sprintf("%s/top-pages-realtime.json", .usag_analytics_base)
  raw <- tryCatch(.usag_fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$data) || length(raw$data) == 0) return(.schema_top_pages)

  items <- raw$data
  tibble(
    page_title = as.character(items$page_title %||% NA_character_),
    active_users = as.integer(items$activeUsers %||% NA_integer_)
  )
}

#' Top government domains by visits (30-day window)
#'
#' @return tibble: domain, visits
#' @export
usag_top_domains <- function() {
  url <- sprintf("%s/top-domains-30-days.json", .usag_analytics_base)
  raw <- tryCatch(.usag_fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$data) || length(raw$data) == 0) return(.schema_top_domains)

  items <- raw$data
  tibble(
    domain = as.character(items$domain %||% NA_character_),
    visits = as.numeric(items$visits %||% NA_real_)
  )
}

#' All government domains with traffic stats (30-day window)
#'
#' @return tibble: domain, visits, pageviews, users, pageviews_per_session, avg_session_duration
#' @export
usag_all_domains <- function() {
  url <- sprintf("%s/all-domains-30-days.json", .usag_analytics_base)
  raw <- tryCatch(.usag_fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$data) || length(raw$data) == 0) return(.schema_all_domains)

  items <- raw$data
  tibble(
    domain = as.character(items$domain %||% NA_character_),
    visits = as.numeric(items$visits %||% NA_real_),
    pageviews = as.numeric(items$pageviews %||% NA_real_),
    users = as.numeric(items$users %||% NA_real_),
    pageviews_per_session = as.numeric(items$pageviews_per_session %||% NA_real_),
    avg_session_duration = as.numeric(items$avg_session_duration %||% NA_real_)
  )
}

#' Government sites with visit counts
#'
#' @return tibble: domain, visits
#' @export
usag_sites <- function() {
  url <- sprintf("%s/sites.json", .usag_analytics_base)
  raw <- tryCatch(.usag_fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$data) || length(raw$data) == 0) {
    return(tibble(domain = character(), visits = numeric()))
  }

  items <- raw$data
  tibble(
    domain = as.character(items$domain %||% NA_character_),
    visits = as.numeric(items$visits %||% NA_real_)
  )
}

#' List available data categories
#'
#' @return tibble: category, description, endpoint
#' @export
usag_list <- function() {
  tibble(
    category = c("executive_orders", "realtime", "top_pages", "top_domains",
                  "all_domains", "sites"),
    description = c(
      "Executive orders from Federal Register (all presidents since Clinton)",
      "Real-time active users and pageviews across all .gov sites",
      "Top 30 pages being viewed right now",
      "Top 30 government domains by visits (30 days)",
      "All government domains with traffic metrics (30 days)",
      "All government sites with visit counts"
    ),
    endpoint = c(
      "federalregister.gov/api/v1/documents",
      "analytics.usa.gov/data/live/realtime.json",
      "analytics.usa.gov/data/live/top-pages-realtime.json",
      "analytics.usa.gov/data/live/top-domains-30-days.json",
      "analytics.usa.gov/data/live/all-domains-30-days.json",
      "analytics.usa.gov/data/live/sites.json"
    )
  )
}

#' Search executive orders by keyword
#'
#' @param query Search query string
#' @param president Optional president slug to narrow results
#' @param per_page Results per page. Default 20.
#' @return tibble: eo_number, title, signing_date, publication_date,
#'   citation, document_number, president, html_url, pdf_url
#' @export
usag_search <- function(query, president = NULL, per_page = 20) {
  fields <- c("title", "executive_order_number", "signing_date",
               "publication_date", "citation", "document_number",
               "html_url", "pdf_url")
  field_params <- paste0("fields%5B%5D=", fields, collapse = "&")

  url <- sprintf(
    "%s/documents.json?conditions%%5Bpresidential_document_type%%5D=executive_order&conditions%%5Btype%%5D=PRESDOCU&conditions%%5Bterm%%5D=%s&%s&per_page=%d&order=relevance",
    .usag_fr_base,
    utils::URLencode(query, reserved = TRUE),
    field_params,
    as.integer(per_page)
  )

  if (!is.null(president)) {
    url <- paste0(url, "&conditions%5Bpresident%5D=", utils::URLencode(president))
  }

  raw <- tryCatch(.usag_fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_eo)

  pres_label <- president %||% NA_character_
  .parse_eo_results(raw$results, president = pres_label)
}

#' Generate LLM-friendly context for usa.gov
#'
#' @return Character string with full function signatures and bodies
#' @export
usag_context <- function() {
  .build_context(
    pkg_name = "usa.gov",
    header_lines = c(
      "# usa.gov R client",
      "# Federal Register executive orders + analytics.usa.gov website analytics",
      "# Auth: none (all public)",
      "# Prefix: usag_"
    )
  )
}
