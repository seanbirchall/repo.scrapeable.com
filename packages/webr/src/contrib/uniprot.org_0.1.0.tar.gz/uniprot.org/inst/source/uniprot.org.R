# uniprot.org.R - Self-contained uniprot.org client

library(httr2)
library(jsonlite)
library(tibble)



.ua <- "support@scrapeable.com"

.fetch_json <- function(url) {
  tmp <- tempfile(fileext = ".json")
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  jsonlite::fromJSON(tmp, simplifyVector = FALSE)
}


.base <- "https://rest.uniprot.org/uniprotkb"

#' Search UniProt proteins
#' @param query Search term (gene name, protein name, etc.)
#' @param size Number of results (default 25)
#' @return tibble of matching proteins
uniprot_search <- function(query, size = 25L) {
  url <- sprintf("%s/search?query=%s&size=%d&format=json", .base, URLencode(query, TRUE), size)
  raw <- .fetch_json(url)
  results <- raw$results
  if (length(results) == 0) return(tibble::tibble(accession = character(), id = character(), protein_name = character()))
  tibble::tibble(
    accession = vapply(results, function(x) x$primaryAccession %||% NA_character_, character(1)),
    id = vapply(results, function(x) x$uniProtkbId %||% NA_character_, character(1)),
    protein_name = vapply(results, function(x) tryCatch(x$proteinDescription$recommendedName$fullName$value, error = function(e) NA_character_), character(1)),
    organism = vapply(results, function(x) tryCatch(x$organism$scientificName, error = function(e) NA_character_), character(1)),
    length = vapply(results, function(x) x$sequence$length %||% NA_integer_, integer(1))
  )
}

#' Get a specific UniProt entry
#' @param accession UniProt accession (e.g. 'P53_HUMAN')
#' @return tibble with protein details
uniprot_entry <- function(accession) {
  url <- sprintf("%s/%s.json", .base, accession)
  raw <- .fetch_json(url)
  tibble::tibble(
    accession = raw$primaryAccession %||% NA_character_,
    id = raw$uniProtkbId %||% NA_character_,
    protein_name = tryCatch(raw$proteinDescription$recommendedName$fullName$value, error = function(e) NA_character_),
    organism = tryCatch(raw$organism$scientificName, error = function(e) NA_character_),
    length = raw$sequence$length %||% NA_integer_
  )
}

# == Context ===================================================================

#' Generate LLM-friendly context for uniprot.org
#'
#' @return Character string with full function signatures and bodies
uniprot_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/uniprot.org.R"
  if (!file.exists(src_file)) {
    cat("# uniprot.org context - source not found\n")
    return(invisible("# uniprot.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

