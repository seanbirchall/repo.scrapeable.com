# dblp.org.R - Self-contained dblp.org client



# dblp-org.R
# Self-contained DBLP computer science bibliography API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required
# Rate limits: be polite, no official limit


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.dblp_base <- "https://dblp.org"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE)


# == Schemas ===================================================================

.schema_publications <- tibble(
  key = character(), title = character(), venue = character(),
  year = integer(), type = character(), doi = character(),
  url = character(), authors = character()
)

.schema_authors <- tibble(
  name = character(), pid = character(), url = character(), notes = character()
)

# == Public functions ==========================================================

#' Search DBLP publications
#'
#' @param query Search query string
#' @param hits Maximum results to return (default 30, max 1000)
#' @param offset Starting position (default 0)
#' @return tibble: key, title, venue, year, type, doi, url, authors
dblp_publications <- function(query, hits = 30, offset = 0) {
  url <- sprintf("%s/search/publ/api?q=%s&format=json&h=%d&f=%d",
                 .dblp_base, utils::URLencode(query), hits, offset)
  raw <- .fetch_json(url)
  hit_list <- raw$result$hits$hit
  if (is.null(hit_list) || length(hit_list) == 0) return(.schema_publications)

  rows <- lapply(hit_list, function(h) {
    info <- h$info
    authors_raw <- info$authors$author
    if (is.null(authors_raw)) {
      auth_str <- NA_character_
    } else if (is.list(authors_raw) && !is.null(authors_raw$text)) {
      auth_str <- authors_raw$text
    } else {
      auth_str <- paste(vapply(authors_raw, function(a) a$text %||% NA_character_, character(1)), collapse = "; ")
    }
    tibble(
      key = as.character(info$key %||% NA),
      title = as.character(info$title %||% NA),
      venue = as.character(info$venue %||% NA),
      year = as.integer(info$year %||% NA),
      type = as.character(info$type %||% NA),
      doi = as.character(info$doi %||% NA),
      url = as.character(info$url %||% NA),
      authors = auth_str
    )
  })
  bind_rows(rows)
}

#' Search DBLP authors
#'
#' @param query Author name search query
#' @param hits Maximum results (default 30)
#' @return tibble: name, pid, url, notes
dblp_authors <- function(query, hits = 30) {
  url <- sprintf("%s/search/author/api?q=%s&format=json&h=%d",
                 .dblp_base, utils::URLencode(query), hits)
  raw <- .fetch_json(url)
  hit_list <- raw$result$hits$hit
  if (is.null(hit_list) || length(hit_list) == 0) return(.schema_authors)

  rows <- lapply(hit_list, function(h) {
    info <- h$info
    tibble(
      name = as.character(info$author %||% NA),
      pid = as.character(info$url %||% NA),
      url = as.character(h$url %||% NA),
      notes = as.character(info$notes$note$text %||% NA)
    )
  })
  bind_rows(rows)
}

#' Search DBLP venues (conferences/journals)
#'
#' @param query Venue name search query
#' @param hits Maximum results (default 30)
#' @return tibble: name, acronym, type, url
dblp_venues <- function(query, hits = 30) {
  url <- sprintf("%s/search/venue/api?q=%s&format=json&h=%d",
                 .dblp_base, utils::URLencode(query), hits)
  raw <- .fetch_json(url)
  hit_list <- raw$result$hits$hit
  if (is.null(hit_list) || length(hit_list) == 0) {
    return(tibble(name = character(), acronym = character(),
                  type = character(), url = character()))
  }
  rows <- lapply(hit_list, function(h) {
    info <- h$info
    tibble(
      name = as.character(info$venue %||% NA),
      acronym = as.character(info$acronym %||% NA),
      type = as.character(info$type %||% NA),
      url = as.character(info$url %||% NA)
    )
  })
  bind_rows(rows)
}
`%||%` <- function(x, y) if (is.null(x)) y else x

# == Context ===================================================================

#' Generate LLM-friendly context for dblp.org
#'
#' @return Character string with full function signatures and bodies
dblp_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/dblp.org.R"
  if (!file.exists(src_file)) {
    cat("# dblp.org context - source not found\n")
    return(invisible("# dblp.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

