# huggingface.co.R - Self-contained huggingface.co client



# huggingface.R
# Self-contained HuggingFace Hub API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required for public endpoints
# Rate limits: generous


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.hf_base <- "https://huggingface.co/api"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = TRUE)

# == Schemas ===================================================================

.schema_models <- tibble(
  id = character(), author = character(), sha = character(),
  pipeline_tag = character(), downloads = integer(), likes = integer(),
  last_modified = character()
)

.schema_datasets <- tibble(
  id = character(), author = character(), sha = character(),
  downloads = integer(), likes = integer(), last_modified = character()
)

.schema_model_detail <- tibble(
  id = character(), author = character(), pipeline_tag = character(),
  downloads = integer(), likes = integer(), library_name = character(),
  tags = character(), last_modified = character()
)


`%||%` <- function(x, y) if (is.null(x)) y else x

# == Public functions ==========================================================

#' Search HuggingFace models
#'
#' @param search Search query (e.g. "bert", "gpt2", "text-generation")
#' @param author Filter by author/organization
#' @param limit Max results (default 30)
#' @return tibble: id, author, sha, pipeline_tag, downloads, likes, last_modified
hf_models <- function(search = NULL, author = NULL, limit = 30) {
  params <- list(search = search, author = author, limit = limit)
  params <- params[!vapply(params, is.null, logical(1))]
  qstr <- paste(names(params), params, sep = "=", collapse = "&")
  url <- paste0(.hf_base, "/models?", qstr)
  raw <- .fetch_json(url)
  if (length(raw) == 0) return(.schema_models)

  tibble(
    id = as.character(raw$id %||% NA_character_),
    author = as.character(raw$author %||% NA_character_),
    sha = as.character(raw$sha %||% NA_character_),
    pipeline_tag = as.character(raw$pipeline_tag %||% NA_character_),
    downloads = as.integer(raw$downloads %||% NA_integer_),
    likes = as.integer(raw$likes %||% NA_integer_),
    last_modified = as.character(raw$lastModified %||% NA_character_)
  )
}

#' Search HuggingFace datasets
#'
#' @param search Search query
#' @param author Filter by author/organization
#' @param limit Max results (default 30)
#' @return tibble: id, author, sha, downloads, likes, last_modified
hf_datasets <- function(search = NULL, author = NULL, limit = 30) {
  params <- list(search = search, author = author, limit = limit)
  params <- params[!vapply(params, is.null, logical(1))]
  qstr <- paste(names(params), params, sep = "=", collapse = "&")
  url <- paste0(.hf_base, "/datasets?", qstr)
  raw <- .fetch_json(url)
  if (length(raw) == 0) return(.schema_datasets)

  tibble(
    id = as.character(raw$id %||% NA_character_),
    author = as.character(raw$author %||% NA_character_),
    sha = as.character(raw$sha %||% NA_character_),
    downloads = as.integer(raw$downloads %||% NA_integer_),
    likes = as.integer(raw$likes %||% NA_integer_),
    last_modified = as.character(raw$lastModified %||% NA_character_)
  )
}

#' Get details for a specific HuggingFace model
#'
#' @param id Model ID (e.g. "bert-base-uncased", "google/flan-t5-base")
#' @return tibble: one row with id, author, pipeline_tag, downloads, likes,
#'   library_name, tags, last_modified
hf_model <- function(id) {
  url <- paste0(.hf_base, "/models/", id)
  raw <- .fetch_json(url)
  if (length(raw) == 0) return(.schema_model_detail)

  tibble(
    id = as.character(raw$id),
    author = as.character(raw$author %||% NA_character_),
    pipeline_tag = as.character(raw$pipeline_tag %||% NA_character_),
    downloads = as.integer(raw$downloads %||% NA_integer_),
    likes = as.integer(raw$likes %||% NA_integer_),
    library_name = as.character(raw$library_name %||% NA_character_),
    tags = paste(raw$tags %||% character(), collapse = ", "),
    last_modified = as.character(raw$lastModified %||% NA_character_)
  )
}

# == Context ===================================================================

#' Generate LLM-friendly context for huggingface.co
#'
#' @return Character string with full function signatures and bodies
hf_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/huggingface.co.R"
  if (!file.exists(src_file)) {
    cat("# huggingface.co context - source not found\n")
    return(invisible("# huggingface.co context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

