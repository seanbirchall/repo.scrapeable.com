# == Occurrence ================================================================

#' Search GBIF occurrence records
#'
#' @param scientificName Scientific name (e.g. "Puma concolor")
#' @param taxonKey GBIF taxon key (numeric)
#' @param country Two-letter country code (e.g. "US")
#' @param geometry WKT geometry for spatial filter
#' @param year Year or range "2000,2020"
#' @param basisOfRecord Record type (e.g. "HUMAN_OBSERVATION")
#' @param limit Number of records (default 100, max 300)
#' @param offset Pagination offset (default 0)
#' @return tibble: key, scientificName, species, family, order, class, phylum,
#'   kingdom, decimalLatitude, decimalLongitude, country, year, month,
#'   basisOfRecord, datasetName, institutionCode
#' @export
gbif_occurrences <- function(scientificName = NULL, taxonKey = NULL,
                             country = NULL, geometry = NULL,
                             year = NULL, basisOfRecord = NULL,
                             limit = 100, offset = 0) {
  params <- list(
    scientificName = scientificName, taxonKey = taxonKey,
    country = country, geometry = geometry,
    year = year, basisOfRecord = basisOfRecord,
    limit = min(limit, 300), offset = offset
  )
  url <- .build_url("/occurrence/search", params)
  res <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(res) || length(res$results) == 0) return(.schema_occurrence)

  d <- res$results
  tibble(
    key = as.numeric(.safe_col(d, "key", NA_real_)),
    scientificName = as.character(.safe_col(d, "scientificName")),
    species = as.character(.safe_col(d, "species")),
    family = as.character(.safe_col(d, "family")),
    order = as.character(.safe_col(d, "order")),
    class = as.character(.safe_col(d, "class")),
    phylum = as.character(.safe_col(d, "phylum")),
    kingdom = as.character(.safe_col(d, "kingdom")),
    decimalLatitude = as.numeric(.safe_col(d, "decimalLatitude", NA_real_)),
    decimalLongitude = as.numeric(.safe_col(d, "decimalLongitude", NA_real_)),
    country = as.character(.safe_col(d, "country")),
    year = as.integer(.safe_col(d, "year", NA_integer_)),
    month = as.integer(.safe_col(d, "month", NA_integer_)),
    basisOfRecord = as.character(.safe_col(d, "basisOfRecord")),
    datasetName = as.character(.safe_col(d, "datasetName")),
    institutionCode = as.character(.safe_col(d, "institutionCode"))
  )
}

# == Species / Taxonomy ========================================================

#' Search GBIF species/taxonomy
#'
#' @param q Search query (e.g. "Puma")
#' @param rank Taxonomic rank filter (e.g. "SPECIES", "GENUS")
#' @param kingdom Kingdom filter (e.g. "Animalia")
#' @param limit Number of results (default 20, max 100)
#' @return tibble: key, scientificName, canonicalName, rank, taxonomicStatus,
#'   kingdom, phylum, class, order, family, genus, numOccurrences
#' @export
gbif_species <- function(q, rank = NULL, kingdom = NULL, limit = 20) {
  params <- list(q = q, rank = rank, kingdom = kingdom, limit = min(limit, 100))
  url <- .build_url("/species/search", params)
  res <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(res) || length(res$results) == 0) return(.schema_species)

  d <- res$results
  tibble(
    key = as.integer(.safe_col(d, "key", NA_integer_)),
    scientificName = as.character(.safe_col(d, "scientificName")),
    canonicalName = as.character(.safe_col(d, "canonicalName")),
    rank = as.character(.safe_col(d, "rank")),
    taxonomicStatus = as.character(.safe_col(d, "taxonomicStatus")),
    kingdom = as.character(.safe_col(d, "kingdom")),
    phylum = as.character(.safe_col(d, "phylum")),
    class = as.character(.safe_col(d, "class")),
    order = as.character(.safe_col(d, "order")),
    family = as.character(.safe_col(d, "family")),
    genus = as.character(.safe_col(d, "genus")),
    numOccurrences = as.integer(.safe_col(d, "numOccurrences", NA_integer_))
  )
}

#' Look up a single GBIF species by taxon key
#'
#' @param taxonKey GBIF taxon key (numeric)
#' @return tibble with one row: key, scientificName, canonicalName, rank,
#'   taxonomicStatus, kingdom, phylum, class, order, family, genus
#' @export
gbif_species_lookup <- function(taxonKey) {
  url <- paste0(.gbif_base, "/species/", taxonKey)
  d <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(d)) return(.schema_species[0, ])

  tibble(
    key = as.integer(d$key %||% NA_integer_),
    scientificName = as.character(d$scientificName %||% NA_character_),
    canonicalName = as.character(d$canonicalName %||% NA_character_),
    rank = as.character(d$rank %||% NA_character_),
    taxonomicStatus = as.character(d$taxonomicStatus %||% NA_character_),
    kingdom = as.character(d$kingdom %||% NA_character_),
    phylum = as.character(d$phylum %||% NA_character_),
    class = as.character(d$class %||% NA_character_),
    order = as.character(d$order %||% NA_character_),
    family = as.character(d$family %||% NA_character_),
    genus = as.character(d$genus %||% NA_character_),
    numOccurrences = NA_integer_
  )
}

# == Datasets ==================================================================

#' Search GBIF datasets
#'
#' @param q Search query
#' @param type Dataset type: "OCCURRENCE", "CHECKLIST", "METADATA", "SAMPLING_EVENT"
#' @param publishingCountry Two-letter country code
#' @param limit Number of results (default 20, max 100)
#' @param offset Pagination offset (default 0)
#' @return tibble: key, title, type, description, publishingCountry, license, recordCount
#' @export
gbif_datasets <- function(q = NULL, type = NULL, publishingCountry = NULL,
                          limit = 20, offset = 0) {
  params <- list(q = q, type = type, publishingCountry = publishingCountry,
                 limit = min(limit, 100), offset = offset)
  url <- .build_url("/dataset/search", params)
  res <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(res) || length(res$results) == 0) return(.schema_dataset)

  d <- res$results
  tibble(
    key = as.character(.safe_col(d, "key")),
    title = as.character(.safe_col(d, "title")),
    type = as.character(.safe_col(d, "type")),
    description = as.character(.safe_col(d, "description")),
    publishingCountry = as.character(.safe_col(d, "publishingCountry")),
    license = as.character(.safe_col(d, "license")),
    recordCount = as.integer(.safe_col(d, "recordCount", NA_integer_))
  )
}

# == Context ===================================================================

#' Return the full source of this client for LLM context
#'
#' @return character string of the source file
#' @export
gbif_context <- function() {
  f <- system.file("source", "gbif.org.R", package = "gbif.org", mustWork = FALSE)
  if (f == "") {
    sf <- sys.frame(1)$ofile %||% ""
    if (nzchar(sf)) f <- sf
  }
  if (nzchar(f)) paste(readLines(f, warn = FALSE), collapse = "\n") else
    "Source not found. Load from inst/source/gbif.org.R"
}
