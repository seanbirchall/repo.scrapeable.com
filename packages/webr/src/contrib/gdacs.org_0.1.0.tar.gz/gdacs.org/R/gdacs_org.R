# gdacs.org.R - Self-contained gdacs.org client



# gdacs-org.R
# Self-contained GDACS (Global Disaster Alert and Coordination System) API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required
# Rate limits: unknown (be polite)


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.gdacs_base <- "https://www.gdacs.org/gdacsapi/api/events"

`%||%` <- function(a, b) if (is.null(a)) b else a
# -- Fetch helpers -------------------------------------------------------------

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE)

# == Schemas ===================================================================

.schema_events <- tibble(
  event_id = character(), event_type = character(), name = character(),
  country = character(), alert_level = character(),
  severity = character(), date = as.POSIXct(character()),
  lat = numeric(), lng = numeric(), url = character()
)

# == Events ====================================================================


#' Fetch GDACS disaster events
#'
#' Query the GDACS event list API for natural disasters including
#' earthquakes, tropical cyclones, floods, volcanoes, droughts, and wildfires.
#'
#' @param type Event type code: "EQ" (earthquake), "TC" (tropical cyclone),
#'   "FL" (flood), "VO" (volcano), "DR" (drought), "WF" (wildfire).
#'   Multiple types can be comma-separated (e.g. "EQ,TC").
#' @param from_date Start date (Date or "YYYY-MM-DD")
#' @param to_date End date (Date or "YYYY-MM-DD")
#' @param alert_level Filter by alert level: "Green", "Orange", "Red"
#' @param limit Max results (default 100)
#' @return tibble: event_id, event_type, name, country, alert_level,
#'   severity, date, lat, lng, url
gdacs_events <- function(type = "EQ", from_date = NULL, to_date = NULL,
                         alert_level = NULL, limit = 100) {
  if (is.null(from_date)) from_date <- Sys.Date() - 30
  if (is.null(to_date)) to_date <- Sys.Date()
  url <- sprintf(
    "%s/geteventlist/SEARCH?eventlist=%s&fromDate=%s&toDate=%s&alertlevel=%s&limit=%d",
    .gdacs_base, type,
    format(as.Date(from_date), "%Y-%m-%d"),
    format(as.Date(to_date), "%Y-%m-%d"),
    alert_level %||% "",
    as.integer(limit)
  )
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_events)

  features <- raw$features
  if (is.null(features) || length(features) == 0) return(.schema_events)

  rows <- lapply(features, function(f) {
    p <- f$properties %||% list()
    g <- f$geometry %||% list()
    coords <- g$coordinates %||% list(NA, NA)
    tibble(
      event_id = as.character(p$eventid %||% p$eventId %||% NA),
      event_type = as.character(p$eventtype %||% p$eventType %||% NA),
      name = as.character(p$name %||% p$eventname %||% NA),
      country = as.character(p$country %||% NA),
      alert_level = as.character(p$alertlevel %||% NA),
      severity = as.character(p$severitydata %||% p$severity %||% NA),
      date = tryCatch(
        as.POSIXct(p$fromdate %||% p$eventDate %||% NA, tz = "UTC"),
        error = function(e) as.POSIXct(NA)
      ),
      lat = as.numeric(if (length(coords) >= 2) coords[[2]] else NA),
      lng = as.numeric(if (length(coords) >= 1) coords[[1]] else NA),
      url = as.character(p$url %||% p$link %||% NA)
    )
  })
  result <- bind_rows(rows)
  if (nrow(result) > limit) result <- result[seq_len(limit), ]
  result
}

#' Get a single GDACS event by event ID and type
#'
#' @param event_id Event ID number (e.g. "1000001")
#' @param event_type Event type code: "EQ", "TC", "FL", "VO", "DR", "WF"
#' @return tibble with one row of event details
gdacs_event <- function(event_id, event_type = "EQ") {
  url <- sprintf(
    "%s/geteventdata?eventtype=%s&eventid=%s",
    .gdacs_base, event_type, as.character(event_id)
  )
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_events)

  # Try GeoJSON feature format
  p <- raw$properties %||% raw$Properties %||% list()
  g <- raw$geometry %||% raw$Geometry %||% list()

  if (length(p) == 0 && !is.null(raw$features) && length(raw$features) > 0) {
    p <- raw$features[[1]]$properties %||% list()
    g <- raw$features[[1]]$geometry %||% list()
  }

  if (length(p) == 0) return(.schema_events)

  coords <- g$coordinates %||% list(NA, NA)
  tibble(
    event_id = as.character(p$eventid %||% p$eventId %||% event_id),
    event_type = as.character(p$eventtype %||% p$eventType %||% event_type),
    name = as.character(p$name %||% p$eventname %||% NA),
    country = as.character(p$country %||% NA),
    alert_level = as.character(p$alertlevel %||% NA),
    severity = as.character(p$severitydata %||% p$severity %||% NA),
    date = tryCatch(
      as.POSIXct(p$fromdate %||% p$eventDate %||% NA, tz = "UTC"),
      error = function(e) as.POSIXct(NA)
    ),
    lat = as.numeric(if (length(coords) >= 2) coords[[2]] else NA),
    lng = as.numeric(if (length(coords) >= 1) coords[[1]] else NA),
    url = as.character(p$url %||% p$link %||% NA)
  )
}

#' Get GDACS events summary by type
#'
#' Returns a summary count of recent events grouped by type and alert level.
#'
#' @param days Number of days to look back (default 30)
#' @return tibble: event_type, alert_level, count
gdacs_summary <- function(days = 30) {
  from_date <- Sys.Date() - days
  to_date <- Sys.Date()
  types <- c("EQ", "TC", "FL", "VO", "DR", "WF")

  rows <- lapply(types, function(t) {
    events <- tryCatch(
      gdacs_events(type = t, from_date = from_date, to_date = to_date, limit = 500),
      error = function(e) .schema_events
    )
    if (nrow(events) == 0) return(NULL)
    events |>
      group_by(event_type, alert_level) |>
      summarise(count = n(), .groups = "drop")
  })
  rows <- rows[!vapply(rows, is.null, logical(1))]
  if (length(rows) == 0) {
    return(tibble(event_type = character(), alert_level = character(), count = integer()))
  }
  bind_rows(rows)
}

# == Context ===================================================================

#' Generate LLM-friendly context for gdacs.org
#'
#' @return Character string with full function signatures and bodies
gdacs_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/gdacs.org.R"
  if (!file.exists(src_file)) {
    cat("# gdacs.org context - source not found\n")
    return(invisible("# gdacs.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

