#' Get real-time regional rail train positions
#'
#' @return tibble: train_number, service, destination, line, source,
#'   current_stop, next_stop, latitude, longitude, late, track
#' @export
septa_trains <- function() {
  url <- paste0(.septa_base, "/TrainView/index.php")
  raw <- .fetch_json(url)
  if (is.null(raw) || length(raw) == 0) return(.schema_trains)
  if (!is.data.frame(raw)) return(.schema_trains)
  tibble(
    train_number = as.character(raw$trainno), service = as.character(raw$service),
    destination = as.character(raw$dest), line = as.character(raw$line),
    source = as.character(raw$SOURCE), current_stop = as.character(raw$currentstop),
    next_stop = as.character(raw$nextstop), latitude = as.numeric(raw$lat),
    longitude = as.numeric(raw$lon), late = as.integer(raw$late),
    track = as.character(raw$TRACK)
  )
}

#' Get real-time bus/trolley positions for a route
#'
#' @param route Route number or ID (e.g. "33", "44").
#' @return tibble of bus/trolley positions
#' @export
septa_buses <- function(route) {
  url <- sprintf("%s/TransitView/index.php?route=%s", .septa_base, route)
  raw <- .fetch_json(url)
  if (is.null(raw)) return(.schema_buses)
  buses <- raw$bus
  if (is.null(buses) && is.list(raw) && length(raw) > 0) {
    first <- raw[[1]]; if (is.data.frame(first)) buses <- first
  }
  if (is.null(buses) || !is.data.frame(buses) || nrow(buses) == 0) return(.schema_buses)
  tibble(
    vehicle_id = as.character(buses$VehicleID %||% buses$label),
    route = as.character(buses$route_id %||% route),
    direction = as.character(buses$Direction), destination = as.character(buses$destination),
    latitude = as.numeric(buses$lat), longitude = as.numeric(buses$lng),
    late = as.integer(buses$late),
    next_stop_name = as.character(buses$next_stop_name %||% NA_character_),
    trip = as.character(buses$trip %||% NA_character_),
    seat_availability = as.character(buses$estimated_seat_availability %||% NA_character_)
  )
}

#' List all SEPTA transit alerts
#'
#' @return tibble of route alert statuses
#' @export
septa_alerts <- function() {
  url <- paste0(.septa_base, "/Alerts/index.php")
  raw <- .fetch_json(url)
  if (is.null(raw) || length(raw) == 0 || !is.data.frame(raw)) return(.schema_alerts)
  tibble(
    route = as.character(raw$route), route_name = as.character(raw$route_name),
    mode = as.character(raw$mode), is_advisory = as.character(raw$isadvisory),
    is_detour = as.character(raw$isdetour), is_alert = as.character(raw$isalert),
    is_suspended = as.character(raw$issuspended), is_delays = as.character(raw$isdelays),
    last_updated = as.character(raw$last_updated)
  )
}

#' Search SEPTA alerts by route
#'
#' @param query Route name/number to search for (case-insensitive).
#' @return tibble of matching alerts
#' @export
septa_search <- function(query) {
  df <- septa_alerts()
  pattern <- query
  df |> filter(grepl(pattern, route, ignore.case = TRUE) | grepl(pattern, route_name, ignore.case = TRUE))
}

#' Get current elevator outages
#'
#' @return tibble: line, station, elevator, message
#' @export
septa_elevators <- function() {
  url <- paste0(.septa_base, "/elevator/index.php")
  raw <- .fetch_json(url)
  results <- raw$results
  if (is.null(results) || length(results) == 0 || !is.data.frame(results))
    return(tibble(line = character(), station = character(), elevator = character(), message = character()))
  tibble(line = as.character(results$line), station = as.character(results$station),
         elevator = as.character(results$elevator), message = as.character(results$message))
}

#' Get bus detours
#'
#' @param route Optional route number; if NULL returns all detours.
#' @return tibble: route, reason, current_message, start_date
#' @export
septa_detours <- function(route = NULL) {
  url <- if (is.null(route)) paste0(.septa_base, "/BusDetours/index.php")
         else sprintf("%s/BusDetours/index.php?route=%s", .septa_base, route)
  raw <- .fetch_json(url)
  empty <- tibble(route = character(), reason = character(), current_message = character(), start_date = character())
  if (is.null(raw) || length(raw) == 0) return(empty)
  if (!is.data.frame(raw) && is.list(raw)) raw <- bind_rows(lapply(raw, function(x) if (is.data.frame(x) && nrow(x) > 0) x else NULL))
  if (!is.data.frame(raw) || nrow(raw) == 0) return(empty)
  tibble(
    route = as.character(raw$route_id %||% raw$Route %||% NA_character_),
    reason = as.character(raw$reason %||% raw$Reason %||% NA_character_),
    current_message = as.character(raw$current_message %||% raw$CurrentMessage %||% NA_character_),
    start_date = as.character(raw$start_date %||% raw$StartDate %||% NA_character_)
  )
}

#' List SEPTA bus and trolley routes
#'
#' @return tibble: route, route_name, mode
#' @export
septa_list <- function() {
  df <- septa_alerts()
  df |> filter(mode %in% c("Bus", "Trolley")) |> select(route, route_name, mode) |> arrange(route)
}

#' Show SEPTA client context for LLM use
#'
#' @return Invisibly returns context string
#' @export
septa_context <- function() {
  .build_context("septa.org")
}
