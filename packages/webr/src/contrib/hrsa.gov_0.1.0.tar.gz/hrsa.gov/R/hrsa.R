#' List Health Professional Shortage Areas (HPSAs)
#'
#' @param state Two-letter state abbreviation (e.g. "CA").
#' @param status Filter by HPSA status (e.g. "Designated", "Withdrawn").
#' @param discipline Filter by discipline class (e.g. "Primary Care", "Dental Health", "Mental Health").
#' @param limit Maximum rows (default 500).
#' @return tibble of HPSAs
#' @export
hrsa_hpsa <- function(state = NULL, status = NULL, discipline = NULL, limit = 500) {
  df <- .hrsa_load_hpsa()
  if (!is.null(state)) { st <- state; df <- df |> filter(.data$state == st) }
  if (!is.null(status)) { pat <- status; df <- df |> filter(grepl(pat, .data$status, ignore.case = TRUE)) }
  if (!is.null(discipline)) { pat <- discipline; df <- df |> filter(grepl(pat, discipline_class, ignore.case = TRUE)) }
  head(df, limit)
}

#' Search HPSAs by name or county
#'
#' @param query Search term (case-insensitive, matched against name and county).
#' @param state Optional state filter.
#' @param limit Maximum rows (default 100).
#' @return tibble of matching HPSAs
#' @export
hrsa_search <- function(query, state = NULL, limit = 100) {
  df <- .hrsa_load_hpsa()
  if (!is.null(state)) df <- df |> filter(.data$state == !!state)
  pattern <- query
  df <- df |> filter(grepl(pattern, hpsa_name, ignore.case = TRUE) | grepl(pattern, county, ignore.case = TRUE))
  head(df, limit)
}

#' List HRSA-funded Health Centers
#'
#' @param state Two-letter state abbreviation.
#' @param city Filter by city (case-insensitive partial match).
#' @param limit Maximum rows (default 500).
#' @return tibble of health center sites
#' @export
hrsa_health_centers <- function(state = NULL, city = NULL, limit = 500) {
  df <- .hrsa_load_hc()
  if (!is.null(state)) df <- df |> filter(.data$site_state == !!state)
  if (!is.null(city)) df <- df |> filter(grepl(city, site_city, ignore.case = TRUE))
  head(df, limit)
}

#' Search health centers by name
#'
#' @param query Search term (case-insensitive, matched against site and center names).
#' @param state Optional state filter.
#' @param limit Maximum rows (default 100).
#' @return tibble of matching health centers
#' @export
hrsa_hc_search <- function(query, state = NULL, limit = 100) {
  df <- .hrsa_load_hc()
  if (!is.null(state)) df <- df |> filter(.data$site_state == !!state)
  pattern <- query
  df <- df |> filter(grepl(pattern, site_name, ignore.case = TRUE) | grepl(pattern, health_center_name, ignore.case = TRUE))
  head(df, limit)
}

#' Summarize HPSAs by state
#'
#' @param status Filter by status (default "Designated" for active only).
#' @return tibble: state, n_hpsa, avg_score, total_pop
#' @export
hrsa_hpsa_by_state <- function(status = "Designated") {
  df <- .hrsa_load_hpsa()
  if (!is.null(status)) { pat <- status; df <- df |> filter(grepl(pat, .data$status, ignore.case = TRUE)) }
  df |> group_by(state) |> summarise(n_hpsa = n(), avg_score = mean(hpsa_score, na.rm = TRUE), total_pop = sum(designation_pop, na.rm = TRUE), .groups = "drop") |> arrange(desc(n_hpsa))
}

#' Summarize health centers by state
#'
#' @return tibble: state, n_sites, n_centers
#' @export
hrsa_hc_by_state <- function() {
  df <- .hrsa_load_hc()
  df |> group_by(state = site_state) |> summarise(n_sites = n(), n_centers = n_distinct(health_center_name), .groups = "drop") |> arrange(desc(n_sites))
}

#' Show HRSA client context for LLM use
#'
#' @return Invisibly returns context string
#' @export
hrsa_context <- function() {
  .build_context("hrsa.gov")
}
