# gleif.org.R - Self-contained gleif.org client



# gleif-org.R
# Self-contained GLEIF LEI (Legal Entity Identifier) client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none
# Rate limits: be polite


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.lei_base <- "https://api.gleif.org/api/v1"

`%||%` <- function(a, b) if (is.null(a)) b else a

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE)

# == Schemas ===================================================================

.schema_lei <- tibble(
  lei = character(), legal_name = character(), status = character(),
  jurisdiction = character(), country = character(), city = character(),
  address = character(), category = character(),
  registration_date = as.Date(character()), last_update = as.Date(character())
)

# == Helper: parse lei-record ==================================================

.parse_lei_record <- function(rec) {
  a <- rec$attributes
  ent <- a$entity %||% list()
  reg <- a$registration %||% list()
  addr <- ent$legalAddress %||% list()
  tibble(
    lei               = as.character(a$lei %||% NA),
    legal_name        = as.character((ent$legalName %||% list())$name %||% NA),
    status            = as.character(ent$status %||% NA),
    jurisdiction      = as.character(ent$jurisdiction %||% NA),
    country           = as.character(addr$country %||% NA),
    city              = as.character(addr$city %||% NA),
    address           = as.character(paste((addr$addressLines %||% list()), collapse = ", ")),
    category          = as.character(ent$category %||% NA),
    registration_date = tryCatch(as.Date(reg$initialRegistrationDate %||% NA), error = function(e) NA),
    last_update       = tryCatch(as.Date(reg$lastUpdateDate %||% NA), error = function(e) NA)
  )
}

# == Search ====================================================================


#' Search GLEIF LEI records by legal entity name
#'
#' @param name Legal name to search (e.g. "Google", "Apple Inc")
#' @param size Results per page (default 20, max 200)
#' @param page Page number (default 1)
#' @return tibble: lei, legal_name, status, jurisdiction, country, city,
#'   address, category, registration_date, last_update
lei_search <- function(name, size = 20, page = 1) {
  url <- sprintf(
    "%s/lei-records?filter%%5Bentity.legalName%%5D=%s&page%%5Bsize%%5D=%d&page%%5Bnumber%%5D=%d",
    .lei_base, utils::URLencode(name), as.integer(size), as.integer(page)
  )
  raw <- .fetch_json(url)
  d <- raw$data
  if (is.null(d) || length(d) == 0) return(.schema_lei)
  bind_rows(lapply(d, .parse_lei_record))
}

#' Fetch a single LEI record by LEI code
#'
#' @param lei The 20-character LEI code
#' @return tibble: one row with lei, legal_name, status, jurisdiction, country,
#'   city, address, category, registration_date, last_update
lei_record <- function(lei) {
  url <- paste0(.lei_base, "/lei-records/", lei)
  raw <- .fetch_json(url)
  d <- raw$data
  if (is.null(d)) return(.schema_lei)
  .parse_lei_record(d)
}

#' Get parent/child relationships for a LEI entity
#'
#' @param lei The 20-character LEI code
#' @return tibble: relationship_type, start_lei, start_name, end_lei, end_name, status
lei_relationships <- function(lei) {
  schema <- tibble(relationship_type = character(), start_lei = character(),
                   start_name = character(), end_lei = character(),
                   end_name = character(), status = character())

  url <- sprintf("%s/lei-records/%s/direct-parent-relationship", .lei_base, lei)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)

  rows <- list()
  if (!is.null(raw) && !is.null(raw$data)) {
    d <- raw$data
    a <- d$attributes %||% list()
    rel <- a$relationship %||% list()
    rows[[1]] <- tibble(
      relationship_type = "direct_parent",
      start_lei = as.character(rel$startNode$id %||% lei),
      start_name = NA_character_,
      end_lei = as.character(rel$endNode$id %||% NA_character_),
      end_name = NA_character_,
      status = as.character(a$registration$status %||% NA_character_)
    )
  }

  # Also try ultimate parent
  url2 <- sprintf("%s/lei-records/%s/ultimate-parent-relationship", .lei_base, lei)
  raw2 <- tryCatch(.fetch_json(url2), error = function(e) NULL)
  if (!is.null(raw2) && !is.null(raw2$data)) {
    d <- raw2$data
    a <- d$attributes %||% list()
    rel <- a$relationship %||% list()
    rows[[length(rows) + 1]] <- tibble(
      relationship_type = "ultimate_parent",
      start_lei = as.character(rel$startNode$id %||% lei),
      start_name = NA_character_,
      end_lei = as.character(rel$endNode$id %||% NA_character_),
      end_name = NA_character_,
      status = as.character(a$registration$status %||% NA_character_)
    )
  }

  if (length(rows) == 0) return(schema)
  bind_rows(rows)
}

#' Search LEI records by country
#'
#' @param country ISO 3166-1 alpha-2 country code (e.g. "US", "GB", "DE")
#' @param size Results per page (default 20)
#' @return tibble: lei, legal_name, status, jurisdiction, country, city
lei_by_country <- function(country, size = 20) {
  url <- sprintf(
    "%s/lei-records?filter%%5Bentity.legalAddress.country%%5D=%s&page%%5Bsize%%5D=%d",
    .lei_base, toupper(country), as.integer(size)
  )
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_lei)
  d <- raw$data
  if (is.null(d) || length(d) == 0) return(.schema_lei)
  bind_rows(lapply(d, .parse_lei_record))
}

# == Context ===================================================================

#' Generate LLM-friendly context for gleif.org
#'
#' @return Character string with full function signatures and bodies
lei_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/gleif.org.R"
  if (!file.exists(src_file)) {
    cat("# gleif.org context - source not found\n")
    return(invisible("# gleif.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

