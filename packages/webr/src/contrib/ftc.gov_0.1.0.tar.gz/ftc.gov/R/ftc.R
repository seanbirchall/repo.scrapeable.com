#' List available FTC API datasets
#'
#' @return A tibble describing available endpoints.
#' @export
ftc_list <- function() {
  tibble::tibble(
    endpoint = "hsr-early-termination-notices",
    description = "Hart-Scott-Rodino Early Termination Notices",
    total_records = "~27,000",
    auth = "API key (DEMO_KEY for testing, register at api.ftc.gov)",
    rate_limit = "10 requests/minute with DEMO_KEY"
  )
}

#' Search FTC HSR Early Termination Notices
#'
#' @param query Character. Search text to match against titles. Optional.
#' @param max_results Integer. Maximum results (default 50).
#' @param api_key Character. FTC API key.
#' @return A tibble of HSR notices.
#' @export
ftc_search <- function(query = NULL, max_results = 50, api_key = NULL) {
  data <- .ftc_fetch_all("hsr-early-termination-notices", api_key = api_key,
                         max_results = max_results)
  result <- .ftc_parse_hsr(data)

  if (!is.null(query) && nrow(result) > 0) {
    result <- result |>
      filter(grepl(!!query, .data$title, ignore.case = TRUE))
  }
  result
}

#' Get recent FTC HSR Early Termination Notices
#'
#' @param n Integer. Number of recent notices (default 20).
#' @param api_key Character. FTC API key.
#' @return A tibble of recent HSR notices.
#' @export
ftc_hsr_recent <- function(n = 20, api_key = NULL) {
  raw <- .ftc_get("hsr-early-termination-notices", api_key = api_key,
                  page_size = min(n, 50))
  .ftc_parse_hsr(raw$data) |> head(n)
}

#' Get FTC HSR notice by transaction number
#'
#' @param transaction_number Character. The HSR transaction number.
#' @param api_key Character. FTC API key.
#' @return A tibble with the matching notice.
#' @export
ftc_hsr_transaction <- function(transaction_number, api_key = NULL) {
  data <- .ftc_fetch_all("hsr-early-termination-notices", api_key = api_key,
                         max_results = 200)
  result <- .ftc_parse_hsr(data)
  result |> filter(.data$transaction_number == !!transaction_number)
}

#' Get FTC HSR notice count
#'
#' @param api_key Character. FTC API key.
#' @return Integer total count.
#' @export
ftc_hsr_count <- function(api_key = NULL) {
  raw <- .ftc_get("hsr-early-termination-notices", api_key = api_key,
                  page_size = 1)
  raw$meta$count %||% 0L
}

#' Print ftc.gov client context
#'
#' @return Character string of function signatures (invisibly).
#' @export
ftc_context <- function() {
  src <- system.file("source", "ftc.R", package = "ftc.gov")
  if (src == "") {
    f <- sys.frame(sys.nframe())$ofile %||%
      attr(body(ftc_context), "srcfile")$filename %||% ""
    if (nzchar(f)) src <- f
  }
  .build_context("ftc.gov", src_file = if (nzchar(src)) src else NULL,
                 header_lines = c(
                   "# ftc.gov -- Federal Trade Commission API R client",
                   "# Base: https://api.ftc.gov/v0",
                   "# Auth: API key (register at api.ftc.gov, DEMO_KEY for testing)"
                 ))
}
