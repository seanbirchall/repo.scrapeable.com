# == Schemas ===================================================================

.schema_speeds <- tibble::tibble(
  sid = character(),
  link_name = character(),
  borough = character(),
  link_length_ft = numeric(),
  aggregation_period_sec = integer(),
  n_samples = integer(),
  timestamp = as.POSIXct(character()),
  median_tt_sec = numeric(),
  median_speed_fps = numeric(),
  median_speed_mph = numeric()
)

# == Public functions ==========================================================

#' Get real-time NYC traffic speeds from EZ-Pass sensors
#'
#' Returns the latest Midtown in Motion traffic speed readings across
#' all sensor links in Manhattan and other boroughs.
#'
#' @return tibble: sid, link_name, borough, link_length_ft,
#'   aggregation_period_sec, n_samples, timestamp, median_tt_sec,
#'   median_speed_fps, median_speed_mph
#' @export
nyctmc_speeds <- function() {
  url <- sprintf("%s/mim_data_opendata.csv", .nyctmc_base)
  tmp <- .fetch(url, ext = ".csv")
  raw <- utils::read.csv(tmp, stringsAsFactors = FALSE)
  if (nrow(raw) == 0) return(.schema_speeds)

  as_tibble(raw) |>
    transmute(
      sid = as.character(sid),
      link_name = as.character(link_name),
      borough = as.character(borough),
      link_length_ft = as.numeric(link_length_ft),
      aggregation_period_sec = as.integer(aggregation_period_sec),
      n_samples = as.integer(n_samples),
      timestamp = as.POSIXct(median_calculation_timestamp,
                             format = "%m/%d/%Y %H:%M:%S"),
      median_tt_sec = as.numeric(median_tt_sec),
      median_speed_fps = as.numeric(median_speed_fps),
      median_speed_mph = round(as.numeric(median_speed_fps) * 0.681818, 2)
    )
}

#' List unique traffic sensor links
#'
#' Returns distinct sensor link segments with their names, boroughs,
#' and lengths.
#'
#' @return tibble: sid, link_name, borough, link_length_ft
#' @export
nyctmc_links <- function() {
  nyctmc_speeds() |>
    distinct(sid, link_name, borough, link_length_ft) |>
    arrange(borough, link_name)
}

#' Get traffic speeds filtered by borough
#'
#' @param borough Borough name (e.g., "Manhattan", "Brooklyn")
#' @return tibble: same columns as nyctmc_speeds()
#' @export
nyctmc_borough <- function(borough) {
  pat <- borough[[1]]
  nyctmc_speeds() |>
    filter(grepl(pat, .data$borough, ignore.case = TRUE))
}

#' Search traffic links by name
#'
#' @param query Search string matched against link names (case-insensitive)
#' @return tibble: same columns as nyctmc_speeds()
#' @export
nyctmc_search <- function(query) {
  nyctmc_speeds() |>
    filter(grepl(query, .data$link_name, ignore.case = TRUE))
}

#' Show context for the nyctmc.org client
#'
#' Reads its own source and returns function signatures and documentation.
#'
#' @return Invisible string of context
#' @export
nyctmc_context <- function() {
  .build_context(
    "nyctmc.org",
    header_lines = c(
      "# nyctmc.org - NYC Traffic Management Center",
      "# Real-time EZ-Pass traffic speed data"
    )
  )
}
