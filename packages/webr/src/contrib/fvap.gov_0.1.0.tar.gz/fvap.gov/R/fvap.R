# == Public functions ==========================================================

#' List available FVAP survey datasets
#'
#' @return tibble: id, name, description, url, year
#' @export
fvap_list <- function() {
  .fvap_datasets
}

#' Fetch an FVAP survey dataset
#'
#' @param dataset Dataset id from fvap_list() (e.g. "military", "overseas_citizens")
#' @param sheet Sheet name or number (default 1)
#' @return tibble: survey response data with all columns from the Excel file
#' @export
fvap_data <- function(dataset, sheet = 1) {
  match <- .fvap_datasets |> filter(.data$id == !!dataset)
  if (nrow(match) == 0) {
    stop("Unknown dataset: ", dataset,
         ". Use fvap_list() to see available datasets.", call. = FALSE)
  }
  url <- match$url[1]
  f <- .fetch_excel(url, ext = ".xls")
  tryCatch(
    readxl::read_excel(f, sheet = sheet) |> as_tibble(),
    error = function(e) {
      warning("Could not read dataset: ", e$message, call. = FALSE)
      tibble()
    }
  )
}

#' List sheets in an FVAP survey dataset
#'
#' @param dataset Dataset id from fvap_list()
#' @return character vector of sheet names
#' @export
fvap_sheets <- function(dataset) {
  match <- .fvap_datasets |> filter(.data$id == !!dataset)
  if (nrow(match) == 0) {
    stop("Unknown dataset: ", dataset, call. = FALSE)
  }
  url <- match$url[1]
  f <- .fetch_excel(url, ext = ".xls")
  readxl::excel_sheets(f)
}

#' Summarize an FVAP survey dataset (column names and types)
#'
#' @param dataset Dataset id from fvap_list()
#' @return tibble: column_name, column_type, n_missing, n_unique
#' @export
fvap_summary <- function(dataset) {
  d <- fvap_data(dataset)
  if (nrow(d) == 0) return(tibble(column_name = character(), column_type = character(),
                                   n_missing = integer(), n_unique = integer()))
  tibble(
    column_name = names(d),
    column_type = vapply(d, function(x) class(x)[1], character(1)),
    n_missing = vapply(d, function(x) sum(is.na(x)), integer(1)),
    n_unique = vapply(d, function(x) length(unique(x[!is.na(x)])), integer(1))
  )
}

#' Return context: full source of this client
#'
#' @return character: source code of this file
#' @export
fvap_context <- function() {
  f <- system.file("source", "fvap.gov.R", package = "fvap.gov")
  if (f == "") {
    f <- tryCatch(
      { env <- sys.frame(0); getSrcFilename(env, full.names = TRUE) },
      error = function(e) ""
    )
  }
  if (f == "" || !file.exists(f)) return("Source not available")
  paste(readLines(f, warn = FALSE), collapse = "\n")
}
