# fvap.gov.R - Self-contained FVAP (Federal Voting Assistance Program) client
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble, readxl
# Auth: none required

library(httr2)
library(jsonlite)
library(tibble)
library(dplyr)
library(readxl)

`%||%` <- function(a, b) if (is.null(a)) b else a

# == Private utilities =========================================================

.ua <- "support@scrapeable.com"

.fvap_base <- "https://www.fvap.gov"

.fetch_excel <- function(url, ext = ".xls") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

# == Dataset metadata ==========================================================

.fvap_datasets <- tibble(
  id = c("military", "overseas_citizens", "vao_military",
         "leo", "federal_civilians", "dos_vao"),
  name = c("Uniformed Services Absentee Voting",
           "Overseas Citizens Absentee Voting",
           "Military Voting Assistance Officers",
           "Local Election Official Data",
           "Federal Employees Overseas Absentee Voting",
           "Department of State Voting Assistance Officers"),
  description = c(
    "2008 post election survey of active duty military on absentee voting",
    "2008 post election survey of American citizens living overseas on absentee voting",
    "2008 post election survey of military voting assistance officers (VAO)",
    "2008 post election survey of Local Election Officials on military/overseas absentee voting",
    "2008 post election survey of Federal employees overseas on absentee voting",
    "2008 post election survey of Dept of State voting assistance officers"
  ),
  url = c(
    paste0(.fvap_base, "/uploads/FVAP/Surveys/military_data.xls"),
    paste0(.fvap_base, "/uploads/FVAP/Surveys/overseas_citizens_data.xls"),
    paste0(.fvap_base, "/uploads/FVAP/Surveys/uvao_data.xls"),
    paste0(.fvap_base, "/uploads/FVAP/Surveys/leo_data.xls"),
    paste0(.fvap_base, "/uploads/FVAP/Surveys/federal_civilians_data.xls"),
    paste0(.fvap_base, "/uploads/FVAP/Surveys/dosvao_data.xls")
  ),
  year = rep(2008L, 6)
)

# == Public functions ==========================================================

#' List available FVAP survey datasets
#'
#' @return tibble: id, name, description, url, year
fvap_list <- function() {
  .fvap_datasets
}

#' Fetch an FVAP survey dataset
#'
#' @param dataset Dataset id from fvap_list() (e.g. "military", "overseas_citizens")
#' @param sheet Sheet name or number (default 1)
#' @return tibble: survey response data with all columns from the Excel file
fvap_data <- function(dataset, sheet = 1) {
  match <- .fvap_datasets |> filter(.data$id == !!dataset)
  if (nrow(match) == 0) {
    stop("Unknown dataset: ", dataset,
         ". Use fvap_list() to see available datasets.", call. = FALSE)
  }
  url <- match$url[1]
  f <- .fetch_excel(url, ext = ".xls")
  tryCatch(
    readxl::read_excel(f, sheet = sheet) |> as_tibble(),
    error = function(e) {
      warning("Could not read dataset: ", e$message, call. = FALSE)
      tibble()
    }
  )
}

#' List sheets in an FVAP survey dataset
#'
#' @param dataset Dataset id from fvap_list()
#' @return character vector of sheet names
fvap_sheets <- function(dataset) {
  match <- .fvap_datasets |> filter(.data$id == !!dataset)
  if (nrow(match) == 0) {
    stop("Unknown dataset: ", dataset, call. = FALSE)
  }
  url <- match$url[1]
  f <- .fetch_excel(url, ext = ".xls")
  readxl::excel_sheets(f)
}

#' Summarize an FVAP survey dataset (column names and types)
#'
#' @param dataset Dataset id from fvap_list()
#' @return tibble: column_name, column_type, n_missing, n_unique
fvap_summary <- function(dataset) {
  d <- fvap_data(dataset)
  if (nrow(d) == 0) return(tibble(column_name = character(), column_type = character(),
                                   n_missing = integer(), n_unique = integer()))
  tibble(
    column_name = names(d),
    column_type = vapply(d, function(x) class(x)[1], character(1)),
    n_missing = vapply(d, function(x) sum(is.na(x)), integer(1)),
    n_unique = vapply(d, function(x) length(unique(x[!is.na(x)])), integer(1))
  )
}

#' Return context: full source of this client
#'
#' @return character: source code of this file
fvap_context <- function() {
  f <- system.file("source", "fvap.gov.R", package = "fvap.gov")
  if (f == "") {
    f <- tryCatch(
      { env <- sys.frame(0); getSrcFilename(env, full.names = TRUE) },
      error = function(e) ""
    )
  }
  if (f == "" || !file.exists(f)) return("Source not available")
  paste(readLines(f, warn = FALSE), collapse = "\n")
}
