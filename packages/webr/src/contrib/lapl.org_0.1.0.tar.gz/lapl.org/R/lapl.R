# == Public functions ==========================================================

#' List available LAPL book feeds
#'
#' @param category Optional filter: "new_titles" or "hot_titles"
#' @return tibble: id, name, url, category
#' @export
lapl_list <- function(category = NULL) {
  out <- .lapl_feeds
  if (!is.null(category)) {
    out <- out |> filter(.data$category == !!category)
  }
  out
}

#' Fetch titles from an LAPL book feed
#'
#' @param feed_id Feed id from lapl_list() (e.g. "new_scifi", "hot_fiction")
#' @return tibble: title, link, author, genre, pub_date, cover_url
#' @export
lapl_titles <- function(feed_id) {
  match <- .lapl_feeds |> filter(.data$id == !!feed_id)
  if (nrow(match) == 0) {
    stop("Unknown feed: ", feed_id,
         ". Use lapl_list() to see available feeds.", call. = FALSE)
  }
  xml_doc <- tryCatch(.fetch_xml(match$url[1]),
                       error = function(e) {
                         warning("Could not fetch feed: ", e$message, call. = FALSE)
                         return(NULL)
                       })
  if (is.null(xml_doc)) {
    return(tibble(title = character(), link = character(), author = character(),
                  genre = character(), pub_date = character(), cover_url = character()))
  }
  .parse_rss_items(xml_doc)
}

#' Fetch new titles across all genres
#'
#' @return tibble: feed_id, title, link, author, genre, pub_date, cover_url
#' @export
lapl_new_titles <- function() {
  feeds <- .lapl_feeds |> filter(.data$category == "new_titles")
  results <- lapply(seq_len(nrow(feeds)), function(i) {
    tryCatch({
      items <- lapl_titles(feeds$id[i])
      if (nrow(items) > 0) items$feed_id <- feeds$id[i]
      items
    }, error = function(e) NULL)
  })
  results <- results[!vapply(results, is.null, logical(1))]
  if (length(results) == 0) {
    return(tibble(feed_id = character(), title = character(), link = character(),
                  author = character(), genre = character(), pub_date = character(),
                  cover_url = character()))
  }
  bind_rows(results) |> select(feed_id, everything())
}

#' Fetch hot/popular titles across all categories
#'
#' @return tibble: feed_id, title, link, author, genre, pub_date, cover_url
#' @export
lapl_hot_titles <- function() {
  feeds <- .lapl_feeds |> filter(.data$category == "hot_titles")
  results <- lapply(seq_len(nrow(feeds)), function(i) {
    tryCatch({
      items <- lapl_titles(feeds$id[i])
      if (nrow(items) > 0) items$feed_id <- feeds$id[i]
      items
    }, error = function(e) NULL)
  })
  results <- results[!vapply(results, is.null, logical(1))]
  if (length(results) == 0) {
    return(tibble(feed_id = character(), title = character(), link = character(),
                  author = character(), genre = character(), pub_date = character(),
                  cover_url = character()))
  }
  bind_rows(results) |> select(feed_id, everything())
}

#' Search LAPL titles by keyword
#'
#' @param query Search string (case-insensitive, matches title or author)
#' @param feeds Which feeds to search (default: all). Vector of feed ids.
#' @return tibble: feed_id, title, link, author, genre, pub_date, cover_url
#' @export
lapl_search <- function(query, feeds = NULL) {
  if (is.null(feeds)) {
    all_items <- bind_rows(lapl_new_titles(), lapl_hot_titles())
  } else {
    results <- lapply(feeds, function(fid) {
      tryCatch({
        items <- lapl_titles(fid)
        if (nrow(items) > 0) items$feed_id <- fid
        items
      }, error = function(e) NULL)
    })
    results <- results[!vapply(results, is.null, logical(1))]
    all_items <- bind_rows(results)
  }
  pattern <- tolower(query)
  all_items |> filter(
    grepl(pattern, tolower(title)) |
    grepl(pattern, tolower(author))
  )
}

#' Return context: full source of this client
#'
#' @return character: source code of this file
#' @export
lapl_context <- function() {
  f <- system.file("source", "lapl.org.R", package = "lapl.org")
  if (f == "") {
    f <- tryCatch(
      { env <- sys.frame(0); getSrcFilename(env, full.names = TRUE) },
      error = function(e) ""
    )
  }
  if (f == "" || !file.exists(f)) return("Source not available")
  paste(readLines(f, warn = FALSE), collapse = "\n")
}
