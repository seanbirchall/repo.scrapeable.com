# == Public functions ==========================================================

#' List available OSMRE GeoMine data layers
#'
#' @return tibble: id, name, service
#' @export
osmre_list <- function() {
  .osmre_layers
}

#' Fetch OSMRE office locations
#'
#' @return tibble: office_name, address, city, state, zip, osm_region, web_site, lat, lon
#' @export
osmre_offices <- function() {
  raw <- .query_layer("OSMRE_Offices")
  if (nrow(raw) == 0) return(tibble())
  out <- tibble(
    office_name = as.character(raw$office_name %||% raw$OFFICE_NAME),
    address = as.character(raw$address %||% raw$ADDRESS),
    city = as.character(raw$city %||% raw$CITY),
    state = as.character(raw$state %||% raw$STATE),
    zip = as.character(raw$zip %||% raw$ZIP),
    osm_region = as.character(raw$osm_region %||% raw$OSM_REGION),
    web_site = as.character(raw$web_site %||% raw$WEB_SITE),
    lat = suppressWarnings(as.numeric(raw$point_y %||% raw$POINT_Y)),
    lon = suppressWarnings(as.numeric(raw$point_x %||% raw$POINT_X))
  )
  out
}

#' Fetch mine records from the National Mine Map Repository
#'
#' @param state Optional state name to filter (e.g. "Pennsylvania")
#' @param commodity Optional commodity filter (e.g. "Coal", "Iron")
#' @param max_records Maximum records to return (default 1000)
#' @return tibble: mine_id, mine_name, company, commodity, mining_type,
#'   latitude, longitude, map_year, document_number
#' @export
osmre_mine_maps <- function(state = NULL, commodity = NULL, max_records = 1000) {
  where_parts <- "1=1"
  if (!is.null(state)) {
    # Mine map repo doesn't have a state field directly - skip state filter
    # The data is point-based, filter by coordinate or post-hoc
  }
  if (!is.null(commodity)) {
    where_parts <- paste0("commodity LIKE '%", commodity, "%'")
  }
  raw <- .query_layer("NationalMineMapRepository_OSMRE", where = where_parts,
                       max_records = max_records)
  if (nrow(raw) == 0) return(tibble())
  tibble(
    mine_id = suppressWarnings(as.numeric(raw$mineid)),
    mine_name = as.character(raw$minename),
    document_mine_name = as.character(raw$documentminename),
    company = as.character(raw$minecompany),
    commodity = as.character(raw$commodity),
    mining_type = as.character(raw$miningtype),
    latitude = suppressWarnings(as.numeric(raw$latitude)),
    longitude = suppressWarnings(as.numeric(raw$longitude)),
    map_year = as.character(raw$mapyear),
    document_number = as.character(raw$documentnumber)
  )
}

#' Fetch coal mine operation permit boundaries
#'
#' @param state Optional state filter (uses state abbreviation or name in data)
#' @param status Optional coalmine operation status code
#' @param max_records Maximum records to return (default 500)
#' @return tibble: mine_name, permittee, company, permit_id, msha_id,
#'   status, coal_bed_names, calculated_area_acres
#' @export
osmre_coalmine_operations <- function(state = NULL, status = NULL, max_records = 500) {
  where <- "1=1"
  if (!is.null(status)) {
    where <- paste0("coalmine_op_status=", status)
  }
  raw <- .query_layer("AllCoalmineOperations", where = where,
                       max_records = max_records)
  if (nrow(raw) == 0) return(tibble())
  tibble(
    mine_name = as.character(raw$mine_name),
    permittee = as.character(raw$permittee),
    company = as.character(raw$company),
    permit_id = as.character(raw$permit_id),
    msha_id = as.character(raw$msha_id),
    status = suppressWarnings(as.integer(raw$coalmine_op_status)),
    coal_bed_names = as.character(raw$coal_bed_names),
    calculated_area_acres = suppressWarnings(as.numeric(raw$calculated_area))
  )
}

#' Search OSMRE mine maps by name
#'
#' @param query Search string (case-insensitive partial match on mine name)
#' @param max_records Maximum records (default 100)
#' @return tibble: same columns as osmre_mine_maps()
#' @export
osmre_search <- function(query, max_records = 100) {
  where <- paste0("minename LIKE '%", toupper(query), "%'")
  raw <- .query_layer("NationalMineMapRepository_OSMRE", where = where,
                       max_records = max_records)
  if (nrow(raw) == 0) return(tibble())
  tibble(
    mine_id = suppressWarnings(as.numeric(raw$mineid)),
    mine_name = as.character(raw$minename),
    document_mine_name = as.character(raw$documentminename),
    company = as.character(raw$minecompany),
    commodity = as.character(raw$commodity),
    mining_type = as.character(raw$miningtype),
    latitude = suppressWarnings(as.numeric(raw$latitude)),
    longitude = suppressWarnings(as.numeric(raw$longitude)),
    map_year = as.character(raw$mapyear),
    document_number = as.character(raw$documentnumber)
  )
}

#' Query any OSMRE GeoMine layer
#'
#' @param layer_id Layer id from osmre_list()
#' @param where SQL WHERE clause (default "1=1")
#' @param max_records Maximum records (default 500)
#' @return tibble: raw attribute columns from the ArcGIS layer
#' @export
osmre_query <- function(layer_id, where = "1=1", max_records = 500) {
  match <- .osmre_layers |> filter(.data$id == !!layer_id)
  if (nrow(match) == 0) {
    stop("Unknown layer: ", layer_id,
         ". Use osmre_list() to see available layers.", call. = FALSE)
  }
  .query_layer(match$service[1], where = where, max_records = max_records)
}

#' Return context: full source of this client
#'
#' @return character: source code of this file
#' @export
osmre_context <- function() {
  f <- system.file("source", "osmre.gov.R", package = "osmre.gov")
  if (f == "") {
    f <- tryCatch(
      { env <- sys.frame(0); getSrcFilename(env, full.names = TRUE) },
      error = function(e) ""
    )
  }
  if (f == "" || !file.exists(f)) return("Source not available")
  paste(readLines(f, warn = FALSE), collapse = "\n")
}
