#' Commerce Enterprise Data Inventory (Project Open Data catalog)
#'
#' Fetches and parses the Department of Commerce data.json catalog containing
#' ~1964 dataset entries. Returns a tibble with one row per dataset.
#'
#' @return tibble with columns: title, description, publisher, keywords,
#'   modified, identifier, access_level, format, access_url,
#'   distribution_urls, landing_page, bureau_code, license, temporal, spatial
#' @export
doc_catalog <- function() {
  raw <- tryCatch(.fetch_json(.base_catalog), error = function(e) {
    warning("Failed to fetch Commerce data catalog: ", conditionMessage(e))
    return(NULL)
  })
  if (is.null(raw)) return(.schema_catalog)
  .parse_catalog(raw)
}

#' Search the Commerce data catalog by keyword
#'
#' Searches across title, description, keywords, and publisher fields
#' of the Enterprise Data Inventory. Case-insensitive.
#'
#' @param query Character string to search for
#' @param field Optional: restrict search to "title", "description",
#'   "keywords", or "publisher". Default searches all.
#' @return tibble (same schema as doc_catalog)
#' @export
doc_search <- function(query, field = NULL) {
  stopifnot(is.character(query), length(query) == 1, nzchar(query))
  catalog <- doc_catalog()
  if (nrow(catalog) == 0) return(catalog)

  if (!is.null(field)) {
    stopifnot(field %in% c("title", "description", "keywords", "publisher"))
    matches <- grepl(query, catalog[[field]], ignore.case = TRUE)
  } else {
    matches <- grepl(query, catalog$title, ignore.case = TRUE) |
      grepl(query, catalog$description, ignore.case = TRUE) |
      grepl(query, catalog$keywords, ignore.case = TRUE) |
      grepl(query, catalog$publisher, ignore.case = TRUE)
  }
  catalog[matches, , drop = FALSE]
}

#' CIO Governance Board memberships
#'
#' Fetches the Department of Commerce CIO governance board membership list.
#'
#' @return tibble with columns: board_name, bureau_code, program_code, description
#' @export
doc_governance <- function() {
  raw <- tryCatch(.fetch_json(.base_governance), error = function(e) {
    warning("Failed to fetch governance boards: ", conditionMessage(e))
    return(NULL)
  })
  if (is.null(raw)) return(.schema_governance)
  .parse_governance(raw)
}

#' IT Cost Savings and Avoidance strategies
#'
#' Fetches the Department of Commerce IT cost savings/avoidance data.
#' Amounts are in millions of dollars.
#'
#' @return tibble with columns: strategy_id, strategy_title, decision_date,
#'   omb_initiative, amount_type, fy2012 through fy2020
#' @export
doc_cost_savings <- function() {
  raw <- tryCatch(.fetch_json(.base_savings), error = function(e) {
    warning("Failed to fetch cost savings data: ", conditionMessage(e))
    return(NULL)
  })
  if (is.null(raw)) return(.schema_savings)
  .parse_savings(raw)
}

#' Bureau IT Leadership Directory
#'
#' Fetches the Department of Commerce bureau IT leadership directory.
#'
#' @return tibble with columns: bureau_code, first_name, last_name,
#'   employment_type, appointment, responsibilities, rating_official,
#'   review_official, key_bureau_cio
#' @export
doc_leadership <- function() {
  raw <- tryCatch(.fetch_json(.base_leadership), error = function(e) {
    warning("Failed to fetch leadership directory: ", conditionMessage(e))
    return(NULL)
  })
  if (is.null(raw)) return(.schema_leadership)
  .parse_leadership(raw)
}

#' List all available Commerce datasets (summary view)
#'
#' Returns a compact tibble of all datasets in the Enterprise Data Inventory,
#' with just the key identification and access fields.
#'
#' @return tibble with columns: title, publisher, format, access_url, modified
#' @export
doc_list <- function() {
  catalog <- doc_catalog()
  if (nrow(catalog) == 0) {
    return(tibble::tibble(
      title = character(), publisher = character(),
      format = character(), access_url = character(),
      modified = as.Date(character())
    ))
  }
  catalog |>
    dplyr::select(title, publisher, format, access_url, modified) |>
    dplyr::arrange(dplyr::desc(modified))
}

#' Return context about the commerce.gov client functions
#'
#' Reads the source file and returns all function signatures with
#' roxygen documentation for use by LLMs or introspection tools.
#'
#' @return Character string (invisibly), printed to console
#' @export
doc_context <- function() {
  .build_context("commerce", header_lines = c(
    "# commerce.gov.R — Department of Commerce open data client",
    "# Endpoints: data.json catalog, governance boards, cost savings, IT leadership",
    "# Prefix: doc_"
  ))
}
