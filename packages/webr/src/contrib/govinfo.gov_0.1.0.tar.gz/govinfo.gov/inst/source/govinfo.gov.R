# govinfo.gov.R - Self-contained GovInfo API client
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: uses DEMO_KEY by default; set GOVINFO_API_KEY env var for higher limits
# Rate limits: DEMO_KEY = 40/hr, registered key = 1000/hr

library(httr2)
library(jsonlite)
library(tibble)
library(dplyr)

# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.govinfo_base <- "https://api.govinfo.gov"

`%||%` <- function(a, b) if (is.null(a)) b else a

.govinfo_key <- function() {
  Sys.getenv("GOVINFO_API_KEY", unset = "DEMO_KEY")
}

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_timeout(30) |>
    httr2::req_retry(max_tries = 2, max_seconds = 10) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = TRUE)

.safe_col <- function(df, col, default = NA_character_) {
  if (col %in% names(df)) df[[col]] else rep(default, nrow(df))
}

# == Schemas ===================================================================

.schema_collection <- tibble(
  collectionCode = character(), collectionName = character(),
  packageCount = integer(), granuleCount = integer()
)

.schema_package <- tibble(
  packageId = character(), title = character(),
  collectionCode = character(), dateIssued = as.Date(character()),
  lastModified = character()
)

.schema_search <- tibble(
  title = character(), packageId = character(),
  collectionCode = character(), dateIssued = as.Date(character()),
  governmentAuthor = character(), category = character()
)

# == Collections ===============================================================

#' List all GovInfo collections
#'
#' @return tibble: collectionCode, collectionName, packageCount, granuleCount
govinfo_collections <- function() {
  url <- paste0(.govinfo_base, "/collections?api_key=", .govinfo_key())
  res <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(res) || is.null(res$collections)) return(.schema_collection)

  d <- res$collections
  tibble(
    collectionCode = as.character(.safe_col(d, "collectionCode")),
    collectionName = as.character(.safe_col(d, "collectionName")),
    packageCount = as.integer(.safe_col(d, "packageCount", NA_integer_)),
    granuleCount = as.integer(.safe_col(d, "granuleCount", NA_integer_))
  )
}

# == Collection Packages =======================================================

#' List packages in a GovInfo collection
#'
#' @param collection Collection code (e.g. "FR", "CFR", "BILLS", "CREC")
#' @param start_date ISO date string for start (e.g. "2024-01-01")
#' @param page_size Number of packages per page (default 20, max 100)
#' @param offset Pagination offset (default 0)
#' @return tibble: packageId, title, collectionCode, dateIssued, lastModified
govinfo_packages <- function(collection, start_date = "2020-01-01",
                             page_size = 20, offset = 0) {
  start_ts <- paste0(start_date, "T00:00:00Z")
  url <- sprintf("%s/collections/%s/%s?offset=%d&pageSize=%d&api_key=%s",
                 .govinfo_base, collection, start_ts, offset,
                 min(page_size, 100), .govinfo_key())
  res <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(res) || is.null(res$packages) || length(res$packages) == 0)
    return(.schema_package)

  d <- res$packages
  tibble(
    packageId = as.character(.safe_col(d, "packageId")),
    title = as.character(.safe_col(d, "title")),
    collectionCode = as.character(.safe_col(d, "docClass")),
    dateIssued = as.Date(.safe_col(d, "dateIssued")),
    lastModified = as.character(.safe_col(d, "lastModified"))
  )
}

# == Package Summary ===========================================================

#' Get summary metadata for a GovInfo package
#'
#' @param package_id Package identifier (e.g. "FR-2024-01-02")
#' @return tibble with one row: packageId, title, collectionCode, dateIssued,
#'   category, branch, governmentAuthor, publisher, pages, suDocClassNumber
govinfo_package_summary <- function(package_id) {
  url <- sprintf("%s/packages/%s/summary?api_key=%s",
                 .govinfo_base, package_id, .govinfo_key())
  d <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(d)) return(tibble())

  tibble(
    packageId = as.character(d$packageId %||% NA_character_),
    title = as.character(d$title %||% NA_character_),
    collectionCode = as.character(d$collectionCode %||% NA_character_),
    dateIssued = as.Date(d$dateIssued %||% NA_character_),
    category = as.character(d$category %||% NA_character_),
    branch = as.character(d$branch %||% NA_character_),
    governmentAuthor = as.character(
      paste(d$governmentAuthor %||% character(0), collapse = "; ")
    ),
    publisher = as.character(d$publisher %||% NA_character_),
    pages = as.integer(d$pages %||% NA_integer_),
    suDocClassNumber = as.character(d$suDocClassNumber %||% NA_character_)
  )
}

# == Search ====================================================================

#' Search GovInfo documents
#'
#' @param query Search query string
#' @param collection Optional collection code filter (e.g. "FR", "BILLS")
#' @param page_size Number of results (default 20, max 100)
#' @param offset_mark Cursor for pagination (default "*" = first page)
#' @return tibble: title, packageId, collectionCode, dateIssued,
#'   governmentAuthor, category
govinfo_search <- function(query, collection = NULL, page_size = 20,
                           offset_mark = "*") {
  body <- list(
    query = query,
    pageSize = min(page_size, 100),
    offsetMark = offset_mark
  )
  if (!is.null(collection)) body$collection <- collection

  url <- paste0(.govinfo_base, "/search?api_key=", .govinfo_key())
  tmp <- tempfile(fileext = ".json")
  resp <- tryCatch({
    httr2::request(url) |>
      httr2::req_headers(`User-Agent` = .ua, `Content-Type` = "application/json") |>
      httr2::req_body_json(body) |>
      httr2::req_timeout(30) |>
      httr2::req_error(is_error = function(resp) FALSE) |>
      httr2::req_perform(path = tmp)
  }, error = function(e) NULL)
  if (is.null(resp)) return(.schema_search)
  if (httr2::resp_status(resp) != 200) {
    warning(sprintf("GovInfo search returned HTTP %d", httr2::resp_status(resp)))
    return(.schema_search)
  }
  res <- jsonlite::fromJSON(tmp, simplifyVector = TRUE)

  if (is.null(res$results) || length(res$results) == 0) return(.schema_search)

  d <- res$results
  tibble(
    title = as.character(.safe_col(d, "title")),
    packageId = as.character(.safe_col(d, "packageId")),
    collectionCode = as.character(.safe_col(d, "collectionCode")),
    dateIssued = as.Date(.safe_col(d, "dateIssued")),
    governmentAuthor = vapply(
      seq_len(nrow(d)),
      function(i) {
        ga <- d$governmentAuthor
        if (is.list(ga)) paste(ga[[i]], collapse = "; ") else as.character(ga[i])
      },
      character(1)
    ),
    category = as.character(.safe_col(d, "category"))
  )
}

# == Context ===================================================================

#' Return the full source of this client for LLM context
#'
#' @return character string of the source file
govinfo_context <- function() {
  f <- system.file("source", "govinfo.gov.R", package = "govinfo.gov", mustWork = FALSE)
  if (f == "") {
    sf <- sys.frame(1)$ofile %||% ""
    if (nzchar(sf)) f <- sf
  }
  if (nzchar(f)) paste(readLines(f, warn = FALSE), collapse = "\n") else
    "Source not found. Load from inst/source/govinfo.gov.R"
}
