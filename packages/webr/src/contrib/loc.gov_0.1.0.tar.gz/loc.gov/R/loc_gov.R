# loc.gov.R
# Self-contained Library of Congress client.
# Covers: Chronicling America (historic newspapers) and LOC collections/search.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required



# == Private utilities =========================================================

`%||%` <- function(a, b) if (is.null(a)) b else a
.ua <- "support@scrapeable.com"
.chron_base <- "https://www.loc.gov"
.loc_base <- "https://www.loc.gov"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))
.fetch_json_nested <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE)


# == Schemas ===================================================================

.schema_pages <- tibble(
  title = character(), date = as.Date(character()),
  newspaper = character(), id = character(),
  image_url = character(), url = character()
)

.schema_newspapers <- tibble(
  lccn = character(), title = character(), place = character(),
  start_year = character(), end_year = character(), url = character()
)




#' Search historic newspaper pages on Chronicling America
#'
#' Full-text search across digitized newspaper pages from the Library of
#' Congress Chronicling America collection via loc.gov API.
#'
#' @param text Search text
#' @param page Page number of results (default 1, 40 results per page)
#' @return tibble: title, date, newspaper, id, image_url, url
chron_search <- function(text, page = 1) {
  url <- sprintf(
    "%s/collections/chronicling-america/?q=%s&sp=%d&fo=json",
    .chron_base, utils::URLencode(text, reserved = TRUE), as.integer(page)
  )
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_pages)

  results <- raw$results
  if (is.null(results) || length(results) == 0) return(.schema_pages)

  rows <- lapply(results, function(r) {
    tibble(
      title = as.character(r$title %||% NA_character_),
      date = tryCatch(as.Date(r$date %||% NA_character_), error = function(e) as.Date(NA)),
      newspaper = as.character(if (!is.null(r$partof)) paste(sapply(r$partof, function(x) if(is.list(x)) x$title %||% x else x), collapse="; ") else NA_character_),
      id = as.character(r$id %||% NA_character_),
      image_url = as.character(if (!is.null(r$image_url)) paste(r$image_url, collapse="; ") else NA_character_),
      url = as.character(r$url %||% r$id %||% NA_character_)
    )
  })
  bind_rows(rows)
}


#' List newspapers in Chronicling America
#'
#' Returns a tibble of digitized newspapers available via the LOC API.
#'
#' @param state Optional two-letter state abbreviation to filter (e.g., "NY")
#' @return tibble: lccn, title, place, start_year, end_year, url
chron_newspapers <- function(state = NULL) {
  url <- sprintf("%s/collections/chronicling-america/?fo=json&fa=original-format:newspaper", .chron_base)
  if (!is.null(state)) url <- paste0(url, "&fa=location:", utils::URLencode(state))
  url <- paste0(url, "&c=100")

  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_newspapers)

  results <- raw$results
  if (is.null(results) || length(results) == 0) return(.schema_newspapers)

  rows <- lapply(results, function(r) {
    # Extract LCCN from aka list
    lccn <- NA_character_
    if (!is.null(r$aka)) {
      lccn_match <- grep("lccn.loc.gov", unlist(r$aka), value = TRUE)
      if (length(lccn_match) > 0) lccn <- sub(".*/", "", lccn_match[1])
    }

    dates <- r$dates %||% list()
    tibble(
      lccn = as.character(lccn),
      title = as.character(r$title %||% NA_character_),
      place = as.character(if (!is.null(r$location)) paste(unlist(r$location), collapse="; ") else NA_character_),
      start_year = as.character(if (length(dates) > 0) dates[[1]] else NA_character_),
      end_year = as.character(if (length(dates) > 1) dates[[length(dates)]] else NA_character_),
      url = as.character(r$id %||% r$url %||% NA_character_)
    )
  })
  bind_rows(rows)
}


#' Search by date range and state
#'
#' @param text Search text
#' @param state Two-letter state abbreviation (e.g., "NY", "CA")
#' @param date_from Start date as "YYYY-MM-DD" (e.g., "1900-01-01")
#' @param date_to End date as "YYYY-MM-DD" (e.g., "1920-12-31")
#' @param page Page number (default 1)
#' @return tibble: title, date, newspaper, id, image_url, url
chron_search_advanced <- function(text, state = NULL, date_from = NULL,
                                  date_to = NULL, page = 1) {
  url <- sprintf(
    "%s/collections/chronicling-america/?q=%s&sp=%d&fo=json",
    .chron_base, utils::URLencode(text, reserved = TRUE), as.integer(page)
  )
  if (!is.null(state)) url <- paste0(url, "&fa=state:", utils::URLencode(state))
  if (!is.null(date_from) && !is.null(date_to)) {
    url <- paste0(url, "&dates=", date_from, "/", date_to)
  }

  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_pages)

  results <- raw$results
  if (is.null(results) || length(results) == 0) return(.schema_pages)

  rows <- lapply(results, function(r) {
    tibble(
      title = as.character(r$title %||% NA_character_),
      date = tryCatch(as.Date(r$date %||% NA_character_), error = function(e) as.Date(NA)),
      newspaper = as.character(if (!is.null(r$partof)) paste(sapply(r$partof, function(x) if(is.list(x)) x$title %||% x else x), collapse="; ") else NA_character_),
      id = as.character(r$id %||% NA_character_),
      image_url = as.character(if (!is.null(r$image_url)) paste(r$image_url, collapse="; ") else NA_character_),
      url = as.character(r$url %||% r$id %||% NA_character_)
    )
  })
  bind_rows(rows)
}


#' Search Library of Congress
#' @param query Search term
#' @param collection Collection (optional, e.g. 'newspapers', 'photos')
#' @return tibble of search results
loc_search <- function(query, collection = NULL) {
  if (!is.null(collection)) {
    url <- sprintf("%s/%s/?q=%s&fo=json&c=25", .loc_base, collection, URLencode(query, TRUE))
  } else {
    url <- sprintf("%s/search/?q=%s&fo=json&c=25", .loc_base, URLencode(query, TRUE))
  }
  raw <- .fetch_json(url)
  results <- raw$results
  if (length(results) == 0) return(tibble::tibble(id = character(), title = character()))
  tibble::tibble(
    id = vapply(results, function(x) x$id %||% NA_character_, character(1)),
    title = vapply(results, function(x) {
      if (is.list(x$title) || length(x$title) > 1) x$title[[1]] else x$title %||% NA_character_
    }, character(1)),
    date = vapply(results, function(x) x$date %||% NA_character_, character(1)),
    type = vapply(results, function(x) {
      if (is.list(x$original_format)) paste(unlist(x$original_format), collapse = ", ") else x$original_format %||% NA_character_
    }, character(1))
  )
}


#' List Library of Congress collections
#'
#' Returns available digital collections.
#'
#' @return tibble: id, title, description, count
loc_collections <- function() {
  schema <- tibble(id = character(), title = character(),
                   description = character(), count = integer())
  url <- sprintf("%s/collections/?fo=json&c=50", .loc_base)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$results) || length(raw$results) == 0) return(schema)
  results <- raw$results
  tibble(
    id = vapply(results, function(x) as.character(x$id %||% NA), character(1)),
    title = vapply(results, function(x) {
      t <- x$title
      if (is.list(t) || length(t) > 1) as.character(t[[1]]) else as.character(t %||% NA)
    }, character(1)),
    description = vapply(results, function(x) {
      d <- x$description
      if (is.list(d) || length(d) > 1) as.character(d[[1]]) else as.character(d %||% NA)
    }, character(1)),
    count = vapply(results, function(x) as.integer(x$count %||% NA), integer(1))
  )
}


# == Context ===================================================================

#' Generate LLM-friendly context for loc.gov
#'
#' @return Character string with full function signatures and bodies
loc_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/loc.gov.R"
  if (!file.exists(src_file)) {
    cat("# loc.gov context - source not found\n")
    return(invisible("# loc.gov context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

