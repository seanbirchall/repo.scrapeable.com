# == Schemas ===================================================================

.schema_datasets <- tibble::tibble(
  id = character(), name = character(), title = character(),
  organization = character(), num_resources = integer(),
  metadata_created = as.POSIXct(character()), notes = character()
)

.schema_resources <- tibble::tibble(
  id = character(), name = character(), format = character(),
  url = character(), description = character(),
  created = as.POSIXct(character()), size = numeric()
)

.schema_organizations <- tibble::tibble(
  id = character(), name = character(), title = character(),
  package_count = integer(), description = character()
)

.schema_tags <- tibble::tibble(
  id = character(), name = character()
)

# == Public functions ==========================================================

#' Search SBA datasets
#'
#' Searches the SBA open data catalog (data.sba.gov). Covers loan programs
#' (7a, 504, PPP, EIDL), disaster loans, size standards, HUBZone data, and more.
#'
#' @param query Search term (e.g. "loan", "disaster", "ppp", "size standards")
#' @param organization Filter by SBA office slug (e.g. "office-of-capital-access",
#'   "advocacy", "disaster"). Use sba_organizations() to see all.
#' @param tag Filter by tag (e.g. "sba", "disaster-loan", "covid-19")
#' @param rows Number of results (default 50, max 1000)
#' @param start Offset for pagination (default 0)
#' @return tibble: id, name, title, organization, num_resources,
#'   metadata_created (POSIXct), notes
#' @export
sba_search <- function(query = NULL, organization = NULL, tag = NULL,
                       rows = 50, start = 0) {
  fq_parts <- character()
  if (!is.null(organization)) fq_parts <- c(fq_parts, paste0("organization:", organization))
  if (!is.null(tag)) fq_parts <- c(fq_parts, paste0("tags:", tag))
  fq <- if (length(fq_parts) > 0) paste(fq_parts, collapse = " ") else NULL

  url <- .sba_url("package_search",
    q     = if (!is.null(query)) utils::URLencode(query, reserved = TRUE) else NULL,
    fq    = if (!is.null(fq)) utils::URLencode(fq, reserved = TRUE) else NULL,
    rows  = rows,
    start = start
  )

  result <- .sba_result(url)
  if (is.null(result)) return(.schema_datasets)

  datasets <- result$results
  if (length(datasets) == 0) return(.schema_datasets)

  tibble::tibble(
    id               = vapply(datasets, function(d) d$id %||% NA_character_, character(1)),
    name             = vapply(datasets, function(d) d$name %||% NA_character_, character(1)),
    title            = vapply(datasets, function(d) d$title %||% NA_character_, character(1)),
    organization     = vapply(datasets, function(d) d$organization$name %||% NA_character_, character(1)),
    num_resources    = vapply(datasets, function(d) as.integer(d$num_resources %||% 0L), integer(1)),
    metadata_created = as.POSIXct(vapply(datasets, function(d) d$metadata_created %||% NA_character_, character(1))),
    notes            = vapply(datasets, function(d) {
      n <- d$notes %||% ""
      if (nchar(n) > 300) paste0(substr(n, 1, 300), "...") else n
    }, character(1))
  )
}

#' List all SBA dataset names
#'
#' Returns a character vector of all dataset identifiers available on data.sba.gov.
#'
#' @return character vector of dataset names/slugs
#' @export
sba_list <- function() {
  result <- .sba_result(.sba_url("package_list"))
  if (is.null(result)) return(character())
  as.character(unlist(result))
}

#' Get full details for an SBA dataset
#'
#' Returns metadata and resource list for a single dataset.
#'
#' @param id Dataset name or UUID (e.g. "7-a-504-foia", "ppp-foia", "disaster-loan-data")
#' @return tibble: one row with id, name, title, organization,
#'   num_resources, metadata_created, notes
#' @export
sba_dataset <- function(id) {
  result <- .sba_result(.sba_url("package_show", id = id))
  if (is.null(result)) return(.schema_datasets)

  tibble::tibble(
    id               = result$id %||% NA_character_,
    name             = result$name %||% NA_character_,
    title            = result$title %||% NA_character_,
    organization     = result$organization$name %||% NA_character_,
    num_resources    = as.integer(result$num_resources %||% 0L),
    metadata_created = as.POSIXct(result$metadata_created %||% NA_character_),
    notes            = result$notes %||% NA_character_
  )
}

#' Get resources (downloadable files) for an SBA dataset
#'
#' Lists all downloadable files (CSV, XLSX, JSON, etc.) within a dataset.
#'
#' @param id Dataset name or UUID (e.g. "7-a-504-foia", "ppp-foia")
#' @return tibble: id, name, format, url, description, created, size
#' @export
sba_resources <- function(id) {
  result <- .sba_result(.sba_url("package_show", id = id))
  if (is.null(result)) return(.schema_resources)

  res <- result$resources
  if (length(res) == 0) return(.schema_resources)

  tibble::tibble(
    id          = vapply(res, function(r) r$id %||% NA_character_, character(1)),
    name        = vapply(res, function(r) r$name %||% NA_character_, character(1)),
    format      = vapply(res, function(r) toupper(r$format %||% ""), character(1)),
    url         = vapply(res, function(r) r$url %||% NA_character_, character(1)),
    description = vapply(res, function(r) {
      d <- r$description %||% ""
      if (nchar(d) > 200) paste0(substr(d, 1, 200), "...") else d
    }, character(1)),
    created     = as.POSIXct(vapply(res, function(r) r$created %||% NA_character_, character(1))),
    size        = vapply(res, function(r) as.numeric(r$size %||% NA_real_), numeric(1))
  )
}

#' List SBA organizations (offices)
#'
#' Returns all SBA organizational units that publish data on data.sba.gov.
#'
#' @param all_fields If TRUE, returns full details; if FALSE just names
#' @return tibble: id, name, title, package_count, description (if all_fields)
#'   or character vector of names (if not)
#' @export
sba_organizations <- function(all_fields = TRUE) {
  if (!all_fields) {
    result <- .sba_result(.sba_url("organization_list"))
    if (is.null(result)) return(character())
    return(as.character(unlist(result)))
  }

  result <- .sba_result(.sba_url("organization_list", all_fields = "true"))
  if (is.null(result)) return(.schema_organizations)

  orgs <- result
  if (length(orgs) == 0) return(.schema_organizations)

  tibble::tibble(
    id            = vapply(orgs, function(o) o$id %||% NA_character_, character(1)),
    name          = vapply(orgs, function(o) o$name %||% NA_character_, character(1)),
    title         = vapply(orgs, function(o) o$title %||% NA_character_, character(1)),
    package_count = vapply(orgs, function(o) as.integer(o$package_count %||% 0L), integer(1)),
    description   = vapply(orgs, function(o) {
      d <- o$description %||% ""
      if (nchar(d) > 200) paste0(substr(d, 1, 200), "...") else d
    }, character(1))
  )
}

#' List SBA dataset tags
#'
#' Returns all tags used to categorize datasets on data.sba.gov.
#'
#' @return character vector of tag names
#' @export
sba_tags <- function() {
  result <- .sba_result(.sba_url("tag_list"))
  if (is.null(result)) return(character())
  as.character(unlist(result))
}

#' Download and parse an SBA CSV resource
#'
#' Downloads a CSV resource by URL and returns it as a tibble.
#' For XLSX resources, downloads the file and returns the file path.
#'
#' @param url Full URL to the resource (from sba_resources()$url)
#' @param ... Additional arguments passed to read.csv()
#' @return tibble of parsed CSV data, or file path for non-CSV formats
#' @export
sba_download <- function(url, ...) {
  ext <- if (grepl("\\.xlsx?$", url, ignore.case = TRUE)) ".xlsx"
         else if (grepl("\\.csv$", url, ignore.case = TRUE)) ".csv"
         else ".dat"

  tmp <- .fetch(url, ext = ext)

  if (ext == ".csv") {
    df <- utils::read.csv(tmp, stringsAsFactors = FALSE, ...)
    return(tibble::as_tibble(df))
  }

  message("File downloaded to: ", tmp)
  invisible(tmp)
}

#' List SBA loan program datasets
#'
#' Searches for datasets related to SBA loan programs (7a, 504, PPP, EIDL,
#' disaster loans, microloans).
#'
#' @return tibble of loan-related datasets
#' @export
sba_loan_programs <- function() {
  sba_search(query = "loan", rows = 100)
}

#' Get SBA small business size standards dataset
#'
#' Returns metadata and resources for the current small business size standards.
#'
#' @return tibble of resources for the size standards dataset
#' @export
sba_size_standards <- function() {
  sba_resources("small-business-size-standards")
}

#' Get SBA Paycheck Protection Program (PPP) FOIA resources
#'
#' Returns downloadable resources for PPP loan data released under FOIA.
#'
#' @return tibble of PPP FOIA data resources
#' @export
sba_ppp <- function() {
  sba_resources("ppp-foia")
}

#' Get SBA disaster loan data resources
#'
#' Returns downloadable resources for historical SBA disaster loan data.
#'
#' @return tibble of disaster loan data resources
#' @export
sba_disaster_loans <- function() {
  sba_resources("disaster-loan-data")
}

#' Return full function source for LLM context
#'
#' Reads this package's source and returns all public function signatures
#' with their roxygen documentation.
#'
#' @return character string of all public function definitions (invisibly)
#' @export
sba_context <- function() {
  .build_context("sba", header_lines = c(
    "# sba.gov R client",
    "# SBA (Small Business Administration) Open Data Portal",
    "# API: CKAN v3 at data.sba.gov",
    "# Auth: none required"
  ))
}
