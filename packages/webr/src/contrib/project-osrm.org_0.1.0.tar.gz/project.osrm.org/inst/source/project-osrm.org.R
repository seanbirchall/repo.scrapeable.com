# project-osrm.org.R - Self-contained project-osrm.org client

library(httr2)
library(jsonlite)
library(tibble)
library(dplyr)


# project-osrm-org.R
# Self-contained OSRM routing client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required
# API: https://router.project-osrm.org


.ua <- "support@scrapeable.com"
.osrm_base <- "https://router.project-osrm.org"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |> httr2::req_headers(`User-Agent` = .ua) |> httr2::req_perform(path = tmp)
  tmp
}
.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE)
`%||%` <- function(a, b) if (is.null(a) || length(a) == 0) b else a

.schema_route <- tibble(
  distance_m = numeric(), duration_s = numeric(),
  origin = character(), destination = character()
)

.schema_table <- tibble(
  origin_index = integer(), dest_index = integer(),
  duration_s = numeric(), distance_m = numeric()
)


#' Calculate driving route between points
#'
#' @param coords Matrix or data frame with columns longitude, latitude.
#'   Or a list of c(lon, lat) vectors. Minimum 2 points.
#' @param profile "driving" (default), "walking", "cycling"
#' @param overview Route geometry: "full", "simplified" (default), or "false"
#' @return tibble: distance_m, duration_s, origin, destination
osrm_route <- function(coords, profile = "driving", overview = "simplified") {
  if (is.data.frame(coords) || is.matrix(coords)) {
    coord_str <- paste(sprintf("%s,%s", coords[, 1], coords[, 2]), collapse = ";")
  } else {
    coord_str <- paste(vapply(coords, function(c) paste(c, collapse = ","), character(1)), collapse = ";")
  }
  url <- sprintf("%s/route/v1/%s/%s?overview=%s&steps=false",
                 .osrm_base, profile, coord_str, overview)
  raw <- tryCatch(.fetch_json(url), error = function(e) { warning("OSRM error: ", e$message); NULL })
  if (is.null(raw) || raw$code != "Ok") return(.schema_route)

  routes <- raw$routes
  if (is.null(routes) || length(routes) == 0) return(.schema_route)

  tibble(
    distance_m  = vapply(routes, function(r) as.numeric(r$distance %||% NA_real_), numeric(1)),
    duration_s  = vapply(routes, function(r) as.numeric(r$duration %||% NA_real_), numeric(1)),
    origin      = coord_str,
    destination = coord_str
  )
}

#' Calculate distance/duration matrix
#'
#' @param coords Matrix or data frame with lon, lat columns
#' @param profile "driving" (default)
#' @return tibble: origin_index, dest_index, duration_s, distance_m
osrm_table <- function(coords, profile = "driving") {
  if (is.data.frame(coords) || is.matrix(coords)) {
    coord_str <- paste(sprintf("%s,%s", coords[, 1], coords[, 2]), collapse = ";")
  } else {
    coord_str <- paste(vapply(coords, function(c) paste(c, collapse = ","), character(1)), collapse = ";")
  }
  url <- sprintf("%s/table/v1/%s/%s?annotations=duration,distance",
                 .osrm_base, profile, coord_str)
  raw <- tryCatch(.fetch_json(url), error = function(e) { warning("OSRM error: ", e$message); NULL })
  if (is.null(raw) || raw$code != "Ok") return(.schema_table)

  durations <- raw$durations
  distances <- raw$distances
  n <- length(durations)
  results <- list()
  for (i in seq_len(n)) {
    for (j in seq_len(n)) {
      results[[length(results) + 1]] <- tibble(
        origin_index = as.integer(i), dest_index = as.integer(j),
        duration_s = as.numeric(durations[[i]][[j]] %||% NA_real_),
        distance_m = as.numeric(distances[[i]][[j]] %||% NA_real_)
      )
    }
  }
  bind_rows(results)
}

#' Get nearest road point
#'
#' @param longitude Longitude
#' @param latitude Latitude
#' @param profile "driving" (default)
#' @return tibble: one row with snapped lon/lat, distance, name
osrm_nearest <- function(longitude, latitude, profile = "driving") {
  url <- sprintf("%s/nearest/v1/%s/%s,%s", .osrm_base, profile, longitude, latitude)
  raw <- tryCatch(.fetch_json(url), error = function(e) { warning("OSRM error: ", e$message); NULL })
  if (is.null(raw) || raw$code != "Ok") return(tibble(longitude = numeric(), latitude = numeric(), distance = numeric(), name = character()))
  w <- raw$waypoints[[1]]
  tibble(longitude = as.numeric(w$location[[1]]), latitude = as.numeric(w$location[[2]]),
         distance = as.numeric(w$distance), name = w$name %||% NA_character_)
}

# == Context ===================================================================

#' Generate LLM-friendly context for project-osrm.org
#'
#' @return Character string with full function signatures and bodies
osrm_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/project-osrm.org.R"
  if (!file.exists(src_file)) {
    cat("# project-osrm.org context - source not found\n")
    return(invisible("# project-osrm.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

