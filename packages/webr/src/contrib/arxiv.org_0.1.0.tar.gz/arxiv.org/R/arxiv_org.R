# arxiv.org.R - Self-contained arxiv.org client



# arxiv-org.R
# Self-contained arXiv API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble, xml2
# Auth: none (public data)
# Rate limits: 1 request per 3 seconds recommended


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.arxiv_base <- "http://export.arxiv.org/api/query"

.fetch <- function(url, ext = ".xml") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url, ext = ".json"))

`%||%` <- function(a, b) if (is.null(a)) b else a

# == Schemas ===================================================================

.schema_papers <- tibble(
  id = character(), title = character(), summary = character(),
  authors = character(), published = as.Date(character()),
  updated = as.Date(character()), categories = character(),
  pdf_url = character(), doi = character()
)

# == Public functions ==========================================================


#' Search arXiv for papers
#'
#' Queries the arXiv API using Atom feed format. Supports field-specific
#' searches: all, ti (title), au (author), abs (abstract), cat (category).
#'
#' @param query Search query. Use "all:term" for general search, "ti:term"
#'   for title, "au:name" for author, "cat:cs.AI" for category.
#' @param max_results Maximum number of results. Default 10, max 2000.
#' @param start Starting index for pagination. Default 0.
#' @param sort_by Sort by "relevance", "lastUpdatedDate", or "submittedDate".
#'   Default "relevance".
#' @return tibble: id, title, summary, authors, published, updated,
#'   categories, pdf_url, doi
arxiv_search <- function(query, max_results = 10, start = 0,
                         sort_by = "relevance") {
  url <- sprintf(
    "%s?search_query=%s&start=%d&max_results=%d&sortBy=%s&sortOrder=descending",
    .arxiv_base, utils::URLencode(query, reserved = TRUE),
    as.integer(start), as.integer(max_results), sort_by
  )

  tmp <- .fetch(url, ext = ".xml")
  doc <- xml2::read_xml(tmp)
  ns <- xml2::xml_ns(doc)

  entries <- xml2::xml_find_all(doc, ".//d1:entry", ns)
  if (length(entries) == 0) return(.schema_papers)

  rows <- lapply(entries, function(entry) {
    id_raw <- xml2::xml_text(xml2::xml_find_first(entry, "d1:id", ns))
    id_clean <- sub("http://arxiv.org/abs/", "", id_raw)
    id_clean <- sub("v\\d+$", "", id_clean)

    title <- xml2::xml_text(xml2::xml_find_first(entry, "d1:title", ns))
    title <- gsub("\\s+", " ", trimws(title))

    summary <- xml2::xml_text(xml2::xml_find_first(entry, "d1:summary", ns))
    summary <- gsub("\\s+", " ", trimws(summary))

    author_nodes <- xml2::xml_find_all(entry, "d1:author/d1:name", ns)
    authors <- paste(xml2::xml_text(author_nodes), collapse = "; ")

    published <- tryCatch(
      as.Date(xml2::xml_text(xml2::xml_find_first(entry, "d1:published", ns))),
      error = function(e) as.Date(NA)
    )
    updated <- tryCatch(
      as.Date(xml2::xml_text(xml2::xml_find_first(entry, "d1:updated", ns))),
      error = function(e) as.Date(NA)
    )

    cat_nodes <- xml2::xml_find_all(entry, "d1:category", ns)
    categories <- paste(xml2::xml_attr(cat_nodes, "term"), collapse = "; ")

    links <- xml2::xml_find_all(entry, "d1:link", ns)
    link_titles <- xml2::xml_attr(links, "title")
    pdf_idx <- which(!is.na(link_titles) & link_titles == "pdf")
    pdf_url <- if (length(pdf_idx) > 0) xml2::xml_attr(links[[pdf_idx[1]]], "href") else NA_character_

    doi_node <- xml2::xml_find_first(entry, "arxiv:doi", ns)
    doi <- if (!inherits(doi_node, "xml_missing") && !is.na(doi_node)) xml2::xml_text(doi_node) else NA_character_

    tibble(
      id = id_clean, title = title, summary = summary, authors = authors,
      published = published, updated = updated, categories = categories,
      pdf_url = pdf_url, doi = doi
    )
  })

  bind_rows(rows)
}

#' Get a single arXiv paper by ID
#'
#' @param arxiv_id arXiv paper ID (e.g., "2301.12345" or "cs/0601001")
#' @return tibble with one row: id, title, summary, authors, published,
#'   updated, categories, pdf_url, doi
arxiv_paper <- function(arxiv_id) {
  arxiv_search(paste0("id:", arxiv_id), max_results = 1)
}

#' Get recent papers from an arXiv category
#'
#' @param category arXiv category (e.g., "cs.AI", "stat.ML", "physics.gen-ph",
#'   "q-bio.BM", "econ.GN"). See https://arxiv.org/category_taxonomy
#' @param max_results Number of papers (default 25, max 2000)
#' @return tibble: id, title, summary, authors, published, updated,
#'   categories, pdf_url, doi
arxiv_recent <- function(category, max_results = 25) {
  arxiv_search(paste0("cat:", category), max_results = max_results,
               sort_by = "submittedDate")
}

#' Search arXiv by author name
#'
#' @param author Author name (e.g., "Hinton" or "Geoffrey Hinton")
#' @param max_results Number of results (default 25)
#' @return tibble: id, title, summary, authors, published, updated,
#'   categories, pdf_url, doi
arxiv_author <- function(author, max_results = 25) {
  arxiv_search(paste0("au:", author), max_results = max_results,
               sort_by = "submittedDate")
}

# == Context ===================================================================

#' Generate LLM-friendly context for arxiv.org
#'
#' @return Character string with full function signatures and bodies
arxiv_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/arxiv.org.R"
  if (!file.exists(src_file)) {
    cat("# arxiv.org context - source not found\n")
    return(invisible("# arxiv.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

