# abs.gov.au.R - Self-contained abs.gov.au client


`%||%` <- function(a, b) if (is.null(a)) b else a


# abs.R
# Self-contained Australian Bureau of Statistics (ABS) SDMX API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required
# Rate limits: not documented, be respectful
# Format: SDMX-CSV


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.abs_base <- "https://data.api.abs.gov.au/rest"

.fetch <- function(url, ext = ".csv") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua, Accept = "application/vnd.sdmx.data+csv;file=true") |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_csv <- function(url) {
  f <- .fetch(url, ext = ".csv")
  tryCatch(
    utils::read.csv(f, stringsAsFactors = FALSE) |> as_tibble(),
    error = function(e) tibble()
  )
}

.fetch_json <- function(url) {
  tmp <- tempfile(fileext = ".json")
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua, Accept = "application/json") |>
    httr2::req_perform(path = tmp)
  jsonlite::fromJSON(tmp)
}

# == Schemas ===================================================================

.schema_data <- tibble(
  DATAFLOW = character(), FREQ = character(), TIME_PERIOD = character(),
  OBS_VALUE = numeric()
)

.schema_dataflows <- tibble(
  id = character(), name = character(), version = character(),
  agencyID = character()
)

# == Data ======================================================================

#' Fetch ABS SDMX data
#'
#' @param dataflow Dataflow identifier (e.g. "CPI", "LF", "ERP").
#'   Use abs_dataflows() to discover available dataflows.
#' @param key SDMX key path (e.g. "1.10001.10.Q" or ".." for all).
#'   Default ".." returns all dimensions.
#' @param start Start period (e.g. "2023-Q1", "2023-01", "2023")
#' @param end End period
#' @param agency Agency ID (default "ABS")
#' @param version Dataflow version (default "1.0.0")
#' @return tibble: SDMX-CSV columns including DATAFLOW, TIME_PERIOD, OBS_VALUE
abs_data <- function(dataflow, key = "..", start = NULL, end = NULL,
                     agency = "ABS", version = "1.0.0") {
  url <- paste0(.abs_base, "/data/", agency, ",", dataflow, ",", version, "/", key)
  params <- character()
  if (!is.null(start)) params <- c(params, paste0("startPeriod=", start))
  if (!is.null(end)) params <- c(params, paste0("endPeriod=", end))
  params <- c(params, "dimensionAtObservation=AllDimensions")
  if (length(params) > 0) url <- paste0(url, "?", paste(params, collapse = "&"))

  df <- .fetch_csv(url)
  if (nrow(df) == 0) return(.schema_data)

  if ("OBS_VALUE" %in% names(df)) {
    df$OBS_VALUE <- as.numeric(df$OBS_VALUE)
  }
  df
}

# == Dataflows =================================================================

#' List available ABS SDMX dataflows
#'
#' @return tibble: id, name, version, agencyID
abs_dataflows <- function() {
  url <- paste0(.abs_base, "/dataflow/ABS")
  tmp <- tempfile(fileext = ".json")
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua,
                       Accept = "application/vnd.sdmx.structure+json") |>
    httr2::req_perform(path = tmp)
  raw <- jsonlite::fromJSON(tmp)

  dfs <- tryCatch({
    structures <- raw$data$dataflows %||% raw$`Dataflow`
    if (is.null(structures)) structures <- raw$data$dataStructures
    structures
  }, error = function(e) NULL)

  if (is.null(dfs) || length(dfs) == 0) return(.schema_dataflows)

  # Handle nested SDMX JSON structure
  if (is.data.frame(dfs)) {
    nm <- if ("name" %in% names(dfs)) {
      vapply(dfs$name, function(x) {
        if (is.list(x) || is.data.frame(x)) as.character(x[[1]])
        else as.character(x)
      }, character(1))
    } else NA_character_

    return(tibble(
      id = as.character(dfs$id %||% NA_character_),
      name = nm,
      version = as.character(dfs$version %||% NA_character_),
      agencyID = as.character(dfs$agencyID %||% NA_character_)
    ))
  }

  .schema_dataflows
}

# == CPI convenience ===========================================================

#' Fetch ABS Consumer Price Index data
#'
#' Convenience wrapper for CPI dataflow.
#'
#' @param start Start period (e.g. "2020")
#' @return tibble: SDMX-CSV format with CPI data
abs_cpi <- function(start = "2020") {
  tryCatch(
    abs_data("CPI", key = "..", start = start),
    error = function(e) .schema_data
  )
}

# == Context ===================================================================

#' Generate LLM-friendly context for abs.gov.au
#'
#' @return Character string with full function signatures and bodies
abs_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/abs.gov.au.R"
  if (!file.exists(src_file)) {
    cat("# abs.gov.au context - source not found\n")
    return(invisible("# abs.gov.au context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

