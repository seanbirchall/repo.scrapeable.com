# ripe.net.R - Self-contained ripe.net client



# ripe-net.R
# Self-contained RIPE Stat API client for network data.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.ripe_base <- "https://stat.ripe.net/data"

`%||%` <- function(a, b) if (is.null(a)) b else a

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))

# == Schemas ===================================================================

.schema_prefixes <- tibble(
  prefix = character(), timelines = character()
)

.schema_country_resources <- tibble(
  resource = character(), type = character(), status = character()
)

.schema_whois <- tibble(
  key = character(), value = character()
)

.schema_geoloc <- tibble(
  prefix = character(), latitude = numeric(), longitude = numeric(),
  city = character(), country = character()
)


# == Announced Prefixes ========================================================

#' Get announced IP prefixes for an ASN
#'
#' Queries the RIPE Stat API for IP prefixes announced by an ASN.
#'
#' @param resource ASN number (e.g. "AS3333" or just "3333") or IP prefix
#' @return tibble: prefix, timelines
ripe_prefixes <- function(resource) {
  url <- sprintf("%s/announced-prefixes/data.json?resource=%s&sourceapp=%s",
                 .ripe_base, utils::URLencode(resource), .ua)
  raw <- tryCatch(.fetch_json(url), error = function(e) {
    message("RIPE prefixes failed: ", e$message)
    return(NULL)
  })
  if (is.null(raw)) return(.schema_prefixes)

  prefixes <- raw$data$prefixes
  if (is.null(prefixes) || length(prefixes) == 0) return(.schema_prefixes)

  tibble(
    prefix    = as.character(prefixes$prefix %||% NA_character_),
    timelines = vapply(prefixes$timelines, function(t) {
      if (is.null(t) || length(t) == 0) return(NA_character_)
      paste(sprintf("%s-%s", t$starttime %||% "?", t$endtime %||% "?"), collapse = "; ")
    }, character(1))
  )
}

# == Country Resources =========================================================

#' Get internet resources for a country
#'
#' @param country Two-letter country code (e.g. "NL", "US", "DE")
#' @return tibble: resource, type, status
ripe_country_resources <- function(country) {
  url <- sprintf("%s/country-resource-list/data.json?resource=%s&sourceapp=%s",
                 .ripe_base, utils::URLencode(toupper(country)), .ua)
  raw <- tryCatch(.fetch_json(url), error = function(e) {
    message("RIPE country resources failed: ", e$message)
    return(NULL)
  })
  if (is.null(raw)) return(.schema_country_resources)

  resources <- raw$data$resources
  if (is.null(resources)) return(.schema_country_resources)

  rows <- list()
  for (rtype in names(resources)) {
    vals <- resources[[rtype]]
    if (length(vals) > 0) {
      rows[[length(rows) + 1]] <- tibble(
        resource = as.character(vals),
        type     = rtype,
        status   = "active"
      )
    }
  }
  if (length(rows) == 0) return(.schema_country_resources)
  bind_rows(rows)
}

# == WHOIS =====================================================================

#' WHOIS lookup via RIPE Stat
#'
#' @param resource IP address, prefix, or ASN (e.g. "193.0.6.139", "AS3333")
#' @return tibble: key, value
ripe_whois <- function(resource) {
  url <- sprintf("%s/whois/data.json?resource=%s&sourceapp=%s",
                 .ripe_base, utils::URLencode(resource), .ua)
  raw <- tryCatch(.fetch_json(url), error = function(e) {
    message("RIPE whois failed: ", e$message)
    return(NULL)
  })
  if (is.null(raw)) return(.schema_whois)

  records <- raw$data$records
  if (is.null(records) || length(records) == 0) return(.schema_whois)

  rows <- list()
  for (rec_group in records) {
    if (is.data.frame(rec_group)) {
      rows[[length(rows) + 1]] <- tibble(
        key   = as.character(rec_group$key %||% NA_character_),
        value = as.character(rec_group$value %||% NA_character_)
      )
    }
  }
  if (length(rows) == 0) return(.schema_whois)
  bind_rows(rows)
}

# == Context ===================================================================

#' Generate LLM-friendly context for ripe.net
#'
#' @return Character string with full function signatures and bodies
ripe_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/ripe.net.R"
  if (!file.exists(src_file)) {
    cat("# ripe.net context - source not found\n")
    return(invisible("# ripe.net context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

