#' List available DOE data sources
#'
#' @return A tibble describing available endpoints.
#' @export
doe_list <- function() {
  tibble::tibble(
    dataset = c("afdc_stations", "fitara_milestones"),
    description = c(
      "Alternative fuel stations nationwide (EV, CNG, LPG, H2, etc.)",
      "DOE FITARA IT modernization milestones"
    ),
    source = c(
      "NREL Alternative Fuels Data Center API",
      "energy.gov/digitalstrategy"
    ),
    records = c("~100,000+", "~2"),
    auth = c("API key (DEMO_KEY for testing)", "none")
  )
}

#' Search alternative fuel stations
#'
#' @param state Character. Two-letter state abbreviation.
#' @param fuel_type Character. Fuel type code: "ELEC", "CNG", "LPG", "BD",
#'   "E85", "HY", "LNG", "RD". Default "ELEC".
#' @param city Character. City name.
#' @param zip Character. ZIP code.
#' @param status Character. "E" (open), "P" (planned), "T" (temp unavailable).
#' @param limit Integer. Maximum results (default 200).
#' @param api_key Character. NREL API key.
#' @return A tibble of fuel stations.
#' @export
doe_search <- function(state = NULL, fuel_type = "ELEC", city = NULL,
                       zip = NULL, status = "E", limit = 200,
                       api_key = NULL) {
  params <- list(
    fuel_type = fuel_type,
    status = status,
    limit = min(limit, 200)
  )
  if (!is.null(state)) params$state <- toupper(state)
  if (!is.null(city))  params$city <- city
  if (!is.null(zip))   params$zip <- zip

  raw <- .doe_get_json(paste0(.afdc_base, ".json"), params, api_key)
  .doe_parse_stations(raw$fuel_stations)
}

#' Get fuel station by ID
#'
#' @param station_id Integer. Station ID.
#' @param api_key Character. NREL API key.
#' @return A tibble (1 row) with station details.
#' @export
doe_station <- function(station_id, api_key = NULL) {
  url <- paste0(.afdc_base, "/", station_id, ".json")
  raw <- .doe_get_json(url, api_key = api_key)
  .doe_parse_stations(list(raw$alt_fuel_station))
}

#' Get fuel station counts by state
#'
#' @param fuel_type Character. Fuel type code (default "ELEC").
#' @param api_key Character. NREL API key.
#' @return A tibble with columns: state, total_stations.
#' @export
doe_station_counts <- function(fuel_type = "ELEC", api_key = NULL) {
  states <- c("AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA",
              "HI","ID","IL","IN","IA","KS","KY","LA","ME","MD",
              "MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ",
              "NM","NY","NC","ND","OH","OK","OR","PA","RI","SC",
              "SD","TN","TX","UT","VT","VA","WA","WV","WI","WY","DC")
  counts <- list()
  for (st in states) {
    raw <- .doe_get_json(paste0(.afdc_base, ".json"),
                         list(fuel_type = fuel_type, status = "E",
                              state = st, limit = 1),
                         api_key)
    counts[[st]] <- raw$total_results %||% 0L
  }
  tibble::tibble(
    state = names(counts),
    total_stations = as.integer(unlist(counts))
  ) |> filter(.data$total_stations > 0) |>
    arrange(desc(.data$total_stations))
}

#' Get nearest fuel stations to coordinates
#'
#' @param latitude Numeric. Latitude.
#' @param longitude Numeric. Longitude.
#' @param radius Numeric. Search radius in miles (default 10).
#' @param fuel_type Character. Fuel type code (default "ELEC").
#' @param limit Integer. Maximum results (default 20).
#' @param api_key Character. NREL API key.
#' @return A tibble of nearby stations.
#' @export
doe_nearest <- function(latitude, longitude, radius = 10,
                        fuel_type = "ELEC", limit = 20, api_key = NULL) {
  url <- paste0(.afdc_base, "/nearest.json")
  params <- list(
    latitude = latitude,
    longitude = longitude,
    radius = radius,
    fuel_type = fuel_type,
    limit = min(limit, 200)
  )
  raw <- .doe_get_json(url, params, api_key)
  .doe_parse_stations(raw$fuel_stations)
}

#' Get DOE FITARA IT milestones
#'
#' @return A tibble of FITARA milestones.
#' @export
doe_fitara <- function() {
  url <- "https://www.energy.gov/sites/default/files/2023-08/fitaramilestones8152023.json"
  tmp <- tempfile(fileext = ".json")
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_timeout(30) |>
    httr2::req_perform(path = tmp)

  raw <- jsonlite::fromJSON(tmp, simplifyVector = FALSE)
  milestones <- raw$milestones %||% list()
  if (length(milestones) == 0) return(tibble::tibble())

  bind_rows(lapply(milestones, function(m) {
    tibble::tibble(
      milestone_id   = as.integer(m$milestoneID %||% NA),
      description    = m$milestoneDesc %||% NA_character_,
      target_date    = m$`milestoneTargetC ompletionDate` %||%
                       m$milestoneTargetCompletionDate %||% NA_character_,
      status         = m$milestoneStatus %||% NA_character_,
      status_desc    = m$milestoneStatusDesc %||% NA_character_,
      baseline_area  = m$commonBaselineArea %||% NA_character_,
      dcoi_area      = m$dcoiArea %||% NA_character_
    )
  }))
}

#' Print energy.gov client context
#'
#' @return Character string of function signatures (invisibly).
#' @export
doe_context <- function() {
  src <- system.file("source", "doe.R", package = "energy.gov")
  if (src == "") {
    f <- sys.frame(sys.nframe())$ofile %||%
      attr(body(doe_context), "srcfile")$filename %||% ""
    if (nzchar(f)) src <- f
  }
  .build_context("energy.gov", src_file = if (nzchar(src)) src else NULL,
                 header_lines = c(
                   "# energy.gov -- Department of Energy R client",
                   "# AFDC: https://developer.nrel.gov/api/alt-fuel-stations/v1",
                   "# Auth: API key (DEMO_KEY for testing, register at developer.nrel.gov)"
                 ))
}
