# figshare.com.R - Self-contained figshare.com client



# figshare.R
# Self-contained Figshare API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required for public data
# Rate limits: not documented, be respectful


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.figshare_base <- "https://api.figshare.com/v2"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))

.post_json <- function(url, body) {
  tmp <- tempfile(fileext = ".json")
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua, `Content-Type` = "application/json") |>
    httr2::req_body_json(body) |>
    httr2::req_perform(path = tmp)
  jsonlite::fromJSON(tmp)
}

# == Schemas ===================================================================

.schema_articles <- tibble(
  id = integer(), title = character(), doi = character(),
  url = character(), published_date = as.Date(character()),
  defined_type_name = character()
)

.schema_article_detail <- tibble(
  id = integer(), title = character(), doi = character(),
  url = character(), published_date = as.Date(character()),
  description = character(), defined_type_name = character(),
  license = character(), authors = character(), tags = character(),
  citation = character()
)

# == Article search ============================================================

#' Search Figshare articles
#'
#' @param query Search query string (e.g. "climate", "genomics")
#' @param page_size Number of results per page (default 10, max 1000)
#' @param page Page number (default 1)
#' @return tibble: id, title, doi, url, published_date, defined_type_name
figshare_search <- function(query, page_size = 10, page = 1) {
  body <- list(search_for = query, page_size = page_size, page = page)
  raw <- .post_json(paste0(.figshare_base, "/articles/search"), body)
  if (is.null(raw) || length(raw) == 0) return(.schema_articles)

  as_tibble(raw) |>
    transmute(
      id = as.integer(id),
      title = as.character(title),
      doi = as.character(doi),
      url = as.character(url),
      published_date = tryCatch(as.Date(published_date), error = function(e) as.Date(NA)),
      defined_type_name = as.character(if ("defined_type_name" %in% names(raw)) defined_type_name else NA_character_)
    )
}


# == Article detail ============================================================

#' Fetch a single Figshare article by ID
#'
#' @param id Figshare article ID (integer)
#' @return tibble: one row with id, title, doi, url, published_date,
#'   description, defined_type_name, license, authors, tags, citation
figshare_article <- function(id) {
  url <- paste0(.figshare_base, "/articles/", id)
  raw <- .fetch_json(url)
  if (is.null(raw) || is.null(raw$id)) return(.schema_article_detail)

  auth_str <- if (!is.null(raw$authors) && is.data.frame(raw$authors)) {
    paste(raw$authors$full_name, collapse = "; ")
  } else NA_character_

  tag_str <- if (!is.null(raw$tags)) {
    paste(raw$tags, collapse = "; ")
  } else NA_character_

  lic_str <- if (!is.null(raw$license) && is.list(raw$license)) {
    as.character(raw$license$name %||% NA_character_)
  } else NA_character_

  tibble(
    id = as.integer(raw$id),
    title = as.character(raw$title %||% NA_character_),
    doi = as.character(raw$doi %||% NA_character_),
    url = as.character(raw$url %||% NA_character_),
    published_date = tryCatch(as.Date(raw$published_date), error = function(e) as.Date(NA)),
    description = as.character(raw$description %||% NA_character_),
    defined_type_name = as.character(raw$defined_type_name %||% NA_character_),
    license = lic_str,
    authors = auth_str,
    tags = tag_str,
    citation = as.character(raw$citation %||% NA_character_)
  )
}


# == Article files =============================================================

#' List files attached to a Figshare article
#'
#' @param id Figshare article ID (integer)
#' @return tibble: id, name, size, download_url, computed_md5
figshare_files <- function(id) {
  schema <- tibble(id = integer(), name = character(), size = numeric(),
                   download_url = character(), computed_md5 = character())
  url <- paste0(.figshare_base, "/articles/", id, "/files")
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || length(raw) == 0) return(schema)
  if (!is.data.frame(raw)) return(schema)

  as_tibble(raw) |>
    transmute(
      id = as.integer(id),
      name = as.character(if ("name" %in% names(raw)) name else NA_character_),
      size = as.numeric(if ("size" %in% names(raw)) size else NA_real_),
      download_url = as.character(if ("download_url" %in% names(raw)) download_url else NA_character_),
      computed_md5 = as.character(if ("computed_md5" %in% names(raw)) computed_md5 else NA_character_)
    )
}

# == Collections ===============================================================

#' Search Figshare collections
#'
#' @param query Search query string
#' @param page_size Number of results (default 10)
#' @param page Page number (default 1)
#' @return tibble: id, title, doi, url, published_date, articles_count
figshare_collections <- function(query, page_size = 10, page = 1) {
  schema <- tibble(id = integer(), title = character(), doi = character(),
                   url = character(), published_date = as.Date(character()),
                   articles_count = integer())
  body <- list(search_for = query, page_size = page_size, page = page)
  raw <- tryCatch(.post_json(paste0(.figshare_base, "/collections/search"), body),
                  error = function(e) NULL)
  if (is.null(raw) || length(raw) == 0) return(schema)
  if (!is.data.frame(raw)) return(schema)

  as_tibble(raw) |>
    transmute(
      id = as.integer(id),
      title = as.character(if ("title" %in% names(raw)) title else NA_character_),
      doi = as.character(if ("doi" %in% names(raw)) doi else NA_character_),
      url = as.character(if ("url" %in% names(raw)) url else NA_character_),
      published_date = tryCatch(as.Date(if ("published_date" %in% names(raw)) published_date else NA), error = function(e) as.Date(NA)),
      articles_count = as.integer(if ("articles_count" %in% names(raw)) articles_count else NA_integer_)
    )
}

# == Context ===================================================================

#' Generate LLM-friendly context for figshare.com
#'
#' @return Character string with full function signatures and bodies
figshare_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/figshare.com.R"
  if (!file.exists(src_file)) {
    cat("# figshare.com context - source not found\n")
    return(invisible("# figshare.com context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

