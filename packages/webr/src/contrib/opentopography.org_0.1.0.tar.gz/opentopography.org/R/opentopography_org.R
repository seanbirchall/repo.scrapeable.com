# opentopography.org.R - Self-contained opentopography.org client



# opentopography.R
# Self-contained OpenTopography API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required for catalog search
# Rate limits: not documented, be respectful


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.otopo_base <- "https://portal.opentopography.org/API"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE)

# == Schemas ===================================================================

.schema_catalog <- tibble(
  name = character(), short_name = character(),
  dataset_type = character(), platform = character(),
  minx = numeric(), miny = numeric(), maxx = numeric(), maxy = numeric(),
  url = character()
)

# == Catalog search ============================================================

#' Search OpenTopography dataset catalog by bounding box
#'
#' @param minx Minimum longitude (e.g. -118)
#' @param miny Minimum latitude (e.g. 33)
#' @param maxx Maximum longitude (e.g. -117)
#' @param maxy Maximum latitude (e.g. 34)
#' @param product_format Product format filter: "PointCloud" or "Raster"
#'   (default "PointCloud")
#' @param detail Include detailed metadata (default TRUE)
#' @return tibble: name, short_name, dataset_type, platform, minx, miny,
#'   maxx, maxy, url
otopo_catalog <- function(minx, miny, maxx, maxy,
                          product_format = "PointCloud", detail = TRUE) {
  url <- paste0(.otopo_base, "/otCatalog?productFormat=", product_format,
                "&minx=", minx, "&miny=", miny,
                "&maxx=", maxx, "&maxy=", maxy,
                "&detail=", tolower(as.character(detail)),
                "&outputFormat=json")
  raw <- .fetch_json(url)
  d <- raw$Datasets %||% raw$datasets %||% raw
  if (is.null(d) || length(d) == 0) return(.schema_catalog)

  # Each item has a $Dataset sub-element with the actual data
  rows <- lapply(d, function(item) {
    ds <- item$Dataset %||% item
    if (is.null(ds)) return(NULL)

    # Extract spatial coverage
    sc <- ds$spatialCoverage %||% list()
    geo <- sc$geo %||% list()

    tibble(
      name = as.character(ds$name %||% NA_character_),
      short_name = as.character(ds$alternateName %||% NA_character_),
      dataset_type = as.character(ds$fileFormat %||% NA_character_),
      platform = as.character(ds$keywords %||% NA_character_),
      minx = as.numeric(geo$longitude %||% NA_real_),
      miny = as.numeric(geo$latitude %||% NA_real_),
      maxx = as.numeric(geo$eastLon %||% NA_real_),
      maxy = as.numeric(geo$northLat %||% NA_real_),
      url = as.character(ds$url %||% NA_character_)
    )
  })
  rows <- rows[!vapply(rows, is.null, logical(1))]
  if (length(rows) == 0) return(.schema_catalog)
  bind_rows(rows)
}

#' List all global datasets available on OpenTopography
#'
#' Returns metadata for globally available datasets (no bounding box filter).
#'
#' @param product_format "PointCloud" or "Raster" (default "PointCloud")
#' @return tibble: name, short_name, dataset_type, platform, minx, miny,
#'   maxx, maxy, url
otopo_global_datasets <- function(product_format = "PointCloud") {
  otopo_catalog(minx = -180, miny = -90, maxx = 180, maxy = 90,
                product_format = product_format, detail = TRUE)
}

#' Search OpenTopography datasets by keyword in name
#'
#' Fetches the full catalog then filters locally by keyword.
#'
#' @param keyword Search term to match against dataset name (case-insensitive)
#' @param product_format "PointCloud" or "Raster" (default "PointCloud")
#' @return tibble: name, short_name, dataset_type, platform, minx, miny,
#'   maxx, maxy, url
otopo_search <- function(keyword, product_format = "PointCloud") {
  all_data <- otopo_global_datasets(product_format = product_format)
  if (nrow(all_data) == 0) return(.schema_catalog)
  all_data[grepl(keyword, all_data$name, ignore.case = TRUE), ]
}

# == Context ===================================================================

#' Generate LLM-friendly context for opentopography.org
#'
#' @return Character string with full function signatures and bodies
otopo_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/opentopography.org.R"
  if (!file.exists(src_file)) {
    cat("# opentopography.org context - source not found\n")
    return(invisible("# opentopography.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

