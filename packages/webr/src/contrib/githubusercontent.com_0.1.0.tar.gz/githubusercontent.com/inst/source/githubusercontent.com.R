# githubusercontent.com.R - Self-contained GitHub raw content client
# Fetches open government datasets hosted on raw.githubusercontent.com
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none
# Rate limits: standard GitHub rate limits

library(httr2)
library(jsonlite)
library(tibble)
library(dplyr)

# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.ghraw_base <- "https://raw.githubusercontent.com"

`%||%` <- function(a, b) if (is.null(a)) b else a

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_timeout(30) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = TRUE)

.fetch_csv <- function(url) {
  tmp <- .fetch(url, ext = ".csv")
  utils::read.csv(tmp, stringsAsFactors = FALSE) |> tibble::as_tibble()
}

.safe_col <- function(df, col, default = NA_character_) {
  if (col %in% names(df)) df[[col]] else rep(default, nrow(df))
}

# == Schemas ===================================================================

.schema_nasa_project <- tibble(
  name = character(), description = character(),
  organization = character(), repositoryURL = character(),
  homepageURL = character(), tags = character(),
  languages = character(), metadataLastUpdated = as.Date(character())
)

.schema_gsa_standard <- tibble(
  id = character(), name = character(), category = character(),
  status = character(), description = character(),
  deployment_type = character()
)

# == NASA Open Source Catalog ==================================================

#' List NASA open-source software projects from code.nasa.gov
#'
#' @param search Optional search term to filter by name/description (case-insensitive)
#' @param organization Optional NASA center code filter (e.g. "ARC", "JPL", "GSFC")
#' @return tibble: name, description, organization, repositoryURL, homepageURL,
#'   tags, languages, metadataLastUpdated
ghraw_nasa_projects <- function(search = NULL, organization = NULL) {
  url <- paste0(.ghraw_base, "/nasa/Open-Source-Catalog/master/code.json")
  res <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(res) || is.null(res$releases) || length(res$releases) == 0)
    return(.schema_nasa_project)

  d <- res$releases

  out <- tibble(
    name = as.character(.safe_col(d, "name")),
    description = as.character(.safe_col(d, "description")),
    organization = as.character(.safe_col(d, "organization")),
    repositoryURL = as.character(.safe_col(d, "repositoryURL")),
    homepageURL = as.character(.safe_col(d, "homepageURL")),
    tags = vapply(seq_len(nrow(d)), function(i) {
      t <- d$tags
      if (is.list(t)) paste(t[[i]], collapse = "; ") else NA_character_
    }, character(1)),
    languages = vapply(seq_len(nrow(d)), function(i) {
      l <- d$languages
      if (is.list(l)) paste(l[[i]], collapse = "; ") else NA_character_
    }, character(1)),
    metadataLastUpdated = as.Date(
      vapply(seq_len(nrow(d)), function(i) {
        dt <- d$date
        if (is.data.frame(dt)) dt$metadataLastUpdated[i] %||% NA_character_
        else NA_character_
      }, character(1))
    )
  )

  if (!is.null(search)) {
    pat <- tolower(search)
    out <- out |> filter(
      grepl(pat, tolower(name), fixed = TRUE) |
      grepl(pat, tolower(description), fixed = TRUE)
    )
  }
  if (!is.null(organization)) {
    out <- out |> filter(toupper(.data$organization) == toupper(organization))
  }
  out
}

# == GSA IT Standards ==========================================================

#' Get GSA IT Standards Profile list
#'
#' @return tibble: id, name, category, status, description, deployment_type
ghraw_gsa_standards <- function() {
  # Note: the catalog URL says .csv but it's actually JSON
  url <- paste0(.ghraw_base, "/GSA/data/gh-pages/enterprise-architecture/it-standards.csv")
  res <- tryCatch({
    tmp <- .fetch(url, ext = ".json")
    txt <- readLines(tmp, warn = FALSE)
    jsonlite::fromJSON(paste(txt, collapse = "\n"), simplifyVector = TRUE)
  }, error = function(e) {
    # Try as CSV fallback
    tryCatch(.fetch_csv(url), error = function(e2) NULL)
  })
  if (is.null(res) || length(res) == 0) return(.schema_gsa_standard)

  if (is.data.frame(res)) {
    tibble(
      id = as.character(.safe_col(res, "ID", .safe_col(res, "id"))),
      name = as.character(.safe_col(res, "Name", .safe_col(res, "name"))),
      category = as.character(.safe_col(res, "Category", .safe_col(res, "category"))),
      status = as.character(.safe_col(res, "Status", .safe_col(res, "status"))),
      description = as.character(.safe_col(res, "Description", .safe_col(res, "description"))),
      deployment_type = as.character(.safe_col(res, "DeploymentType",
        .safe_col(res, "deployment_type")))
    )
  } else .schema_gsa_standard
}

# == Philadelphia Contracts ====================================================

#' Get Philadelphia professional services contract data
#'
#' @param fiscal_year Fiscal year (e.g. 2020)
#' @param quarter Quarter (1-4)
#' @return tibble of contract data (columns vary by quarter)
ghraw_philly_contracts <- function(fiscal_year = 2020, quarter = 4) {
  url <- sprintf(
    "%s/CityOfPhiladelphia/contracts/gh-pages/professional-services/data/FY-%d-Q%d.csv",
    .ghraw_base, fiscal_year, quarter
  )
  tryCatch(.fetch_csv(url), error = function(e) tibble())
}

# == Context ===================================================================

#' Return the full source of this client for LLM context
#'
#' @return character string of the source file
ghraw_context <- function() {
  f <- system.file("source", "githubusercontent.com.R", package = "githubusercontent.com", mustWork = FALSE)
  if (f == "") {
    sf <- sys.frame(1)$ofile %||% ""
    if (nzchar(sf)) f <- sf
  }
  if (nzchar(f)) paste(readLines(f, warn = FALSE), collapse = "\n") else
    "Source not found. Load from inst/source/githubusercontent.com.R"
}
