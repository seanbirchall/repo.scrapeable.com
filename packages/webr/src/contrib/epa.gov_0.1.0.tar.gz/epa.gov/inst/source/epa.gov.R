# epa.gov.R
# Self-contained EPA Envirofacts API client.
# Covers: TRI, FRS, NPDES/PCS, GHGRP, and SDWIS (Safe Drinking Water).
# All public functions return tibbles with typed columns.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required (public API)
# Docs: https://www.epa.gov/enviro/envirofacts-data-service-api

library(httr2)
library(jsonlite)
library(dplyr, warn.conflicts = FALSE)
library(tibble)


# == Private utilities =========================================================

`%||%` <- function(x, y) if (is.null(x)) y else x
.ua <- "support@scrapeable.com"
.epa_base <- "https://data.epa.gov/efservice"

.epa_query <- function(table, filters = list(), max_rows = 1000) {
  filter_path <- ""
  for (f in filters) {
    if (!is.null(f$value))
      filter_path <- paste0(filter_path, "/", f$column, "/", f$op %||% "=", "/",
                            utils::URLencode(as.character(f$value)))
  }

  url <- paste0(.epa_base, "/", table, filter_path, "/rows/0:", max_rows - 1, "/JSON")

  tmp <- tempfile(fileext = ".json")
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)

  raw <- jsonlite::fromJSON(tmp)
  if (is.null(raw) || length(raw) == 0) return(tibble())
  df <- as_tibble(raw)
  names(df) <- tolower(names(df))

  for (col in names(df)) {
    vals <- df[[col]]
    if (!is.character(vals)) next
    if (grepl("date", col)) {
      parsed <- suppressWarnings(as.Date(vals))
      if (sum(!is.na(parsed)) > sum(!is.na(vals)) * 0.5) { df[[col]] <- parsed; next }
    }
    if (grepl("latitude|longitude|amt|qty|quantity|amount|rate|num|count|year", col)) {
      parsed <- suppressWarnings(as.numeric(vals))
      if (sum(!is.na(parsed)) >= sum(vals != "" & !is.na(vals)) * 0.8) df[[col]] <- parsed
    }
  }
  df
}

.epa_fetch_all <- function(table, filters = list(), max_rows = 10000,
                           chunk_size = 1000) {
  all_data <- list()
  offset <- 0

  repeat {
    end <- offset + chunk_size - 1
    filter_path <- ""
    for (f in filters) {
      if (!is.null(f$value))
        filter_path <- paste0(filter_path, "/", f$column, "/", f$op %||% "=", "/",
                              utils::URLencode(as.character(f$value)))
    }

    url <- paste0(.epa_base, "/", table, filter_path,
                  "/rows/", offset, ":", end, "/JSON")

    raw <- tryCatch({
      tmp <- tempfile(fileext = ".json")
      httr2::request(url) |>
        httr2::req_headers(`User-Agent` = .ua) |>
        httr2::req_perform(path = tmp)
      jsonlite::fromJSON(tmp)
    }, error = function(e) NULL)

    if (is.null(raw) || length(raw) == 0) break

    df <- as_tibble(raw)
    names(df) <- tolower(names(df))
    all_data[[length(all_data) + 1]] <- df

    n_so_far <- sum(vapply(all_data, nrow, integer(1)))
    if (nrow(df) < chunk_size || n_so_far >= max_rows) break
    offset <- offset + chunk_size

    if (length(all_data) %% 5 == 0)
      message(sprintf("  ...fetched %d rows", n_so_far))
  }

  if (length(all_data) == 0) return(tibble())
  result <- bind_rows(all_data)
  if (nrow(result) > max_rows) result <- head(result, max_rows)
  result
}

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = TRUE)


# == Schemas ===================================================================

.schema_sdwis_systems <- tibble(
  pwsid = character(), pws_name = character(), state_code = character(),
  pws_type_code = character(), primary_source_code = character(),
  population_served = integer(), service_connections = integer(),
  owner_type_code = character(), pws_activity_code = character()
)

.schema_sdwis_violations <- tibble(
  pwsid = character(), violation_id = character(), pws_name = character(),
  contaminant_code = character(), violation_type_code = character(),
  compliance_period_begin_date = character(),
  compliance_period_end_date = character(),
  state_code = character()
)


# == Core: generic table query =================================================

#' Query any EPA Envirofacts table
#'
#' The universal engine. Builds the URL path from table name and filters.
#'
#' @param table Envirofacts table name (e.g. "TRI_FACILITY", "FRS_FACILITY_SITE")
#' @param ... Named filter arguments. Each should be a value to match.
#'   Name = column name (case-insensitive, will be uppercased).
#'   e.g. state_abbr = "CA", reporting_year = "2022"
#' @param max_rows Maximum rows to return (default 1000)
#' @return tibble with auto-typed columns (lowercase names)
epa_get <- function(table, ..., max_rows = 1000) {
  args <- list(...)
  filters <- lapply(names(args), function(nm) {
    list(column = toupper(nm), op = "=", value = args[[nm]])
  })
  if (max_rows > 1000) {
    .epa_fetch_all(table, filters, max_rows)
  } else {
    .epa_query(table, filters, max_rows)
  }
}


# == TRI (Toxic Release Inventory) =============================================

#' TRI facility information
#'
#' Facilities reporting to the Toxic Release Inventory.
#'
#' @param state 2-letter state abbreviation (e.g. "CA", "TX")
#' @param city City name filter
#' @param zip ZIP code filter
#' @param max_rows Max rows (default 1000)
#' @return tibble: tri_facility_id, facility_name, street_address, city_name,
#'   county_name, state_abbr, zip_code, latitude, longitude, ...
epa_tri_facility <- function(state = NULL, city = NULL, zip = NULL,
                             max_rows = 1000) {
  filters <- list()
  if (!is.null(state)) filters <- c(filters, list(list(column = "STATE_ABBR", value = state)))
  if (!is.null(city))  filters <- c(filters, list(list(column = "CITY_NAME", value = city)))
  if (!is.null(zip))   filters <- c(filters, list(list(column = "ZIP_CODE", value = zip)))
  .epa_query("TRI_FACILITY", filters, max_rows)
}

#' TRI chemical release quantities
#'
#' Chemical release data from TRI-reporting facilities.
#'
#' @param state 2-letter state abbreviation
#' @param year Reporting year (e.g. "2022")
#' @param chemical Chemical name filter
#' @param max_rows Max rows (default 5000)
#' @return tibble: tri_facility_id, chemical_name, unit_of_measure,
#'   total_releases, on_site_release_total, off_site_release_total, ...
epa_tri_release <- function(state = NULL, year = NULL, chemical = NULL,
                            max_rows = 5000) {
  filters <- list()
  if (!is.null(state))    filters <- c(filters, list(list(column = "STATE_ABBR", value = state)))
  if (!is.null(year))     filters <- c(filters, list(list(column = "REPORTING_YEAR", value = year)))
  if (!is.null(chemical)) filters <- c(filters, list(list(column = "CHEMICAL_NAME", value = chemical)))
  .epa_fetch_all("TRI_RELEASE_QTY", filters, max_rows)
}


# == FRS (Facility Registry Service) ===========================================

#' EPA facility registry
#'
#' Master list of EPA-regulated facilities across all programs.
#'
#' @param state 2-letter state code
#' @param city City name filter
#' @param zip ZIP code filter
#' @param max_rows Max rows (default 1000)
#' @return tibble: registry_id, primary_name, city_name, state_code,
#'   postal_code, latitude, longitude, ...
epa_facility <- function(state = NULL, city = NULL, zip = NULL,
                         max_rows = 1000) {
  filters <- list()
  if (!is.null(state)) filters <- c(filters, list(list(column = "STATE_CODE", value = state)))
  if (!is.null(city))  filters <- c(filters, list(list(column = "CITY_NAME", value = city)))
  if (!is.null(zip))   filters <- c(filters, list(list(column = "POSTAL_CODE", value = zip)))
  .epa_query("FRS_FACILITY_SITE", filters, max_rows)
}


# == Water (PCS/NPDES) =========================================================

#' Water discharge permits (PCS/NPDES)
#'
#' Facilities with water discharge permits under the Clean Water Act.
#'
#' @param state 2-letter state code
#' @param city City name filter
#' @param max_rows Max rows (default 1000)
#' @return tibble with permit and facility information
epa_water_permit <- function(state = NULL, city = NULL, max_rows = 1000) {
  filters <- list()
  if (!is.null(state)) filters <- c(filters, list(list(column = "STATE_CODE", value = state)))
  if (!is.null(city))  filters <- c(filters, list(list(column = "CITY", value = city)))
  .epa_query("PCS_PERMIT_FACILITY", filters, max_rows)
}


# == GHG (Greenhouse Gas) =====================================================

#' Greenhouse gas reporting facilities (GHGRP)
#'
#' Facilities reporting greenhouse gas emissions under EPA's GHGRP.
#'
#' @param state 2-letter state abbreviation
#' @param max_rows Max rows (default 1000)
#' @return tibble: facility_id, latitude, longitude, city, state, zip,
#'   county_fips, county, ...
epa_ghg_facility <- function(state = NULL, max_rows = 1000) {
  filters <- list()
  if (!is.null(state)) filters <- c(filters, list(list(column = "STATE", value = state)))
  .epa_query("PUB_DIM_FACILITY", filters, max_rows)
}


# == SDWIS (Safe Drinking Water Information System) ============================

#' Fetch SDWIS public water systems by state
#'
#' @param state Two-letter state code (e.g. "CA", "NY")
#' @param rows Row range "start:end" (default "0:99")
#' @return tibble: pwsid, pws_name, state_code, pws_type_code,
#'   primary_source_code, population_served, service_connections,
#'   owner_type_code, pws_activity_code
sdwis_systems <- function(state, rows = "0:99") {
  url <- sprintf("%s/WATER_SYSTEM/STATE_CODE/%s/ROWS/%s/JSON",
                 .epa_base, toupper(state), rows)
  raw <- .fetch_json(url)
  if (is.null(raw) || length(raw) == 0 || !is.data.frame(raw)) return(.schema_sdwis_systems)

  as_tibble(raw) |>
    transmute(
      pwsid               = as.character(pwsid),
      pws_name            = as.character(pws_name),
      state_code          = as.character(if ("primacy_agency_code" %in% names(raw)) primacy_agency_code else state_code),
      pws_type_code       = as.character(pws_type_code),
      primary_source_code = as.character(if ("primary_source_code" %in% names(raw)) primary_source_code else NA),
      population_served   = as.integer(if ("population_served_count" %in% names(raw)) population_served_count else NA),
      service_connections = as.integer(if ("service_connections_count" %in% names(raw)) service_connections_count else NA),
      owner_type_code     = as.character(if ("owner_type_code" %in% names(raw)) owner_type_code else NA),
      pws_activity_code   = as.character(if ("pws_activity_code" %in% names(raw)) pws_activity_code else NA)
    )
}

#' Fetch SDWIS drinking water violations by state
#'
#' @param state Two-letter state code (e.g. "CA", "NY")
#' @param rows Row range "start:end" (default "0:99")
#' @return tibble: pwsid, violation_id, pws_name, contaminant_code,
#'   violation_type_code, compliance_period_begin_date,
#'   compliance_period_end_date, state_code
sdwis_violations <- function(state, rows = "0:99") {
  url <- sprintf("%s/VIOLATION/PRIMACY_AGENCY_CODE/%s/ROWS/%s/JSON",
                 .epa_base, toupper(state), rows)
  raw <- .fetch_json(url)
  if (is.null(raw) || length(raw) == 0 || !is.data.frame(raw)) return(.schema_sdwis_violations)

  as_tibble(raw) |>
    transmute(
      pwsid                        = as.character(if ("pwsid" %in% names(raw)) pwsid else NA),
      violation_id                 = as.character(if ("violation_id" %in% names(raw)) violation_id else NA),
      pws_name                     = as.character(if ("pws_name" %in% names(raw)) pws_name else NA),
      contaminant_code             = as.character(if ("contaminant_code" %in% names(raw)) contaminant_code else NA),
      violation_type_code          = as.character(if ("violation_type_code" %in% names(raw)) violation_type_code else NA),
      compliance_period_begin_date = as.character(if ("compliance_period_begin_date" %in% names(raw)) compliance_period_begin_date else NA),
      compliance_period_end_date   = as.character(if ("compliance_period_end_date" %in% names(raw)) compliance_period_end_date else NA),
      state_code                   = as.character(if ("primacy_agency_code" %in% names(raw)) primacy_agency_code else NA)
    )
}


# == Context ===================================================================

#' Generate LLM-friendly context for epa.gov
#'
#' @return Character string with full function signatures and bodies
epa_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/epa.gov.R"
  if (!file.exists(src_file)) {
    cat("# epa.gov context - source not found\n")
    return(invisible("# epa.gov context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}
