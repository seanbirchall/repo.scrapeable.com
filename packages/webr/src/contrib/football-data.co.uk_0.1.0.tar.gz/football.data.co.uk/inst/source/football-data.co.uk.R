# football-data.co.uk.R - Self-contained football-data.co.uk client

library(httr2)
library(jsonlite)
library(tibble)
library(dplyr)



.ua <- "support@scrapeable.com"

.fetch_json <- function(url) {
  tmp <- tempfile(fileext = ".json")
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  jsonlite::fromJSON(tmp, simplifyVector = FALSE)
}


#' Get football match results
#' @param league League code (e.g. 'E0' for English Premier League, 'D1' for German Bundesliga)
#' @param season Season code (e.g. '2324' for 2023-2024)
#' @return tibble of match results
fbdata_results <- function(league = "E0", season = "2324") {
  url <- sprintf("https://www.football-data.co.uk/mmz4281/%s/%s.csv", season, league)
  tmp <- tempfile(fileext = ".csv")
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  df <- tryCatch(utils::read.csv(tmp, stringsAsFactors = FALSE), error = function(e) data.frame())
  if (nrow(df) == 0) return(tibble::tibble(date = character(), home = character(), away = character()))
  cols <- intersect(c("Div", "Date", "HomeTeam", "AwayTeam", "FTHG", "FTAG", "FTR"), names(df))
  tibble::as_tibble(df[, cols, drop = FALSE])
}

#' Compute league standings from match results
#'
#' @param league League code (e.g. "E0" for English Premier League)
#' @param season Season code (e.g. "2324" for 2023-2024)
#' @return tibble: team, played, won, drawn, lost, goals_for, goals_against,
#'   goal_diff, points — sorted by points descending
fbdata_standings <- function(league = "E0", season = "2324") {
  results <- fbdata_results(league = league, season = season)
  if (nrow(results) == 0 || !all(c("HomeTeam", "AwayTeam", "FTHG", "FTAG") %in% names(results))) {
    return(tibble(team = character(), played = integer(), won = integer(),
                  drawn = integer(), lost = integer(), goals_for = integer(),
                  goals_against = integer(), goal_diff = integer(), points = integer()))
  }

  results <- results |> mutate(FTHG = as.integer(FTHG), FTAG = as.integer(FTAG))

  home <- results |>
    group_by(team = HomeTeam) |>
    summarise(p = n(), w = sum(FTHG > FTAG), d = sum(FTHG == FTAG),
              l = sum(FTHG < FTAG), gf = sum(FTHG), ga = sum(FTAG), .groups = "drop")
  away <- results |>
    group_by(team = AwayTeam) |>
    summarise(p = n(), w = sum(FTAG > FTHG), d = sum(FTAG == FTHG),
              l = sum(FTAG < FTHG), gf = sum(FTAG), ga = sum(FTHG), .groups = "drop")

  bind_rows(home, away) |>
    group_by(team) |>
    summarise(played = sum(p), won = sum(w), drawn = sum(d), lost = sum(l),
              goals_for = sum(gf), goals_against = sum(ga), .groups = "drop") |>
    mutate(goal_diff = goals_for - goals_against,
           points = won * 3L + drawn) |>
    arrange(desc(points), desc(goal_diff))
}

#' Get results for a specific team
#'
#' @param team Team name (e.g. "Arsenal", "Man City")
#' @param league League code (default "E0")
#' @param season Season code (default "2324")
#' @return tibble of match results involving that team
fbdata_team <- function(team, league = "E0", season = "2324") {
  results <- fbdata_results(league = league, season = season)
  if (nrow(results) == 0) return(results)
  results[grepl(team, results$HomeTeam, ignore.case = TRUE) |
          grepl(team, results$AwayTeam, ignore.case = TRUE), ]
}

#' List available leagues and their codes
#'
#' @return tibble: code, league, country
fbdata_leagues <- function() {
  tibble(
    code = c("E0", "E1", "E2", "E3", "EC",
             "SC0", "SC1", "SC2", "SC3",
             "D1", "D2", "I1", "I2",
             "SP1", "SP2", "F1", "F2",
             "N1", "B1", "P1", "T1", "G1"),
    league = c("Premier League", "Championship", "League One", "League Two", "Conference",
               "Scottish Premiership", "Scottish Championship", "Scottish League One", "Scottish League Two",
               "Bundesliga", "2. Bundesliga", "Serie A", "Serie B",
               "La Liga", "Segunda Division", "Ligue 1", "Ligue 2",
               "Eredivisie", "Jupiler League", "Liga Portugal", "Super Lig", "Super League Greece"),
    country = c(rep("England", 5), rep("Scotland", 4), rep("Germany", 2),
                rep("Italy", 2), rep("Spain", 2), rep("France", 2),
                "Netherlands", "Belgium", "Portugal", "Turkey", "Greece")
  )
}

# == Context ===================================================================

#' Generate LLM-friendly context for football-data.co.uk
#'
#' @return Character string with full function signatures and bodies
fbdata_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/football-data.co.uk.R"
  if (!file.exists(src_file)) {
    cat("# football-data.co.uk context - source not found\n")
    return(invisible("# football-data.co.uk context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

