# usgs.gov.R
# Self-contained USGS client.
# Covers: earthquake data and water data (NWIS).
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required

library(httr2)
library(jsonlite)
library(dplyr, warn.conflicts = FALSE)
library(tibble)


# == Private utilities =========================================================

`%||%` <- function(a, b) if (is.null(a)) b else a
.ua <- "support@scrapeable.com"
.usgs_base <- "https://earthquake.usgs.gov/fdsnws/event/1"
.water_base <- "https://waterservices.usgs.gov/nwis"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))
.fetch_json_nested <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE)


# == Schemas ===================================================================

.schema_quakes <- tibble(
  id = character(), time = as.POSIXct(character()), mag = numeric(),
  place = character(), longitude = numeric(), latitude = numeric(),
  depth = numeric(), type = character(), status = character(),
  url = character()
)

.schema_realtime <- tibble(
  site = character(), parameter = character(), datetime = as.POSIXct(character()),
  value = numeric(), qualifier = character(), site_name = character()
)

.schema_daily <- tibble(
  site = character(), parameter = character(), date = as.Date(character()),
  value = numeric(), qualifier = character(), site_name = character()
)

.schema_sites <- tibble(
  site_no = character(), site_name = character(), site_type = character(),
  lat = numeric(), lon = numeric(), state_cd = character(),
  county_cd = character(), huc_cd = character()
)



#' Query USGS earthquake data
#'
#' Returns earthquake events from the USGS FDSN web service.
#'
#' @param starttime Start date (Date or "YYYY-MM-DD")
#' @param endtime End date (Date or "YYYY-MM-DD"). Default: today.
#' @param minmagnitude Minimum magnitude (default 2.5)
#' @param maxmagnitude Maximum magnitude
#' @param limit Max results (default 100, max 20000)
#' @param latitude Center latitude for radius search
#' @param longitude Center longitude for radius search
#' @param maxradiuskm Max radius in km (requires lat/lon)
#' @param orderby Sort: "time" (default), "time-asc", "magnitude", "magnitude-asc"
#' @return tibble: id, time (POSIXct), mag, place, longitude, latitude,
#'   depth, type, status, url
usgs_quakes <- function(starttime = NULL, endtime = NULL,
                        minmagnitude = 2.5, maxmagnitude = NULL,
                        limit = 100, latitude = NULL, longitude = NULL,
                        maxradiuskm = NULL, orderby = "time") {
  params <- list(format = "geojson", limit = limit,
                 minmagnitude = minmagnitude, orderby = orderby)
  if (!is.null(starttime)) params$starttime <- as.character(starttime)
  if (!is.null(endtime))   params$endtime <- as.character(endtime)
  if (!is.null(maxmagnitude)) params$maxmagnitude <- maxmagnitude
  if (!is.null(latitude))   params$latitude <- latitude
  if (!is.null(longitude))  params$longitude <- longitude
  if (!is.null(maxradiuskm)) params$maxradiuskm <- maxradiuskm

  params <- params[!vapply(params, is.null, logical(1))]
  query <- paste(names(params), params, sep = "=", collapse = "&")
  url <- paste0(.usgs_base, "/query?", query)

  raw <- tryCatch(.fetch_json(url), error = function(e) {
    warning("USGS API error: ", e$message); NULL
  })
  if (is.null(raw)) return(.schema_quakes)

  features <- raw$features
  if (is.null(features) || length(features) == 0) return(.schema_quakes)

  tibble(
    id        = vapply(features, function(f) f$id %||% NA_character_, character(1)),
    time      = as.POSIXct(vapply(features, function(f) {
      (f$properties$time %||% NA_real_) / 1000
    }, numeric(1)), origin = "1970-01-01", tz = "UTC"),
    mag       = vapply(features, function(f) as.numeric(f$properties$mag %||% NA_real_), numeric(1)),
    place     = vapply(features, function(f) f$properties$place %||% NA_character_, character(1)),
    longitude = vapply(features, function(f) as.numeric(f$geometry$coordinates[[1]] %||% NA_real_), numeric(1)),
    latitude  = vapply(features, function(f) as.numeric(f$geometry$coordinates[[2]] %||% NA_real_), numeric(1)),
    depth     = vapply(features, function(f) as.numeric(f$geometry$coordinates[[3]] %||% NA_real_), numeric(1)),
    type      = vapply(features, function(f) f$properties$type %||% NA_character_, character(1)),
    status    = vapply(features, function(f) f$properties$status %||% NA_character_, character(1)),
    url       = vapply(features, function(f) f$properties$url %||% NA_character_, character(1))
  )
}



#' Get significant earthquakes in the last 30 days
#'
#' @return tibble: same columns as usgs_quakes
usgs_significant <- function() {
  url <- "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/significant_month.geojson"
  raw <- tryCatch(.fetch_json(url), error = function(e) {
    warning("USGS API error: ", e$message); NULL
  })
  if (is.null(raw)) return(.schema_quakes)

  features <- raw$features
  if (is.null(features) || length(features) == 0) return(.schema_quakes)

  tibble(
    id        = vapply(features, function(f) f$id %||% NA_character_, character(1)),
    time      = as.POSIXct(vapply(features, function(f) (f$properties$time %||% NA_real_) / 1000, numeric(1)),
                           origin = "1970-01-01", tz = "UTC"),
    mag       = vapply(features, function(f) as.numeric(f$properties$mag %||% NA_real_), numeric(1)),
    place     = vapply(features, function(f) f$properties$place %||% NA_character_, character(1)),
    longitude = vapply(features, function(f) as.numeric(f$geometry$coordinates[[1]] %||% NA_real_), numeric(1)),
    latitude  = vapply(features, function(f) as.numeric(f$geometry$coordinates[[2]] %||% NA_real_), numeric(1)),
    depth     = vapply(features, function(f) as.numeric(f$geometry$coordinates[[3]] %||% NA_real_), numeric(1)),
    type      = vapply(features, function(f) f$properties$type %||% NA_character_, character(1)),
    status    = vapply(features, function(f) f$properties$status %||% NA_character_, character(1)),
    url       = vapply(features, function(f) f$properties$url %||% NA_character_, character(1))
  )
}



#' Fetch real-time (instantaneous) water data from USGS
#'
#' @param sites Character vector of USGS site numbers (e.g., "01646500")
#' @param params Parameter codes: "00060" = discharge, "00065" = gage height,
#'   "00010" = water temp. Default "00060".
#' @param period ISO 8601 duration (e.g., "P1D" = past 1 day, "P7D" = past week).
#'   Default "P1D".
#' @return tibble: site, parameter, datetime, value, qualifier, site_name
water_realtime <- function(sites, params = "00060", period = "P1D") {
  sites_str <- paste(sites, collapse = ",")
  params_str <- paste(params, collapse = ",")
  url <- sprintf("%s/iv/?format=json&sites=%s&parameterCd=%s&period=%s",
                 .water_base, sites_str, params_str, period)
  raw <- .fetch_json_nested(url)
  .parse_iv_response(raw)
}


#' Fetch daily values from USGS water data
#'
#' @param sites Character vector of USGS site numbers
#' @param params Parameter codes. Default "00060" (discharge).
#' @param start Start date as "YYYY-MM-DD"
#' @param end End date as "YYYY-MM-DD"
#' @return tibble: site, parameter, date, value, qualifier, site_name
water_daily <- function(sites, params = "00060", start = NULL, end = NULL) {
  sites_str <- paste(sites, collapse = ",")
  params_str <- paste(params, collapse = ",")
  url <- sprintf("%s/dv/?format=json&sites=%s&parameterCd=%s",
                 .water_base, sites_str, params_str)
  if (!is.null(start)) url <- paste0(url, "&startDT=", start)
  if (!is.null(end)) url <- paste0(url, "&endDT=", end)
  raw <- .fetch_json_nested(url)
  .parse_dv_response(raw)
}


#' Search for USGS water monitoring sites by state
#'
#' @param state Two-letter state code (e.g., "MD", "CA")
#' @param site_type Site type code. Default "ST" (stream). Use "GW" for
#'   groundwater, "LK" for lake, "SP" for spring.
#' @param param_code Optional parameter code to filter sites that measure
#'   a specific parameter (e.g., "00060" for discharge)
#' @return tibble: site_no, site_name, site_type, lat, lon, state_cd,
#'   county_cd, huc_cd
water_sites <- function(state, site_type = "ST", param_code = NULL) {
  url <- sprintf("%s/site/?format=rdb&stateCD=%s&siteType=%s&siteStatus=active",
                 .water_base, state, site_type)
  if (!is.null(param_code)) url <- paste0(url, "&parameterCd=", param_code)

  tmp <- .fetch(url, ext = ".tsv")
  raw_lines <- readLines(tmp, warn = FALSE)

  # Skip comment lines (start with #)
  data_lines <- raw_lines[!grepl("^#", raw_lines)]
  if (length(data_lines) < 3) return(.schema_sites)

  # First line is header, second is format spec, rest is data
  header <- strsplit(data_lines[1], "\t")[[1]]
  data_lines <- data_lines[3:length(data_lines)]

  con <- textConnection(paste(c(data_lines), collapse = "\n"))
  df <- tryCatch(
    read.delim(con, header = FALSE, stringsAsFactors = FALSE,
               col.names = header, sep = "\t"),
    error = function(e) NULL
  )
  close(con)

  if (is.null(df) || nrow(df) == 0) return(.schema_sites)

  nms <- names(df)
  as_tibble(df) |>
    transmute(
      site_no = as.character(site_no),
      site_name = as.character(station_nm),
      site_type = as.character(site_tp_cd),
      lat = suppressWarnings(as.numeric(dec_lat_va)),
      lon = suppressWarnings(as.numeric(dec_long_va)),
      state_cd = as.character(if ("state_cd" %in% nms) .data[["state_cd"]] else NA_character_),
      county_cd = as.character(if ("county_cd" %in% nms) .data[["county_cd"]] else NA_character_),
      huc_cd = as.character(if ("huc_cd" %in% nms) .data[["huc_cd"]] else NA_character_)
    )
}


#' Get site info for a specific USGS monitoring site
#'
#' @param site USGS site number (e.g., "01646500")
#' @return tibble: site_no, site_name, site_type, lat, lon, state_cd,
#'   county_cd, huc_cd, altitude, drain_area_sq_mi
water_site_info <- function(site) {
  url <- sprintf("%s/site/?format=rdb&sites=%s&siteOutput=expanded",
                 .water_base, site)
  tmp <- .fetch(url, ext = ".tsv")
  raw_lines <- readLines(tmp, warn = FALSE)
  data_lines <- raw_lines[!grepl("^#", raw_lines)]
  if (length(data_lines) < 3) return(.schema_sites)

  header <- strsplit(data_lines[1], "\t")[[1]]
  data_lines <- data_lines[3:length(data_lines)]
  con <- textConnection(paste(data_lines, collapse = "\n"))
  df <- tryCatch(
    read.delim(con, header = FALSE, stringsAsFactors = FALSE,
               col.names = header, sep = "\t"),
    error = function(e) NULL
  )
  close(con)
  if (is.null(df) || nrow(df) == 0) return(.schema_sites)

  nms <- names(df)
  as_tibble(df) |>
    transmute(
      site_no = as.character(site_no),
      site_name = as.character(station_nm),
      site_type = as.character(site_tp_cd),
      lat = suppressWarnings(as.numeric(dec_lat_va)),
      lon = suppressWarnings(as.numeric(dec_long_va)),
      state_cd = as.character(if ("state_cd" %in% nms) .data[["state_cd"]] else NA_character_),
      county_cd = as.character(if ("county_cd" %in% nms) .data[["county_cd"]] else NA_character_),
      huc_cd = as.character(if ("huc_cd" %in% nms) .data[["huc_cd"]] else NA_character_),
      altitude = suppressWarnings(as.numeric(if ("alt_va" %in% nms) .data[["alt_va"]] else NA_real_)),
      drain_area_sq_mi = suppressWarnings(as.numeric(if ("drain_area_va" %in% nms) .data[["drain_area_va"]] else NA_real_))
    )
}


#' Get statistical summaries for a USGS site
#'
#' Returns daily statistical summaries (mean, median, percentiles) based on
#' the historical record for a site.
#'
#' @param site USGS site number (e.g., "01646500")
#' @param params Parameter codes. Default "00060" (discharge).
#' @param stat_type Statistic type: "daily" (default), "monthly", "annual"
#' @return tibble: site, parameter, month_day, mean, median, count_years
water_stats <- function(site, params = "00060", stat_type = "daily") {
  stat_cd <- switch(stat_type,
    daily = "daily",
    monthly = "monthly",
    annual = "annual",
    "daily"
  )
  url <- sprintf("%s/stat/?format=rdb&sites=%s&parameterCd=%s&statReportType=%s&statTypeCd=all",
                 .water_base, site, paste(params, collapse = ","), stat_cd)

  tmp <- .fetch(url, ext = ".tsv")
  raw_lines <- readLines(tmp, warn = FALSE)
  data_lines <- raw_lines[!grepl("^#", raw_lines)]
  if (length(data_lines) < 3) return(tibble(site = character(), parameter = character(),
                                             month_day = character(), mean = numeric(),
                                             count_years = integer()))

  header <- strsplit(data_lines[1], "\t")[[1]]
  data_lines <- data_lines[3:length(data_lines)]
  con <- textConnection(paste(data_lines, collapse = "\n"))
  df <- tryCatch(
    read.delim(con, header = FALSE, stringsAsFactors = FALSE,
               col.names = header, sep = "\t"),
    error = function(e) NULL
  )
  close(con)
  if (is.null(df) || nrow(df) == 0) return(tibble(site = character(), parameter = character(),
                                                    month_day = character(), mean = numeric(),
                                                    count_years = integer()))

  nms <- names(df)
  result <- as_tibble(df)
  out <- tibble(
    site = as.character(result[[if ("site_no" %in% nms) "site_no" else nms[1]]]),
    parameter = as.character(result[[if ("parameter_cd" %in% nms) "parameter_cd" else nms[2]]])
  )
  if ("month_nu" %in% nms && "day_nu" %in% nms) {
    out$month_day <- sprintf("%02d-%02d",
      suppressWarnings(as.integer(result$month_nu)),
      suppressWarnings(as.integer(result$day_nu)))
  } else if ("month_nu" %in% nms) {
    out$month_day <- sprintf("%02d", suppressWarnings(as.integer(result$month_nu)))
  } else {
    out$month_day <- NA_character_
  }
  out$mean <- suppressWarnings(as.numeric(if ("mean_va" %in% nms) result$mean_va else NA_real_))
  out$count_years <- suppressWarnings(as.integer(if ("count_nu" %in% nms) result$count_nu else NA_integer_))
  out
}


# == Context ===================================================================

#' Generate LLM-friendly context for usgs.gov
#'
#' @return Character string with full function signatures and bodies
usgs_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/usgs.gov.R"
  if (!file.exists(src_file)) {
    cat("# usgs.gov context - source not found\n")
    return(invisible("# usgs.gov context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

