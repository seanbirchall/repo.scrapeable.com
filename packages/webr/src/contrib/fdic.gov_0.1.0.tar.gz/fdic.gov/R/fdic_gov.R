# fdic.gov.R
# Self-contained FDIC client.
# Covers: institution search, financial data, and bank failure list.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required



# == Private utilities =========================================================

`%||%` <- function(a, b) if (is.null(a)) b else a
.ua <- "support@scrapeable.com"
.fdic_base <- "https://banks.data.fdic.gov/api"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))
.fetch_json_nested <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE)


# == Schemas ===================================================================

.schema_institutions <- tibble(
  cert = integer(), name = character(), city = character(),
  state = character(), total_assets = numeric()
)

.schema_institutions <- tibble(
  cert = integer(), name = character(), city = character(),
  state = character(), zip = character(), active = integer(),
  class = character(), total_assets = numeric()
)

.schema_financials <- tibble(
  cert = integer(), repdte = character(), asset = numeric(),
  dep = numeric(), netinc = numeric(), roa = numeric(),
  roe = numeric(), equity = numeric()
)

.schema_search <- tibble(
  cert = integer(), name = character(), city = character(),
  state = character(), active = integer()
)

.schema_institutions <- tibble(
  cert = integer(), name = character(), city = character(),
  state = character(), zip = character(), active = integer(),
  class = character(), total_assets = numeric()
)

.schema_financials <- tibble(
  cert = integer(), repdte = character(), asset = numeric(),
  dep = numeric(), netinc = numeric(), roa = numeric(),
  roe = numeric(), equity = numeric()
)

.schema_search <- tibble(
  cert = integer(), name = character(), city = character(),
  state = character(), active = integer()
)

.schema_institutions <- tibble(
  cert = integer(), name = character(), city = character(),
  state = character(), zip = character(), active = integer(),
  class = character(), total_assets = numeric()
)

.schema_financials <- tibble(
  cert = integer(), repdte = character(), asset = numeric(),
  dep = numeric(), netinc = numeric(), roa = numeric(),
  roe = numeric(), equity = numeric()
)

.schema_search <- tibble(
  cert = integer(), name = character(), city = character(),
  state = character(), active = integer()
)







#' Search FDIC institutions (banks)
#'
#' @param name Bank name search term (optional)
#' @param state State name (e.g. "Ohio", "California") (optional)
#' @param limit Max results (default 25)
#' @return tibble: cert, name, city, state, total_assets
fdic_institutions <- function(name = NULL, state = NULL, limit = 25L) {
  url <- sprintf("%s/institutions?limit=%d&fields=CERT,NAME,CITY,STNAME,ASSET&sort_by=ASSET&sort_order=DESC",
                 .fdic_base, limit)
  filters <- c()
  if (!is.null(name)) filters <- c(filters, sprintf("NAME:*%s*", utils::URLencode(name, reserved = TRUE)))
  if (!is.null(state)) filters <- c(filters, sprintf("STNAME:%%22%s%%22", utils::URLencode(state, reserved = TRUE)))
  if (length(filters) > 0) url <- paste0(url, "&filters=", paste(filters, collapse = " AND "))

  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_institutions)
  data <- raw$data
  if (is.null(data) || length(data) == 0) return(.schema_institutions)

  tibble(
    cert = vapply(data, function(x) as.integer(x$data$CERT %||% NA), integer(1)),
    name = vapply(data, function(x) x$data$NAME %||% NA_character_, character(1)),
    city = vapply(data, function(x) x$data$CITY %||% NA_character_, character(1)),
    state = vapply(data, function(x) x$data$STNAME %||% NA_character_, character(1)),
    total_assets = vapply(data, function(x) as.numeric(x$data$ASSET %||% NA_real_), numeric(1))
  )
}




#' Get FDIC failed banks list
#'
#' @param limit Max results (default 50)
#' @return tibble: cert, name, city, state, closing_date, acquiring_institution
fdic_failures <- function(limit = 50L) {
  schema <- tibble(cert = integer(), name = character(), city = character(),
                   state = character(), closing_date = character(),
                   acquiring_institution = character())
  url <- sprintf("%s/failures?limit=%d&sort_by=FAILDATE&sort_order=DESC", .fdic_base, limit)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(schema)
  data <- raw$data
  if (is.null(data) || length(data) == 0) return(schema)

  tibble(
    cert = vapply(data, function(x) as.integer(x$data$CERT %||% NA), integer(1)),
    name = vapply(data, function(x) x$data$NAME %||% NA_character_, character(1)),
    city = vapply(data, function(x) x$data$CITYST %||% NA_character_, character(1)),
    state = vapply(data, function(x) x$data$PSTALP %||% NA_character_, character(1)),
    closing_date = vapply(data, function(x) x$data$FAILDATE %||% NA_character_, character(1)),
    acquiring_institution = vapply(data, function(x) x$data$APTS %||% NA_character_, character(1))
  )
}




#' Get bank financial history
#'
#' @param cert FDIC certificate number
#' @param limit Number of quarters (default 20)
#' @return tibble: cert, name, report_date, total_assets, total_deposits, net_income
fdic_financials <- function(cert, limit = 20L) {
  schema <- tibble(cert = integer(), name = character(), report_date = character(),
                   total_assets = numeric(), total_deposits = numeric(),
                   net_income = numeric())
  url <- sprintf("%s/financials?filters=CERT:%d&limit=%d&sort_by=REPDTE&sort_order=DESC",
                 .fdic_base, as.integer(cert), limit)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(schema)
  data <- raw$data
  if (is.null(data) || length(data) == 0) return(schema)

  tibble(
    cert = vapply(data, function(x) as.integer(x$data$CERT %||% NA), integer(1)),
    name = vapply(data, function(x) x$data$NAME %||% NA_character_, character(1)),
    report_date = vapply(data, function(x) x$data$REPDTE %||% NA_character_, character(1)),
    total_assets = vapply(data, function(x) as.numeric(x$data$ASSET %||% NA_real_), numeric(1)),
    total_deposits = vapply(data, function(x) as.numeric(x$data$DEP %||% NA_real_), numeric(1)),
    net_income = vapply(data, function(x) as.numeric(x$data$NETINC %||% NA_real_), numeric(1))
  )
}




#' Search FDIC institutions by name
#'
#' @param name Bank name or partial name (e.g. "Goldman", "Chase")
#' @param limit Max results (default 25)
#' @return tibble: cert, name, city, state, active
fdic_search <- function(name, limit = 25) {
  url <- sprintf(
    "%s/institutions?search=INSTNAME:%s&fields=CERT,INSTNAME,CITY,STALP,ACTIVE&limit=%d",
    .fdic_base, utils::URLencode(name), as.integer(limit)
  )
  raw <- .fetch_json(url)
  d <- raw$data
  if (is.null(d) || length(d) == 0) return(.schema_search)

  rows <- lapply(d, function(x) {
    r <- x$data %||% x
    tibble(
      cert = as.integer(r$CERT %||% NA),
      name = as.character(r$INSTNAME %||% NA),
      city = as.character(r$CITY %||% NA),
      state = as.character(r$STALP %||% NA),
      active = as.integer(r$ACTIVE %||% NA)
    )
  })
  bind_rows(rows)
}


# == Context ===================================================================

#' Generate LLM-friendly context for fdic.gov
#'
#' @return Character string with full function signatures and bodies
fdic_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/fdic.gov.R"
  if (!file.exists(src_file)) {
    cat("# fdic.gov context - source not found\n")
    return(invisible("# fdic.gov context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

