# fueleconomy.gov.R - Self-contained fueleconomy.gov client

library(httr2)
library(xml2)
library(tibble)


# fueleconomy-gov.R
# Self-contained FuelEconomy.gov API client (XML API).
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble, xml2
# Auth: none
# Rate limits: none documented


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.fuel_base <- "https://www.fueleconomy.gov/ws/rest"

`%||%` <- function(a, b) if (is.null(a) || length(a) == 0 || identical(a, "")) b else a

.fetch <- function(url, ext = ".xml") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_xml <- function(url) {
  xml2::read_xml(.fetch(url, ext = ".xml"))
}

# -- Parse menu items from XML ------------------------------------------------
.parse_menu <- function(xml_doc) {
  items <- xml2::xml_find_all(xml_doc, ".//menuItem")
  if (length(items) == 0) return(tibble(text = character(), value = character()))
  tibble(
    text  = xml2::xml_text(xml2::xml_find_all(xml_doc, ".//menuItem/text")),
    value = xml2::xml_text(xml2::xml_find_all(xml_doc, ".//menuItem/value"))
  )
}

# == Schemas ===================================================================

.schema_menu <- tibble(text = character(), value = character())

.schema_vehicle <- tibble(
  id = integer(), year = integer(), make = character(), model = character(),
  trany = character(), drive = character(), cylinders = integer(),
  displ = numeric(), fuel_type = character(),
  city_mpg = numeric(), highway_mpg = numeric(), comb_mpg = numeric(),
  co2 = numeric()
)


# == Public functions ==========================================================

#' Get available model years
#'
#' @return tibble: text (display year), value (year string)
fuel_years <- function() {
  url <- sprintf("%s/vehicle/menu/year", .fuel_base)
  .parse_menu(.fetch_xml(url))
}

#' Get makes available for a given year
#'
#' @param year Model year (e.g. 2024)
#' @return tibble: text (make name), value (make name)
fuel_makes <- function(year) {
  url <- sprintf("%s/vehicle/menu/make?year=%s", .fuel_base, as.integer(year))
  .parse_menu(.fetch_xml(url))
}

#' Get models available for a given year and make
#'
#' @param year Model year (e.g. 2024)
#' @param make Make name (e.g. "Toyota", "Ford")
#' @return tibble: text (model name), value (model id)
fuel_models <- function(year, make) {
  url <- sprintf("%s/vehicle/menu/model?year=%s&make=%s",
                 .fuel_base, as.integer(year),
                 utils::URLencode(as.character(make), reserved = TRUE))
  .parse_menu(.fetch_xml(url))
}

#' Get vehicle details by ID
#'
#' @param id Vehicle ID from fuel_models()
#' @return tibble with one row: id, year, make, model, trany, drive, cylinders,
#'   displ, fuel_type, city_mpg, highway_mpg, comb_mpg, co2
fuel_vehicle <- function(id) {
  url <- sprintf("%s/vehicle/%s", .fuel_base, as.integer(id))
  doc <- .fetch_xml(url)

  .xml_val <- function(node, tag) {
    v <- xml2::xml_text(xml2::xml_find_first(node, tag))
    if (is.na(v) || v == "") return(NA_character_)
    v
  }

  as_tibble(data.frame(
    id          = as.integer(.xml_val(doc, ".//id")),
    year        = as.integer(.xml_val(doc, ".//year")),
    make        = as.character(.xml_val(doc, ".//make")),
    model       = as.character(.xml_val(doc, ".//model")),
    trany       = as.character(.xml_val(doc, ".//trany")),
    drive       = as.character(.xml_val(doc, ".//drive")),
    cylinders   = as.integer(.xml_val(doc, ".//cylinders")),
    displ       = as.numeric(.xml_val(doc, ".//displ")),
    fuel_type   = as.character(.xml_val(doc, ".//fuelType")),
    city_mpg    = as.numeric(.xml_val(doc, ".//city08")),
    highway_mpg = as.numeric(.xml_val(doc, ".//highway08")),
    comb_mpg    = as.numeric(.xml_val(doc, ".//comb08")),
    co2         = as.numeric(.xml_val(doc, ".//co2TailpipeGpm")),
    stringsAsFactors = FALSE
  ))
}

# == Context ===================================================================

#' Generate LLM-friendly context for fueleconomy.gov
#'
#' @return Character string with full function signatures and bodies
fuel_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/fueleconomy.gov.R"
  if (!file.exists(src_file)) {
    cat("# fueleconomy.gov context - source not found\n")
    return(invisible("# fueleconomy.gov context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

