# psmsl.org.R - Self-contained psmsl.org client

library(httr2)
library(tibble)
library(dplyr)


# psmsl-org.R
# Self-contained Permanent Service for Mean Sea Level (PSMSL) client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required
# Rate limits: none documented


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.psmsl_base <- "https://psmsl.org"
# -- Fetch helpers -------------------------------------------------------------

.fetch <- function(url, ext = ".txt") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

`%||%` <- function(a, b) if (is.null(a)) b else a

# == Schemas ===================================================================

.schema_stations <- tibble(
  station_id = integer(), latitude = numeric(), longitude = numeric(),
  name = character(), coastline_code = integer(),
  station_code = integer(), quality = character()
)

.schema_annual <- tibble(
  year = integer(), level_mm = numeric(), missing = logical(),
  flag = character(), station_id = integer()
)



# == Station listing ===========================================================

#' List all PSMSL tide gauge stations
#'
#' Returns the complete station catalog from the Revised Local Reference
#' (RLR) dataset. Includes station coordinates, names, and metadata.
#'
#' @return tibble: station_id (integer), latitude (numeric),
#'   longitude (numeric), name (character), coastline_code (integer),
#'   station_code (integer), quality (character: Y/N for RLR quality)
psmsl_stations <- function() {
  url <- sprintf("%s/data/obtaining/rlr.monthly.data/filelist.txt", .psmsl_base)
  f <- .fetch(url)
  lines <- readLines(f, warn = FALSE)
  lines <- lines[nzchar(trimws(lines))]

  rows <- lapply(lines, function(line) {
    parts <- strsplit(line, ";")[[1]]
    if (length(parts) < 6) return(NULL)
    tibble(
      station_id     = as.integer(trimws(parts[1])),
      latitude       = as.numeric(trimws(parts[2])),
      longitude      = as.numeric(trimws(parts[3])),
      name           = trimws(parts[4]),
      coastline_code = as.integer(trimws(parts[5])),
      station_code   = as.integer(trimws(parts[6])),
      quality        = if (length(parts) >= 7) trimws(parts[7]) else NA_character_
    )
  })
  bind_rows(rows)
}


# == Annual sea level data =====================================================

#' Fetch annual mean sea level data for a PSMSL station
#'
#' Returns the Revised Local Reference (RLR) annual mean sea level
#' record for a specific tide gauge station. Values of -99999 indicate
#' missing data and are returned as NA.
#'
#' @param station_id PSMSL station ID (from psmsl_stations)
#' @return tibble: year (integer), level_mm (numeric, mm above RLR datum),
#'   missing (logical), flag (character), station_id (integer)
psmsl_annual <- function(station_id) {
  url <- sprintf("%s/data/obtaining/rlr.annual.data/%d.rlrdata",
                 .psmsl_base, station_id)
  f <- tryCatch(.fetch(url), error = function(e) NULL)
  if (is.null(f)) return(.schema_annual)

  lines <- readLines(f, warn = FALSE)
  lines <- lines[nzchar(trimws(lines))]
  if (length(lines) == 0) return(.schema_annual)

  rows <- lapply(lines, function(line) {
    parts <- strsplit(line, ";")[[1]]
    if (length(parts) < 2) return(NULL)
    yr <- as.integer(trimws(parts[1]))
    val <- as.numeric(trimws(parts[2]))
    is_missing <- !is.na(val) && val == -99999
    tibble(
      year       = yr,
      level_mm   = if (is_missing) NA_real_ else val,
      missing    = is_missing,
      flag       = if (length(parts) >= 3) trimws(parts[3]) else NA_character_,
      station_id = as.integer(station_id)
    )
  })
  bind_rows(rows)
}


# == Monthly data ==============================================================

#' Fetch monthly mean sea level data for a PSMSL station
#'
#' @param station_id PSMSL station ID (from psmsl_stations)
#' @return tibble: year, month, level_mm, missing, station_id
psmsl_monthly <- function(station_id) {
  schema <- tibble(year = integer(), month = integer(), level_mm = numeric(),
                   missing = logical(), station_id = integer())
  url <- sprintf("%s/data/obtaining/rlr.monthly.data/%d.rlrdata",
                 .psmsl_base, station_id)
  f <- tryCatch(.fetch(url), error = function(e) NULL)
  if (is.null(f)) return(schema)

  lines <- readLines(f, warn = FALSE)
  lines <- lines[nzchar(trimws(lines))]
  if (length(lines) == 0) return(schema)

  rows <- lapply(lines, function(line) {
    parts <- strsplit(line, ";")[[1]]
    if (length(parts) < 2) return(NULL)
    date_part <- as.numeric(trimws(parts[1]))
    yr <- as.integer(floor(date_part))
    mon <- as.integer(round((date_part - yr) * 12) + 1)
    val <- as.numeric(trimws(parts[2]))
    is_missing <- !is.na(val) && val == -99999
    tibble(
      year = yr, month = mon,
      level_mm = if (is_missing) NA_real_ else val,
      missing = is_missing,
      station_id = as.integer(station_id)
    )
  })
  bind_rows(rows)
}

# == Context ===================================================================

#' Generate LLM-friendly context for psmsl.org
#'
#' @return Character string with full function signatures and bodies
psmsl_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/psmsl.org.R"
  if (!file.exists(src_file)) {
    cat("# psmsl.org context - source not found\n")
    return(invisible("# psmsl.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

