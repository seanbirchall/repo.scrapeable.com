# osti.gov.R - Self-contained osti.gov client


# osti-gov.R
# Self-contained OSTI (Office of Scientific and Technical Information) API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required
# Rate limits: none documented


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.osti_base <- "https://www.osti.gov/api/v1"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua, Accept = "application/json") |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))


# == Schemas ===================================================================

.schema_records <- tibble(
  osti_id = character(), title = character(), authors = character(),
  publication_date = as.Date(character()), doi = character(),
  product_type = character(), journal_name = character(),
  sponsor_orgs = character(), description = character()
)

# == Public functions ==========================================================

#' Search OSTI scientific/technical records
#'
#' @param query Search query string
#' @param rows Maximum records to return (default 20)
#' @param page Page number (1-indexed, default 1)
#' @return tibble: osti_id, title, authors, publication_date, doi,
#'   product_type, journal_name, sponsor_orgs, description
osti_search <- function(query, rows = 20, page = 1) {
  url <- sprintf("%s/records?q=%s&rows=%d&page=%d",
                 .osti_base, utils::URLencode(query), rows, page)
  raw <- .fetch_json(url)
  if (is.null(raw) || length(raw) == 0) return(.schema_records)
  if (!is.data.frame(raw)) return(.schema_records)

  as_tibble(raw) |>
    transmute(
      osti_id = as.character(osti_id),
      title = as.character(title),
      authors = vapply(authors, function(a) {
        if (is.null(a) || length(a) == 0) return(NA_character_)
        paste(a, collapse = "; ")
      }, character(1)),
      publication_date = tryCatch(as.Date(substr(publication_date, 1, 10)),
                                  error = function(e) as.Date(NA)),
      doi = as.character(if ("doi" %in% names(raw)) doi else NA),
      product_type = as.character(if ("product_type" %in% names(raw)) product_type else NA),
      journal_name = as.character(if ("journal_name" %in% names(raw)) journal_name else NA),
      sponsor_orgs = vapply(sponsor_orgs, function(s) {
        if (is.null(s) || length(s) == 0) return(NA_character_)
        paste(s, collapse = "; ")
      }, character(1)),
      description = as.character(if ("description" %in% names(raw)) description else NA)
    )
}

#' Fetch a single OSTI record by ID
#'
#' @param id OSTI record ID
#' @return tibble: single row with record details
osti_record <- function(id) {
  url <- sprintf("%s/records/%s", .osti_base, as.character(id))
  raw <- .fetch_json(url)
  if (is.null(raw) || length(raw) == 0) return(.schema_records)
  if (!is.data.frame(raw)) return(.schema_records)

  as_tibble(raw) |>
    transmute(
      osti_id = as.character(osti_id),
      title = as.character(title),
      authors = vapply(authors, function(a) {
        if (is.null(a) || length(a) == 0) return(NA_character_)
        paste(a, collapse = "; ")
      }, character(1)),
      publication_date = tryCatch(as.Date(substr(publication_date, 1, 10)),
                                  error = function(e) as.Date(NA)),
      doi = as.character(if ("doi" %in% names(raw)) doi else NA),
      product_type = as.character(if ("product_type" %in% names(raw)) product_type else NA),
      journal_name = as.character(if ("journal_name" %in% names(raw)) journal_name else NA),
      sponsor_orgs = vapply(sponsor_orgs, function(s) {
        if (is.null(s) || length(s) == 0) return(NA_character_)
        paste(s, collapse = "; ")
      }, character(1)),
      description = as.character(if ("description" %in% names(raw)) description else NA)
    )
}

#' Search OSTI records by DOE sponsor organization
#'
#' @param sponsor DOE sponsor name (e.g. "USDOE Office of Science")
#' @param rows Maximum records (default 20)
#' @return tibble: osti_id, title, authors, publication_date, doi, product_type
osti_by_sponsor <- function(sponsor, rows = 20) {
  url <- sprintf("%s/records?sponsor_orgs=%s&rows=%d",
                 .osti_base, utils::URLencode(sponsor), rows)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || length(raw) == 0 || !is.data.frame(raw)) return(.schema_records)

  as_tibble(raw) |>
    transmute(
      osti_id = as.character(osti_id),
      title = as.character(title),
      authors = vapply(authors, function(a) {
        if (is.null(a) || length(a) == 0) return(NA_character_)
        paste(a, collapse = "; ")
      }, character(1)),
      publication_date = tryCatch(as.Date(substr(publication_date, 1, 10)),
                                  error = function(e) as.Date(NA)),
      doi = as.character(if ("doi" %in% names(raw)) doi else NA),
      product_type = as.character(if ("product_type" %in% names(raw)) product_type else NA),
      journal_name = as.character(if ("journal_name" %in% names(raw)) journal_name else NA),
      sponsor_orgs = vapply(sponsor_orgs, function(s) {
        if (is.null(s) || length(s) == 0) return(NA_character_)
        paste(s, collapse = "; ")
      }, character(1)),
      description = as.character(if ("description" %in% names(raw)) description else NA)
    )
}

#' Search OSTI records by subject area
#'
#' @param subject Subject area (e.g. "nuclear physics", "solar energy")
#' @param rows Maximum records (default 20)
#' @return tibble: osti_id, title, authors, publication_date, doi
osti_subject <- function(subject, rows = 20) {
  url <- sprintf("%s/records?subjects=%s&rows=%d",
                 .osti_base, utils::URLencode(subject), rows)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || length(raw) == 0 || !is.data.frame(raw)) return(.schema_records)

  as_tibble(raw) |>
    transmute(
      osti_id = as.character(osti_id),
      title = as.character(title),
      authors = vapply(authors, function(a) {
        if (is.null(a) || length(a) == 0) return(NA_character_)
        paste(a, collapse = "; ")
      }, character(1)),
      publication_date = tryCatch(as.Date(substr(publication_date, 1, 10)),
                                  error = function(e) as.Date(NA)),
      doi = as.character(if ("doi" %in% names(raw)) doi else NA),
      product_type = as.character(if ("product_type" %in% names(raw)) product_type else NA),
      journal_name = as.character(if ("journal_name" %in% names(raw)) journal_name else NA),
      sponsor_orgs = vapply(sponsor_orgs, function(s) {
        if (is.null(s) || length(s) == 0) return(NA_character_)
        paste(s, collapse = "; ")
      }, character(1)),
      description = as.character(if ("description" %in% names(raw)) description else NA)
    )
}

# == Context ===================================================================

#' Generate LLM-friendly context for osti.gov
#'
#' @return Character string with full function signatures and bodies
osti_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/osti.gov.R"
  if (!file.exists(src_file)) {
    cat("# osti.gov context - source not found\n")
    return(invisible("# osti.gov context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

