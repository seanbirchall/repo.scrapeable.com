# parliament.uk.R - Self-contained parliament.uk client

library(httr2)
library(jsonlite)
library(tibble)
library(dplyr)


# parliament-uk.R
# Self-contained UK Parliament Members API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required
# Rate limits: not documented


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.parl_base <- "https://members-api.parliament.uk/api"
# -- Fetch helpers -------------------------------------------------------------

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE)

# == Schemas ===================================================================

.schema_members <- tibble(
  id = integer(), name = character(), party = character(),
  constituency = character(), house = character(), gender = character(),
  start_date = as.Date(character()), status = character()
)

.schema_member <- tibble(
  id = integer(), name = character(), full_title = character(),
  party = character(), constituency = character(), house = character(),
  gender = character(), start_date = as.Date(character()),
  status = character()
)


# == Public functions ==========================================================

#' Search UK Parliament members
#'
#' Returns members of the UK Parliament matching search criteria.
#'
#' @param name Optional name to search for
#' @param house House filter: 1 = Commons, 2 = Lords, NULL = both (default)
#' @param is_current Logical: TRUE for current members only (default TRUE)
#' @param take Number of results per page (default 20, max 100)
#' @param skip Number of results to skip for pagination (default 0)
#' @return tibble: id, name, party, constituency, house, gender, start_date, status
parl_members <- function(name = NULL, house = NULL, is_current = TRUE,
                         take = 20, skip = 0) {
  params <- list(
    Name = name, House = house, IsCurrentMember = tolower(as.character(is_current)),
    take = take, skip = skip
  )
  params <- params[!vapply(params, is.null, logical(1))]
  query <- paste(names(params), params, sep = "=", collapse = "&")
  url <- sprintf("%s/Members/Search?%s", .parl_base, query)

  raw <- .fetch_json(url)
  items <- raw$items
  if (is.null(items) || length(items) == 0) return(.schema_members)

  rows <- lapply(items, function(item) {
    v <- item$value
    membership <- v$latestHouseMembership
    tibble(
      id = as.integer(v$id),
      name = as.character(v$nameDisplayAs %||% NA),
      party = as.character(v$latestParty$name %||% NA),
      constituency = as.character(membership$membershipFrom %||% NA),
      house = if (identical(membership$house, 1L)) "Commons" else if (identical(membership$house, 2L)) "Lords" else as.character(membership$house %||% NA),
      gender = as.character(v$gender %||% NA),
      start_date = tryCatch(as.Date(sub("T.*", "", membership$membershipStartDate)), error = function(e) NA_real_),
      status = as.character(membership$membershipStatus$statusDescription %||% NA)
    )
  })
  bind_rows(rows)
}

#' Get a specific UK Parliament member by ID
#'
#' @param id Member ID (integer)
#' @return tibble: id, name, full_title, party, constituency, house,
#'   gender, start_date, status
parl_member <- function(id) {
  url <- sprintf("%s/Members/%d", .parl_base, as.integer(id))
  raw <- .fetch_json(url)
  v <- raw$value
  if (is.null(v)) return(.schema_member)

  membership <- v$latestHouseMembership
  tibble(
    id = as.integer(v$id),
    name = as.character(v$nameDisplayAs %||% NA),
    full_title = as.character(v$nameFullTitle %||% NA),
    party = as.character(v$latestParty$name %||% NA),
    constituency = as.character(membership$membershipFrom %||% NA),
    house = if (identical(membership$house, 1L)) "Commons" else if (identical(membership$house, 2L)) "Lords" else as.character(membership$house %||% NA),
    gender = as.character(v$gender %||% NA),
    start_date = tryCatch(as.Date(sub("T.*", "", membership$membershipStartDate)), error = function(e) NA_real_),
    status = as.character(membership$membershipStatus$statusDescription %||% NA)
  )
}
# -- null coalesce operator ---
`%||%` <- function(lhs, rhs) if (is.null(lhs)) rhs else lhs

# == Context ===================================================================

#' Generate LLM-friendly context for parliament.uk
#'
#' @return Character string with full function signatures and bodies
parl_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/parliament.uk.R"
  if (!file.exists(src_file)) {
    cat("# parliament.uk context - source not found\n")
    return(invisible("# parliament.uk context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

