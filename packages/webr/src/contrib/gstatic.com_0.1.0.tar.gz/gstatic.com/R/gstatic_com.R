# gstatic.com.R - Self-contained gstatic.com client



# gstatic-com.R
# Self-contained Google Cloud IP Ranges client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required
# Rate limits: none (static JSON file)


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.gcp_url <- "https://www.gstatic.com/ipranges/cloud.json"

`%||%` <- function(a, b) if (is.null(a)) b else a
# -- Fetch helpers -------------------------------------------------------------

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))

# == Schemas ===================================================================

.schema_ranges <- tibble(
  ip_prefix = character(), service = character(), scope = character()
)

# == Public functions ==========================================================

#' Fetch Google Cloud IP address ranges
#'
#' Returns the current list of Google Cloud IP address ranges, optionally
#' filtered by service and/or scope (region).
#'
#' @param service Optional filter by service name (e.g. "Google Cloud").
#'   Case-insensitive.
#' @param scope Optional filter by scope/region (e.g. "us-east1", "europe-west1")
#' @return tibble: ip_prefix, service, scope
gcpip_ranges <- function(service = NULL, scope = NULL) {
  raw <- .fetch_json(.gcp_url)
  prefixes <- raw$prefixes
  if (is.null(prefixes) || length(prefixes) == 0) return(.schema_ranges)

  df <- as_tibble(prefixes)
  # Combine ipv4Prefix and ipv6Prefix into ip_prefix
  if ("ipv4Prefix" %in% names(df) && "ipv6Prefix" %in% names(df)) {
    df <- df |> mutate(ip_prefix = ifelse(is.na(ipv4Prefix), ipv6Prefix, ipv4Prefix))
  } else if ("ipv4Prefix" %in% names(df)) {
    df <- df |> mutate(ip_prefix = ipv4Prefix)
  } else if ("ipv6Prefix" %in% names(df)) {
    df <- df |> mutate(ip_prefix = ipv6Prefix)
  } else {
    return(.schema_ranges)
  }

  result <- df |> select(ip_prefix, service, scope)

  if (!is.null(service)) {
    result <- result |> filter(toupper(service) == toupper(!!service))
  }
  if (!is.null(scope)) {
    result <- result |> filter(scope == !!scope)
  }

  result
}

#' List unique GCP services with IP range counts
#'
#' @return tibble: service, ipv4_count, ipv6_count, total
gcpip_services <- function() {
  schema <- tibble(service = character(), ipv4_count = integer(),
                   ipv6_count = integer(), total = integer())
  raw <- tryCatch(.fetch_json(.gcp_url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$prefixes)) return(schema)

  df <- as_tibble(raw$prefixes)
  if (nrow(df) == 0) return(schema)

  df |>
    mutate(has_v4 = !is.na(ipv4Prefix), has_v6 = !is.na(ipv6Prefix)) |>
    group_by(service) |>
    summarise(
      ipv4_count = sum(has_v4),
      ipv6_count = sum(has_v6),
      total = n(),
      .groups = "drop"
    ) |>
    arrange(desc(total))
}

#' List unique GCP regions/scopes with IP range counts
#'
#' @return tibble: scope, count
gcpip_regions <- function() {
  schema <- tibble(scope = character(), count = integer())
  raw <- tryCatch(.fetch_json(.gcp_url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$prefixes)) return(schema)

  df <- as_tibble(raw$prefixes)
  if (nrow(df) == 0) return(schema)

  df |>
    group_by(scope) |>
    summarise(count = n(), .groups = "drop") |>
    arrange(desc(count))
}

# == Context ===================================================================

#' Generate LLM-friendly context for gstatic.com
#'
#' @return Character string with full function signatures and bodies
gstatic_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/gstatic.com.R"
  if (!file.exists(src_file)) {
    cat("# gstatic.com context - source not found\n")
    return(invisible("# gstatic.com context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

