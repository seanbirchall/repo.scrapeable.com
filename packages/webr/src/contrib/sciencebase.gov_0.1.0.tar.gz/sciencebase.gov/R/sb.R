# == Search ====================================================================

#' Search the ScienceBase catalog
#'
#' @param q Search query string
#' @param folder_id Optional parent folder/item ID to search within
#' @param max Number of results (default 20, max 100)
#' @param offset Pagination offset (default 0)
#' @param fields Comma-separated fields to return (default: id, title, summary,
#'   hasChildren, provenance, tags)
#' @return tibble: id, title, summary, hasChildren, dateCreated, lastUpdated, tags
#' @export
sb_search <- function(q, folder_id = NULL, max = 20, offset = 0,
                      fields = "id,title,summary,hasChildren,provenance,tags") {
  params <- list(
    format = "json", q = q, max = min(max, 100), offset = offset,
    fields = fields
  )
  if (!is.null(folder_id)) params$parentId <- folder_id

  pairs <- paste0(names(params), "=",
    vapply(params, function(x) utils::URLencode(as.character(x), reserved = TRUE), character(1)))
  url <- paste0(.sb_base, "/items?", paste(pairs, collapse = "&"))

  res <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(res) || is.null(res$items) || length(res$items) == 0)
    return(.schema_item)

  items <- res$items
  n <- length(items$id)

  prov <- items$provenance
  dc <- if (!is.null(prov) && "dateCreated" %in% names(prov))
    as.POSIXct(prov$dateCreated, format = "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  else rep(as.POSIXct(NA), n)

  lu <- if (!is.null(prov) && "lastUpdated" %in% names(prov))
    as.POSIXct(prov$lastUpdated, format = "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  else rep(as.POSIXct(NA), n)

  tag_vals <- if ("tags" %in% names(items) && is.list(items$tags)) {
    vapply(items$tags, function(t) {
      if (is.data.frame(t)) paste(t$name, collapse = "; ") else NA_character_
    }, character(1))
  } else rep(NA_character_, n)

  tibble(
    id = as.character(items$id),
    title = as.character(items$title),
    summary = as.character(.safe_col(items, "summary")),
    hasChildren = as.logical(.safe_col(items, "hasChildren", NA)),
    dateCreated = dc,
    lastUpdated = lu,
    tags = tag_vals
  )
}

# == Item Detail ===============================================================

#' Get full details for a ScienceBase item
#'
#' @param item_id ScienceBase item ID
#' @return tibble with one row: id, title, summary, hasChildren, dateCreated,
#'   lastUpdated, tags, contacts, files
#' @export
sb_item <- function(item_id) {
  url <- sprintf("%s/item/%s?format=json&fields=id,title,summary,hasChildren,provenance,tags,contacts,files",
                 .sb_base, item_id)
  d <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(d)) return(.schema_item_detail[0, ])

  prov <- d$provenance
  dc <- if (!is.null(prov$dateCreated))
    as.POSIXct(prov$dateCreated, format = "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  else as.POSIXct(NA)
  lu <- if (!is.null(prov$lastUpdated))
    as.POSIXct(prov$lastUpdated, format = "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  else as.POSIXct(NA)

  tags_str <- if (is.data.frame(d$tags)) paste(d$tags$name, collapse = "; ")
    else NA_character_

  contacts_str <- if (is.data.frame(d$contacts))
    paste(d$contacts$name %||% character(0), collapse = "; ")
  else NA_character_

  files_str <- if (is.data.frame(d$files))
    paste(d$files$name %||% character(0), collapse = "; ")
  else NA_character_

  tibble(
    id = as.character(d$id %||% NA_character_),
    title = as.character(d$title %||% NA_character_),
    summary = as.character(d$summary %||% NA_character_),
    hasChildren = as.logical(d$hasChildren %||% NA),
    dateCreated = dc,
    lastUpdated = lu,
    tags = tags_str,
    contacts = contacts_str,
    files = files_str
  )
}

# == Child Items ===============================================================

#' List child items of a ScienceBase item
#'
#' @param parent_id Parent item ID
#' @param max Number of results (default 20, max 100)
#' @param offset Pagination offset (default 0)
#' @return tibble: id, title, summary, hasChildren, dateCreated, lastUpdated, tags
#' @export
sb_children <- function(parent_id, max = 20, offset = 0) {
  url <- sprintf("%s/items?format=json&parentId=%s&max=%d&offset=%d&fields=id,title,summary,hasChildren,provenance,tags",
                 .sb_base, parent_id, min(max, 100), offset)
  res <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(res) || is.null(res$items) || length(res$items) == 0)
    return(.schema_item)

  items <- res$items
  n <- length(items$id)

  prov <- items$provenance
  dc <- if (!is.null(prov) && "dateCreated" %in% names(prov))
    as.POSIXct(prov$dateCreated, format = "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  else rep(as.POSIXct(NA), n)

  lu <- if (!is.null(prov) && "lastUpdated" %in% names(prov))
    as.POSIXct(prov$lastUpdated, format = "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  else rep(as.POSIXct(NA), n)

  tag_vals <- if ("tags" %in% names(items) && is.list(items$tags)) {
    vapply(items$tags, function(t) {
      if (is.data.frame(t)) paste(t$name, collapse = "; ") else NA_character_
    }, character(1))
  } else rep(NA_character_, n)

  tibble(
    id = as.character(items$id),
    title = as.character(items$title),
    summary = as.character(.safe_col(items, "summary")),
    hasChildren = as.logical(.safe_col(items, "hasChildren", NA)),
    dateCreated = dc,
    lastUpdated = lu,
    tags = tag_vals
  )
}

# == Context ===================================================================

#' Return the full source of this client for LLM context
#'
#' @return character string of the source file
#' @export
sb_context <- function() {
  f <- system.file("source", "sciencebase.gov.R", package = "sciencebase.gov", mustWork = FALSE)
  if (f == "") {
    sf <- sys.frame(1)$ofile %||% ""
    if (nzchar(sf)) f <- sf
  }
  if (nzchar(f)) paste(readLines(f, warn = FALSE), collapse = "\n") else
    "Source not found. Load from inst/source/sciencebase.gov.R"
}
