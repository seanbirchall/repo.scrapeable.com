#' List all known ENERGY STAR product categories
#'
#' Returns a tibble of ~70 product categories with view_id for use in
#' estar_products() or estar_view().
#'
#' @return tibble with columns: category, view_id, description
#' @export
estar_list <- function() {
  .estar_catalog
}

#' Search ENERGY STAR product categories by keyword
#'
#' @param query Character string to match against category names and descriptions
#' @return tibble of matching categories
#' @export
estar_search <- function(query) {
  q <- tolower(query)
  .estar_catalog |>
    dplyr::filter(
      grepl(q, tolower(category)) | grepl(q, tolower(description))
    )
}

#' Fetch certified products by category name
#'
#' @param category Category name (partial match against catalog). Use estar_list()
#'   to see valid names.
#' @param limit Maximum number of records to return (default 1000)
#' @param where Optional SoQL WHERE clause for filtering (e.g. "brand_name='LG'")
#' @param q Optional full-text search query
#' @return tibble of certified products
#' @export
estar_products <- function(category, limit = 1000, where = NULL, q = NULL) {
  cat_lower <- tolower(category)
  match <- .estar_catalog |>
    dplyr::filter(grepl(cat_lower, tolower(.data$category), fixed = TRUE))
  if (nrow(match) == 0) {
    stop("No category matching '", category, "'. Use estar_list() to see options.")
  }
  if (nrow(match) > 1) {
    message("Multiple matches found, using first: ", match$category[1])
  }
  .estar_fetch(match$view_id[1], where = where, q = q, limit = limit)
}

#' Generic SODA query escape hatch
#'
#' @param view_id Socrata view ID (e.g. "rxdj-2c88")
#' @param limit Maximum records (default 1000)
#' @param where Optional SoQL WHERE clause
#' @param select Optional SoQL SELECT clause
#' @param q Optional full-text search query
#' @param offset Starting row offset (default 0)
#' @return tibble
#' @export
estar_view <- function(view_id, limit = 1000, where = NULL, select = NULL,
                       q = NULL, offset = 0) {
  .estar_fetch(view_id, where = where, select = select, q = q, limit = limit)
}

#' Fetch certified computers
#'
#' @param limit Maximum records (default 1000)
#' @param where Optional SoQL WHERE clause (e.g. "brand_name='Apple'")
#' @param q Optional full-text search
#' @return tibble of certified computers
#' @export
estar_computers <- function(limit = 1000, where = NULL, q = NULL) {
  .estar_fetch("rxdj-2c88", where = where, q = q, limit = limit)
}

#' Fetch certified commercial refrigerators and freezers
#'
#' @param limit Maximum records (default 1000)
#' @param where Optional SoQL WHERE clause
#' @param q Optional full-text search
#' @return tibble
#' @export
estar_refrigerators <- function(limit = 1000, where = NULL, q = NULL) {
  .estar_fetch("wati-2tfp", where = where, q = q, limit = limit)
}

#' Fetch certified residential clothes dryers
#'
#' @param limit Maximum records (default 1000)
#' @param where Optional SoQL WHERE clause
#' @param q Optional full-text search
#' @return tibble
#' @export
estar_dryers <- function(limit = 1000, where = NULL, q = NULL) {
  .estar_fetch("t9u7-4d2j", where = where, q = q, limit = limit)
}

#' Fetch certified EV supply equipment (DC output)
#'
#' @param limit Maximum records (default 1000)
#' @param where Optional SoQL WHERE clause
#' @param q Optional full-text search
#' @return tibble
#' @export
estar_ev_chargers <- function(limit = 1000, where = NULL, q = NULL) {
  .estar_fetch("t3a6-mkxz", where = where, q = q, limit = limit)
}

#' Fetch certified displays
#'
#' @param limit Maximum records (default 1000)
#' @param where Optional SoQL WHERE clause
#' @param q Optional full-text search
#' @return tibble
#' @export
estar_displays <- function(limit = 1000, where = NULL, q = NULL) {
  .estar_fetch("qbg3-d468", where = where, q = q, limit = limit)
}

#' Fetch certified televisions
#'
#' @param limit Maximum records (default 1000)
#' @param where Optional SoQL WHERE clause
#' @param q Optional full-text search
#' @return tibble
#' @export
estar_televisions <- function(limit = 1000, where = NULL, q = NULL) {
  .estar_fetch("pd96-rr3d", where = where, q = q, limit = limit)
}

#' Fetch certified residential dishwashers
#'
#' @param limit Maximum records (default 1000)
#' @param where Optional SoQL WHERE clause
#' @param q Optional full-text search
#' @return tibble
#' @export
estar_dishwashers <- function(limit = 1000, where = NULL, q = NULL) {
  .estar_fetch("q8py-6w3f", where = where, q = q, limit = limit)
}

#' Fetch certified residential clothes washers
#'
#' @param limit Maximum records (default 1000)
#' @param where Optional SoQL WHERE clause
#' @param q Optional full-text search
#' @return tibble
#' @export
estar_washers <- function(limit = 1000, where = NULL, q = NULL) {
  .estar_fetch("bghd-e2wd", where = where, q = q, limit = limit)
}

#' Fetch certified residential refrigerators
#'
#' @param limit Maximum records (default 1000)
#' @param where Optional SoQL WHERE clause
#' @param q Optional full-text search
#' @return tibble
#' @export
estar_home_refrigerators <- function(limit = 1000, where = NULL, q = NULL) {
  .estar_fetch("p5st-her9", where = where, q = q, limit = limit)
}

#' Fetch certified smart thermostats
#'
#' @param limit Maximum records (default 1000)
#' @param where Optional SoQL WHERE clause
#' @param q Optional full-text search
#' @return tibble
#' @export
estar_thermostats <- function(limit = 1000, where = NULL, q = NULL) {
  .estar_fetch("7p2p-wkbf", where = where, q = q, limit = limit)
}

#' Fetch certified heat pumps (general)
#'
#' @param limit Maximum records (default 1000)
#' @param where Optional SoQL WHERE clause
#' @param q Optional full-text search
#' @return tibble
#' @export
estar_heat_pumps <- function(limit = 1000, where = NULL, q = NULL) {
  .estar_fetch("83eb-xbyy", where = where, q = q, limit = limit)
}

#' Fetch certified furnaces
#'
#' @param limit Maximum records (default 1000)
#' @param where Optional SoQL WHERE clause
#' @param q Optional full-text search
#' @return tibble
#' @export
estar_furnaces <- function(limit = 1000, where = NULL, q = NULL) {
  .estar_fetch("i97v-e8au", where = where, q = q, limit = limit)
}

#' Return full source code of this client for LLM context
#'
#' @return character string with the full contents of this file
#' @export
estar_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/energystar.gov.R"
  if (!file.exists(src_file)) {
    pkg_dir <- system.file("source", "energystar.R", package = "energystar.gov")
    if (nzchar(pkg_dir)) src_file <- pkg_dir
  }
  if (!file.exists(src_file)) return("Source not available")
  paste(readLines(src_file, warn = FALSE), collapse = "\n")
}
