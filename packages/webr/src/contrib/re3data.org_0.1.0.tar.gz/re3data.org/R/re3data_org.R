# re3data.org.R - Self-contained re3data.org client



.ua <- "support@scrapeable.com"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) {
  jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE)
}

`%||%` <- function(a, b) if (is.null(a)) b else a

.re3_base <- "https://www.re3data.org/api/beta"

#' Search research data repositories
#'
#' @param query Search term (e.g., "genomics", "climate", "astronomy")
#' @return tibble: id, name, link
re3_search <- function(query) {
  schema <- tibble(id = character(), name = character(), link = character())
  url <- sprintf("%s/repositories?query=%s", .re3_base, utils::URLencode(query, reserved = TRUE))
  tmp <- .fetch(url, ext = ".xml")
  doc <- tryCatch(xml2::read_xml(tmp), error = function(e) NULL)
  if (is.null(doc)) return(schema)

  repos <- xml2::xml_find_all(doc, ".//repository")
  if (length(repos) == 0) return(schema)
  tibble(
    id = xml2::xml_text(xml2::xml_find_first(repos, ".//id")),
    name = xml2::xml_text(xml2::xml_find_first(repos, ".//name")),
    link = xml2::xml_text(xml2::xml_find_first(repos, ".//link"))
  )
}

#' Get detailed info about a research data repository
#'
#' @param repo_id Repository ID from re3_search (e.g., "r3d100010468")
#' @return tibble: id, name, url, description, subjects, content_types,
#'   provider_types, countries
re3_repository <- function(repo_id) {
  schema <- tibble(id = character(), name = character(), url = character(),
                   description = character(), subjects = character(),
                   content_types = character(), provider_types = character(),
                   countries = character())
  api_url <- sprintf("%s/repository/%s", .re3_base, repo_id)
  tmp <- .fetch(api_url, ext = ".xml")
  doc <- tryCatch(xml2::read_xml(tmp), error = function(e) NULL)
  if (is.null(doc)) return(schema)

  ns <- xml2::xml_ns(doc)
  get_text <- function(xpath) {
    nodes <- xml2::xml_find_all(doc, xpath)
    if (length(nodes) == 0) return(NA_character_)
    paste(xml2::xml_text(nodes), collapse = "; ")
  }

  tibble(
    id = repo_id,
    name = get_text(".//r3d:repositoryName"),
    url = get_text(".//r3d:repositoryURL"),
    description = get_text(".//r3d:description"),
    subjects = get_text(".//r3d:subject"),
    content_types = get_text(".//r3d:contentType"),
    provider_types = get_text(".//r3d:providerType"),
    countries = get_text(".//r3d:institutionCountry")
  )
}

#' List all research data repositories (paginated)
#'
#' @return tibble: id, name, link
re3_list <- function() {
  schema <- tibble(id = character(), name = character(), link = character())
  url <- sprintf("%s/repositories", .re3_base)
  tmp <- .fetch(url, ext = ".xml")
  doc <- tryCatch(xml2::read_xml(tmp), error = function(e) NULL)
  if (is.null(doc)) return(schema)

  repos <- xml2::xml_find_all(doc, ".//repository")
  if (length(repos) == 0) return(schema)
  tibble(
    id = xml2::xml_text(xml2::xml_find_first(repos, ".//id")),
    name = xml2::xml_text(xml2::xml_find_first(repos, ".//name")),
    link = xml2::xml_text(xml2::xml_find_first(repos, ".//link"))
  )
}

# == Context ===================================================================

#' Generate LLM-friendly context for re3data.org
#'
#' @return Character string with full function signatures and bodies
re3data_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/re3data.org.R"
  if (!file.exists(src_file)) {
    cat("# re3data.org context - source not found\n")
    return(invisible("# re3data.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

