# == Public functions ==========================================================

#' Search Flickr public photos by tags
#'
#' @param tags Comma-separated tag string (e.g. "nature,landscape")
#' @param tagmode Tag matching mode: "any" (OR) or "all" (AND). Default "any".
#' @return tibble: title, link, author, author_id, tags, date_taken, published, image_url
#' @export
flickr_search <- function(tags, tagmode = "any") {
  url <- paste0(.flickr_feeds_base,
                "/photos_public.gne?format=json&nojsoncallback=1",
                "&tags=", utils::URLencode(tags),
                "&tagmode=", tagmode)
  data <- .fetch_json(url)
  .parse_feed_items(data)
}

#' Fetch recent public photos from a Flickr user
#'
#' @param user_id Flickr user ID (e.g. "12345678@N00")
#' @return tibble: title, link, author, author_id, tags, date_taken, published, image_url
#' @export
flickr_user_photos <- function(user_id) {
  url <- paste0(.flickr_feeds_base,
                "/photos_public.gne?format=json&nojsoncallback=1",
                "&id=", utils::URLencode(user_id))
  data <- .fetch_json(url)
  .parse_feed_items(data)
}

#' Fetch recent public photos from Flickr (no filter)
#'
#' @return tibble: title, link, author, author_id, tags, date_taken, published, image_url
#' @export
flickr_recent <- function() {
  url <- paste0(.flickr_feeds_base,
                "/photos_public.gne?format=json&nojsoncallback=1")
  data <- .fetch_json(url)
  .parse_feed_items(data)
}

#' Fetch Flickr geotagged photos feed
#'
#' @param tags Optional comma-separated tags to filter
#' @return tibble: title, link, author, author_id, tags, date_taken, published, image_url
#' @export
flickr_geo <- function(tags = NULL) {
  url <- paste0(.flickr_feeds_base,
                "/geo?format=json&nojsoncallback=1")
  if (!is.null(tags)) {
    url <- paste0(url, "&tags=", utils::URLencode(tags))
  }
  data <- .fetch_json(url)
  .parse_feed_items(data)
}

#' List available Flickr public feeds
#'
#' @return tibble: id, name, description
#' @export
flickr_list <- function() {
  tibble(
    id = c("photos_public", "geo"),
    name = c("Public Photos", "Geotagged Photos"),
    description = c(
      "Recent public photos, filterable by tags or user ID",
      "Recent geotagged public photos"
    )
  )
}

#' Return context: full source of this client
#'
#' @return character: source code of this file
#' @export
flickr_context <- function() {
  f <- system.file("source", "flickr.com.R", package = "flickr.com")
  if (f == "") {
    f <- tryCatch(
      { env <- sys.frame(0); getSrcFilename(env, full.names = TRUE) },
      error = function(e) ""
    )
  }
  if (f == "" || !file.exists(f)) return("Source not available")
  paste(readLines(f, warn = FALSE), collapse = "\n")
}
