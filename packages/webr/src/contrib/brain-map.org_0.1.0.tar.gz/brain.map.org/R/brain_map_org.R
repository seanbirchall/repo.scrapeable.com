# portal.brain-map.org.R - Self-contained portal.brain-map.org client


`%||%` <- function(a, b) if (is.null(a)) b else a

.ua <- "support@scrapeable.com"
.allen_base <- "https://api.brain-map.org/api/v2"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = FALSE)
.fetch_json_df <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = TRUE)

# == Schemas ===================================================================

.schema_structures <- tibble(
  id = integer(), name = character(), acronym = character(),
  parent_structure_id = integer()
)

.schema_genes <- tibble(
  id = integer(), acronym = character(), name = character(),
  entrez_id = integer()
)

# == Public functions ==========================================================

#' Search Allen Brain Atlas structures
#'
#' Returns brain structures from the Allen Reference Atlas.
#'
#' @param query Search term for structure name (optional). If NULL, returns
#'   structures from the default atlas product.
#' @param num_rows Max results (default 50)
#' @return tibble: id, name, acronym, parent_structure_id
allen_structures <- function(query = NULL, num_rows = 50) {
  if (!is.null(query)) {
    url <- sprintf("%s/data/Structure/query.json?criteria=[name$il*%s*]&num_rows=%d",
                   .allen_base, URLencode(query, TRUE), num_rows)
  } else {
    url <- sprintf("%s/data/Structure/query.json?num_rows=%d", .allen_base, num_rows)
  }
  raw <- .fetch_json(url)
  msgs <- raw$msg
  if (is.null(msgs) || length(msgs) == 0 || is.character(msgs)) return(.schema_structures)
  tibble(
    id = vapply(msgs, function(x) as.integer(x$id %||% NA), integer(1)),
    name = vapply(msgs, function(x) as.character(x$name %||% NA), character(1)),
    acronym = vapply(msgs, function(x) as.character(x$acronym %||% NA), character(1)),
    parent_structure_id = vapply(msgs, function(x) as.integer(x$parent_structure_id %||% NA), integer(1))
  )
}

#' Search Allen Brain Atlas genes
#'
#' @param query Gene name or symbol to search for
#' @param num_rows Max results (default 50)
#' @return tibble: id, acronym, name, entrez_id
allen_genes <- function(query, num_rows = 50) {
  url <- sprintf("%s/data/Gene/query.json?criteria=[acronym$il*%s*]&num_rows=%d",
                 .allen_base, URLencode(query, TRUE), num_rows)
  raw <- .fetch_json(url)
  msgs <- raw$msg
  if (is.null(msgs) || length(msgs) == 0 || is.character(msgs)) return(.schema_genes)
  tibble(
    id = vapply(msgs, function(x) as.integer(x$id %||% NA), integer(1)),
    acronym = vapply(msgs, function(x) as.character(x$acronym %||% NA), character(1)),
    name = vapply(msgs, function(x) as.character(x$name %||% NA), character(1)),
    entrez_id = vapply(msgs, function(x) as.integer(x$entrez_id %||% NA), integer(1))
  )
}

#' List Allen Brain Atlas datasets/products
#'
#' Returns available atlas products (e.g. Human Brain Atlas, Mouse Brain Atlas).
#'
#' @param num_rows Max results (default 50)
#' @return tibble: id, name, abbreviation, description
allen_products <- function(num_rows = 50) {
  schema <- tibble(id = integer(), name = character(),
                   abbreviation = character(), description = character())
  url <- sprintf("%s/data/Product/query.json?num_rows=%d", .allen_base, num_rows)
  raw <- .fetch_json(url)
  msgs <- raw$msg
  if (is.null(msgs) || length(msgs) == 0 || is.character(msgs)) return(schema)
  tibble(
    id = vapply(msgs, function(x) as.integer(x$id %||% NA), integer(1)),
    name = vapply(msgs, function(x) as.character(x$name %||% NA), character(1)),
    abbreviation = vapply(msgs, function(x) as.character(x$abbreviation %||% NA), character(1)),
    description = vapply(msgs, function(x) as.character(x$description %||% NA), character(1))
  )
}

# == Context ===================================================================

#' Generate LLM-friendly context for portal.brain-map.org
#'
#' @return Character string with full function signatures and bodies
allen_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/portal.brain-map.org.R"
  if (!file.exists(src_file)) {
    cat("# portal.brain-map.org context - source not found\n")
    return(invisible("# portal.brain-map.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

