# courtlistener.com.R - Self-contained courtlistener.com client

library(httr2)
library(jsonlite)
library(tibble)
library(dplyr)


# courtlistener.R
# Self-contained CourtListener API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required for basic search
# Rate limits: be respectful


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.cl_base <- "https://www.courtlistener.com/api/rest/v4"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))

`%||%` <- function(a, b) if (is.null(a)) b else a

# == Schemas ===================================================================

.schema_search <- tibble(
  cluster_id = integer(), caseName = character(), court = character(),
  dateFiled = as.Date(character()), snippet = character(),
  url = character()
)

.schema_opinion <- tibble(
  cluster_id = integer(), caseName = character(), court = character(),
  dateFiled = as.Date(character()), snippet = character(),
  url = character(), plain_text = character()
)

# == Search ====================================================================

#' Search CourtListener legal opinions and dockets
#'
#' @param query Search query string (e.g. "privacy", "first amendment")
#' @param type Result type: "o" = opinions, "r" = RECAP, "d" = dockets,
#'   "p" = people (default "o")
#' @param page_size Number of results (default 10)
#' @param page Page number (default 1)
#' @return tibble: id, caseName, court, dateFiled, snippet, url
cl_search <- function(query, type = "o", page_size = 10, page = 1) {
  url <- paste0(.cl_base, "/search/?q=", utils::URLencode(query),
                "&type=", type, "&page_size=", page_size, "&page=", page)
  raw <- .fetch_json(url)
  d <- raw$results
  if (is.null(d) || length(d) == 0) return(.schema_search)

  as_tibble(d) |>
    transmute(
      cluster_id = as.integer(cluster_id),
      caseName = as.character(caseName),
      court = as.character(if ("court" %in% names(d)) court else NA_character_),
      dateFiled = tryCatch(as.Date(dateFiled), error = function(e) as.Date(NA)),
      snippet = as.character(if ("syllabus" %in% names(d)) syllabus else NA_character_),
      url = paste0("https://www.courtlistener.com", as.character(absolute_url))
    )
}

# == Opinion detail ============================================================

#' Fetch a CourtListener opinion cluster by ID
#'
#' @param id Opinion cluster ID (integer)
#' @return tibble: one row with id, caseName, court, dateFiled, snippet, url, plain_text
cl_opinion <- function(id) {
  url <- paste0(.cl_base, "/clusters/", id, "/")
  raw <- .fetch_json(url)
  if (is.null(raw) || is.null(raw$id)) return(.schema_opinion)

  tibble(
    cluster_id = as.integer(raw$id),
    caseName = as.character(raw$case_name %||% NA_character_),
    court = as.character(raw$court %||% NA_character_),
    dateFiled = tryCatch(as.Date(raw$date_filed), error = function(e) as.Date(NA)),
    snippet = as.character(raw$syllabus %||% NA_character_),
    url = paste0("https://www.courtlistener.com", as.character(raw$absolute_url %||% "")),
    plain_text = NA_character_
  )
}

# == Courts ====================================================================

#' List courts available on CourtListener
#'
#' @param page_size Number of results (default 20)
#' @return tibble: id, full_name, short_name, jurisdiction, url
cl_courts <- function(page_size = 20) {
  schema <- tibble(id = character(), full_name = character(),
                   short_name = character(), jurisdiction = character(),
                   url = character())
  url <- sprintf("%s/courts/?page_size=%d", .cl_base, as.integer(page_size))
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$results)) return(schema)
  d <- raw$results
  if (length(d) == 0 || nrow(d) == 0) return(schema)

  as_tibble(d) |>
    transmute(
      id = as.character(if ("id" %in% names(d)) id else NA_character_),
      full_name = as.character(if ("full_name" %in% names(d)) full_name else NA_character_),
      short_name = as.character(if ("short_name" %in% names(d)) short_name else NA_character_),
      jurisdiction = as.character(if ("jurisdiction" %in% names(d)) jurisdiction else NA_character_),
      url = as.character(if ("url" %in% names(d)) url else NA_character_)
    )
}

# == Context ===================================================================

#' Generate LLM-friendly context for courtlistener.com
#'
#' @return Character string with full function signatures and bodies
cl_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/courtlistener.com.R"
  if (!file.exists(src_file)) {
    cat("# courtlistener.com context - source not found\n")
    return(invisible("# courtlistener.com context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

