# open-notify.org.R - Self-contained open-notify.org client



.ua <- "support@scrapeable.com"

`%||%` <- function(a, b) if (is.null(a)) b else a

.fetch_json <- function(url) {
  tmp <- tempfile(fileext = ".json")
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  jsonlite::fromJSON(tmp, simplifyVector = FALSE)
}


#' Get current ISS position
#'
#' @return tibble with latitude, longitude, timestamp
iss_position <- function() {
  raw <- .fetch_json("http://api.open-notify.org/iss-now.json")
  tibble::tibble(
    latitude = as.numeric(raw$iss_position$latitude),
    longitude = as.numeric(raw$iss_position$longitude),
    timestamp = as.POSIXct(raw$timestamp, origin = "1970-01-01")
  )
}

#' Get astronauts currently in space
#'
#' @return tibble of astronauts with name and craft
iss_astronauts <- function() {
  raw <- .fetch_json("http://api.open-notify.org/astros.json")
  people <- raw$people
  if (length(people) == 0) return(tibble::tibble(name = character(), craft = character()))
  tibble::tibble(
    name = vapply(people, function(x) x$name %||% NA_character_, character(1)),
    craft = vapply(people, function(x) x$craft %||% NA_character_, character(1))
  )
}

#' Summarize astronauts by spacecraft
#'
#' @return tibble: craft, count (number of astronauts on each craft)
iss_craft_summary <- function() {
  schema <- tibble(craft = character(), count = integer())
  raw <- tryCatch(.fetch_json("http://api.open-notify.org/astros.json"), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$people) || length(raw$people) == 0) return(schema)

  crafts <- vapply(raw$people, function(x) x$craft %||% NA_character_, character(1))
  tbl <- table(crafts)
  tibble(craft = names(tbl), count = as.integer(tbl))
}

# == Context ===================================================================

#' Generate LLM-friendly context for open-notify.org
#'
#' @return Character string with full function signatures and bodies
iss_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/open-notify.org.R"
  if (!file.exists(src_file)) {
    cat("# open-notify.org context - source not found\n")
    return(invisible("# open-notify.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

