# berkeleyearth.org.R - Self-contained berkeleyearth.org client

library(httr2)
library(tibble)
library(dplyr)


# berkeleyearth-org.R
# Self-contained Berkeley Earth temperature data client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, dplyr, tibble
# Auth: none required
# Data: tab-separated text with % comment lines


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.berk_s3 <- "https://berkeley-earth-temperature.s3.us-west-1.amazonaws.com/Global"

.fetch <- function(url, ext = ".txt") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.parse_berk_txt <- function(file) {
  lines <- readLines(file, warn = FALSE)
  # Remove comment lines starting with %
  data_lines <- lines[!grepl("^%", lines) & nchar(trimws(lines)) > 0]
  if (length(data_lines) == 0) return(NULL)
  tc <- textConnection(data_lines)
  on.exit(close(tc))
  tryCatch(
    utils::read.table(tc, header = FALSE, stringsAsFactors = FALSE,
                      fill = TRUE, comment.char = "%"),
    error = function(e) NULL
  )
}

# == Schemas ===================================================================

.schema_global_temp <- tibble(
  year = integer(), month = integer(), anomaly = numeric(),
  anomaly_unc = numeric(), annual_anomaly = numeric(),
  annual_anomaly_unc = numeric()
)


# == Global temperature ========================================================

#' Fetch Berkeley Earth global land+ocean temperature data
#'
#' Downloads the complete Land_and_Ocean data from Berkeley Earth.
#' Contains monthly temperature anomalies relative to the 1951-1980 average.
#'
#' @return tibble: year (integer), month (integer), anomaly (numeric),
#'   anomaly_unc (numeric), annual_anomaly (numeric),
#'   annual_anomaly_unc (numeric)
berk_global_temp <- function() {
  url <- paste0(.berk_s3, "/Land_and_Ocean_complete.txt")
  f <- .fetch(url, ext = ".txt")
  df <- .parse_berk_txt(f)
  if (is.null(df) || nrow(df) == 0) return(.schema_global_temp)
  # The file has monthly data with columns:
  # Year, Month, Monthly_Anomaly, Monthly_Unc, Annual_Anomaly, Annual_Unc, ...
  # Number of columns can vary; take first 6
  nc <- min(ncol(df), 6)
  result <- tibble(
    year = as.integer(df[[1]]),
    month = as.integer(df[[2]]),
    anomaly = suppressWarnings(as.numeric(df[[3]])),
    anomaly_unc = if (nc >= 4) suppressWarnings(as.numeric(df[[4]])) else NA_real_,
    annual_anomaly = if (nc >= 5) suppressWarnings(as.numeric(df[[5]])) else NA_real_,
    annual_anomaly_unc = if (nc >= 6) suppressWarnings(as.numeric(df[[6]])) else NA_real_
  )
  result |> filter(!is.na(year), !is.na(month))
}

# == Land-only temperature ====================================================

#' Fetch Berkeley Earth land-only temperature data
#'
#' Downloads the complete Land data from Berkeley Earth.
#' Contains monthly temperature anomalies for land only.
#'
#' @return tibble: year, month, anomaly, anomaly_unc
berk_land_temp <- function() {
  schema <- tibble(year = integer(), month = integer(),
                   anomaly = numeric(), anomaly_unc = numeric())
  url <- paste0(.berk_s3, "/Land_and_Ocean_complete.txt")
  f <- .fetch(url, ext = ".txt")
  df <- .parse_berk_txt(f)
  if (is.null(df) || nrow(df) == 0) return(schema)

  tibble(
    year = as.integer(df[[1]]),
    month = as.integer(df[[2]]),
    anomaly = suppressWarnings(as.numeric(df[[3]])),
    anomaly_unc = if (ncol(df) >= 4) suppressWarnings(as.numeric(df[[4]])) else NA_real_
  ) |> filter(!is.na(year), !is.na(month))
}

# == Context ===================================================================

#' Generate LLM-friendly context for berkeleyearth.org
#'
#' @return Character string with full function signatures and bodies
berkeleyearth_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/berkeleyearth.org.R"
  if (!file.exists(src_file)) {
    cat("# berkeleyearth.org context - source not found\n")
    return(invisible("# berkeleyearth.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

