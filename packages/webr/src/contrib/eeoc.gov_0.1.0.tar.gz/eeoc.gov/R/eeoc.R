#' List available EEOC datasets
#'
#' @return A tibble with columns: dataset, description, format, years, url
#' @export
eeoc_list <- function() {
  tibble::tibble(
    dataset = c("eeo4", rep("eeo1", length(.eeo1_years))),
    description = c(
      "State & Local Government Workforce (EEO-4)",
      paste0("Private Industry Workforce (EEO-1) ", names(.eeo1_years))
    ),
    format = c("CSV", rep("XLSX", length(.eeo1_years))),
    years = c("2005-2021", names(.eeo1_years)),
    url = c(.eeo4_url, unname(.eeo1_years))
  )
}

#' Search EEOC EEO-4 state/local government workforce data
#'
#' @param state Character. Two-letter state abbreviation (optional).
#' @param year Integer. Year to filter (2005-2021).
#' @param sex Character. "Male" or "Female" (optional).
#' @param data_type Character. Race/ethnicity category (optional).
#' @param max_results Integer. Maximum rows (default 1000).
#' @return A tibble of EEO-4 workforce data.
#' @export
eeoc_search <- function(state = NULL, year = NULL, sex = NULL,
                        data_type = NULL, max_results = 1000) {
  tmp <- .eeoc_download(.eeo4_url, ".csv")
  df <- utils::read.csv(tmp, stringsAsFactors = FALSE, check.names = FALSE)
  df <- tibble::as_tibble(df)

  if (!is.null(state))     df <- df |> filter(.data$state == !!state)
  if (!is.null(year))      df <- df |> filter(.data$year == !!as.integer(year))
  if (!is.null(sex))       df <- df |> filter(.data$sex == !!sex)
  if (!is.null(data_type)) df <- df |> filter(.data$data_type == !!data_type)

  df |> head(max_results)
}

#' Get EEOC EEO-4 summary by state and year
#'
#' @param year Integer. Year (2005-2021). Default 2021.
#' @return A tibble summarized by state and data_type.
#' @export
eeoc_state_summary <- function(year = 2021) {
  tmp <- .eeoc_download(.eeo4_url, ".csv")
  df <- utils::read.csv(tmp, stringsAsFactors = FALSE, check.names = FALSE)
  df <- tibble::as_tibble(df)

  df |>
    filter(.data$year == !!as.integer(year)) |>
    filter(.data$state != "") |>
    group_by(.data$state, .data$data_type) |>
    summarise(total = sum(.data$value, na.rm = TRUE), .groups = "drop") |>
    arrange(.data$state, .data$data_type)
}

#' Get EEOC EEO-4 data by government function
#'
#' @param year Integer. Year (2005-2021). Default 2021.
#' @param state Character. Optional state filter.
#' @return A tibble summarized by function code and demographic.
#' @export
eeoc_by_function <- function(year = 2021, state = NULL) {
  tmp <- .eeoc_download(.eeo4_url, ".csv")
  df <- utils::read.csv(tmp, stringsAsFactors = FALSE, check.names = FALSE)
  df <- tibble::as_tibble(df)

  df <- df |> filter(.data$year == !!as.integer(year))
  if (!is.null(state)) df <- df |> filter(.data$state == !!state)

  df |>
    filter(!is.na(.data$functcd)) |>
    group_by(.data$functcd, .data$data_type) |>
    summarise(total = sum(.data$value, na.rm = TRUE), .groups = "drop") |>
    arrange(.data$functcd, .data$data_type)
}

#' Get available years in EEO-4 data
#'
#' @return Integer vector of available years.
#' @export
eeoc_years <- function() {
  tmp <- .eeoc_download(.eeo4_url, ".csv")
  df <- utils::read.csv(tmp, stringsAsFactors = FALSE, check.names = FALSE,
                        nrows = 100000)
  sort(unique(df$year))
}

#' Print eeoc.gov client context
#'
#' @return Character string of function signatures (invisibly).
#' @export
eeoc_context <- function() {
  src <- system.file("source", "eeoc.R", package = "eeoc.gov")
  if (src == "") {
    f <- sys.frame(sys.nframe())$ofile %||%
      attr(body(eeoc_context), "srcfile")$filename %||% ""
    if (nzchar(f)) src <- f
  }
  .build_context("eeoc.gov", src_file = if (nzchar(src)) src else NULL,
                 header_lines = c(
                   "# eeoc.gov -- EEOC Workforce Data R client",
                   "# Data: EEO-4 (state/local govt) CSV, EEO-1 (private) XLSX",
                   "# Auth: none"
                 ))
}
