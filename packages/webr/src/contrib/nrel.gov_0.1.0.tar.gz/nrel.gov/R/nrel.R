# == Alt Fuel Stations =========================================================

#' Search alternative fuel stations
#'
#' @param state Two-letter state code (optional)
#' @param fuel_type Fuel type: ELEC, CNG, LPG, BD, E85, HY, LNG, RD (optional)
#' @param city City name (optional)
#' @param zip ZIP code (optional)
#' @param status Station status: E, P, T (optional)
#' @param limit Max results (default 100)
#' @return tibble of fuel station records
#' @export
nrel_stations <- function(state = NULL, fuel_type = NULL, city = NULL,
                          zip = NULL, status = NULL, limit = 100) {
  url <- sprintf("%s/alt-fuel-stations/v1.json?api_key=%s&limit=%d",
                 .nrel_base, .nrel_key(), as.integer(limit))
  if (!is.null(state))     url <- paste0(url, "&state=", state)
  if (!is.null(fuel_type)) url <- paste0(url, "&fuel_type=", fuel_type)
  if (!is.null(city))      url <- paste0(url, "&city=", utils::URLencode(city))
  if (!is.null(zip))       url <- paste0(url, "&zip=", zip)
  if (!is.null(status))    url <- paste0(url, "&status_code=", status)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$fuel_stations)) return(.schema_stations)
  fs <- raw$fuel_stations
  if (!is.data.frame(fs) || nrow(fs) == 0) return(.schema_stations)
  as_tibble(fs) |>
    select(any_of(c("id", "station_name", "street_address", "city", "state",
                     "zip", "fuel_type_code", "status_code", "latitude",
                     "longitude", "access_code", "owner_type_code",
                     "open_date", "ev_network", "ev_connector_types",
                     "ev_level2_evse_num", "ev_dc_fast_num")))
}

#' Get details for a specific fuel station
#'
#' @param station_id Numeric station ID
#' @return tibble with station details (1 row)
#' @export
nrel_station <- function(station_id) {
  url <- sprintf("%s/alt-fuel-stations/v1/%d.json?api_key=%s",
                 .nrel_base, as.integer(station_id), .nrel_key())
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$alt_fuel_station)) return(.schema_stations)
  s <- raw$alt_fuel_station
  flat <- lapply(s, function(v) {
    if (is.list(v) || length(v) > 1) paste(unlist(v), collapse = ", ")
    else as.character(v %||% NA)
  })
  as_tibble(flat)
}

# == Solar Resource ============================================================

#' Get solar resource data for a location
#'
#' @param lat Latitude
#' @param lon Longitude
#' @return tibble: parameter, annual, jan-dec monthly values
#' @export
nrel_solar <- function(lat, lon) {
  url <- sprintf("%s/solar/solar_resource/v1.json?api_key=%s&lat=%f&lon=%f",
                 .nrel_base, .nrel_key(), lat, lon)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$outputs)) return(.schema_solar)
  out <- raw$outputs
  params <- names(out)
  rows <- lapply(params, function(p) {
    v <- out[[p]]
    if (!is.list(v)) return(NULL)
    monthly <- v$monthly
    if (is.null(monthly)) return(NULL)
    tibble(
      parameter = p,
      annual = as.numeric(v$annual %||% NA),
      jan = as.numeric(monthly$jan %||% NA),
      feb = as.numeric(monthly$feb %||% NA),
      mar = as.numeric(monthly$mar %||% NA),
      apr = as.numeric(monthly$apr %||% NA),
      may = as.numeric(monthly$may %||% NA),
      jun = as.numeric(monthly$jun %||% NA),
      jul = as.numeric(monthly$jul %||% NA),
      aug = as.numeric(monthly$aug %||% NA),
      sep = as.numeric(monthly$sep %||% NA),
      oct = as.numeric(monthly$oct %||% NA),
      nov = as.numeric(monthly$nov %||% NA),
      dec = as.numeric(monthly$dec %||% NA)
    )
  })
  bind_rows(rows[!vapply(rows, is.null, logical(1))])
}

# == Utility Rates =============================================================

#' Get utility rates for a location
#'
#' @param lat Latitude
#' @param lon Longitude
#' @return tibble: utility_name, residential, commercial, industrial ($/kWh)
#' @export
nrel_utility_rates <- function(lat, lon) {
  url <- sprintf("%s/utility_rates/v3.json?api_key=%s&lat=%f&lon=%f",
                 .nrel_base, .nrel_key(), lat, lon)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$outputs)) return(tibble())
  o <- raw$outputs
  tibble(
    utility_name = as.character(o$utility_name %||% NA),
    residential  = as.numeric(o$residential %||% NA),
    commercial   = as.numeric(o$commercial %||% NA),
    industrial   = as.numeric(o$industrial %||% NA)
  )
}

# == Context ===================================================================

#' Generate LLM-friendly context for nrel.gov
#'
#' @return Character string (invisibly), also printed
#' @export
nrel_context <- function() {
  .build_context("nrel.gov")
}
