# nycgovparks.org
# Self-contained NYC Parks client.
# All public functions return tibbles.
#
# Dependencies: httr2, jsonlite, dplyr, tibble


# == Directory Facilities ======================================================

#' List available NYC Parks facility directories
#'
#' Returns the names of all known directory feeds that can be
#' passed to nycparks_facilities().
#'
#' @return character vector of directory names
#' @export
nycparks_list <- function() {
  names(.nycparks_dirs)
}


#' Fetch a NYC Parks facility directory
#'
#' Retrieves a full directory of a specific facility type (pools, dog runs,
#' playgrounds, etc.) from the NYC Parks JSON feeds.
#'
#' @param directory Directory name (see nycparks_list() for options).
#'   Examples: "pools_indoor", "dog_runs", "playgrounds", "beaches"
#' @param borough Optional filter: "Bronx", "Brooklyn", "Manhattan",
#'   "Queens", "Staten_Island" (or partial match)
#' @return tibble with facility details (columns vary by directory type)
#' @export
nycparks_facilities <- function(directory, borough = NULL) {
  path <- .nycparks_dirs[[directory]]
  if (is.null(path)) {
    stop(sprintf("Unknown directory '%s'. Use nycparks_list() to see options.", directory))
  }
  raw <- .nycparks_fetch(path)
  if (length(raw) == 0) return(tibble())
  df <- as_tibble(raw)
  df <- .type_cols(df)

  if (!is.null(borough)) {
    for (bcol in c("borough", "Borough", "Location")) {
      if (bcol %in% names(df)) {
        df <- df |> filter(grepl(borough, .data[[bcol]], ignore.case = TRUE))
        break
      }
    }
  }
  df
}


#' Search NYC Parks facilities across all directories
#'
#' Searches facility names across all or selected directory types.
#'
#' @param query Text to search for in Name/name fields (case-insensitive)
#' @param directories Character vector of directory names to search
#'   (default: all). See nycparks_list().
#' @return tibble with matching facilities and a directory_type column
#' @export
nycparks_search <- function(query, directories = NULL) {
  if (is.null(directories)) directories <- names(.nycparks_dirs)
  all_results <- list()

  for (d in directories) {
    tryCatch({
      df <- nycparks_facilities(d)
      if (nrow(df) == 0) next

      name_col <- intersect(names(df), c("Name", "name", "title"))[1]
      if (is.na(name_col)) next

      matches <- df |> filter(grepl(query, .data[[name_col]], ignore.case = TRUE))
      if (nrow(matches) > 0) {
        matches$directory_type <- d
        all_results[[length(all_results) + 1]] <- matches
      }
    }, error = function(e) NULL)
  }

  if (length(all_results) == 0) return(tibble())
  bind_rows(all_results)
}


# == Events ====================================================================

#' Get upcoming NYC Parks events (next 14 days)
#'
#' Fetches public events from the NYC Parks events feed.
#'
#' @param category Optional category filter (e.g. "Fitness", "Dance",
#'   "Nature", "Volunteer"). Partial match.
#' @param borough Optional borough filter on park names/location
#' @return tibble: title, description, startdate, enddate, starttime, endtime,
#'   parknames, location, categories, link, registration_url, coordinates
#' @export
nycparks_events <- function(category = NULL, borough = NULL) {
  raw <- .nycparks_fetch("xml/events_300_rss.json")
  if (length(raw) == 0) return(tibble())
  df <- as_tibble(raw)

  if ("startdate" %in% names(df)) df$startdate <- as.Date(df$startdate)
  if ("enddate" %in% names(df)) df$enddate <- as.Date(df$enddate)

  if (!is.null(category)) {
    df <- df |> filter(grepl(category, categories, ignore.case = TRUE))
  }
  if (!is.null(borough)) {
    df <- df |> filter(grepl(borough, parknames, ignore.case = TRUE) |
                       grepl(borough, location, ignore.case = TRUE))
  }
  df
}


# == Capital Projects ==========================================================

#' Fetch NYC Parks capital project tracker
#'
#' Returns all capital construction and renovation projects managed by
#' NYC Parks with timelines, phases, and funding info.
#'
#' @param phase Optional filter on current phase (e.g. "Construction",
#'   "Design", "Procurement", "Scope", "Completed")
#' @param borough Optional borough filter
#' @return tibble: TrackerID, Title, Summary, CurrentPhase,
#'   DesignPercentComplete, ConstructionPercentComplete, TotalFunding,
#'   dates, ProjectLiaison, Locations, Boroughs, ...
#' @export
nycparks_projects <- function(phase = NULL, borough = NULL) {
  raw <- .nycparks_fetch("bigapps/DPR_CapitalProjectTracker_001.json")
  if (length(raw) == 0) return(tibble())
  df <- as_tibble(raw)
  df <- .type_cols(df)

  if (!is.null(phase)) {
    df <- df |> filter(grepl(phase, CurrentPhase, ignore.case = TRUE))
  }
  if (!is.null(borough)) {
    df <- df |> filter(grepl(borough, Boroughs, ignore.case = TRUE))
  }
  df
}


# == Historical Signs ==========================================================

#' Fetch NYC Parks historical signs
#'
#' Returns the full text of historical signs installed in NYC Parks
#' properties, including park history and naming context.
#'
#' @param borough Optional filter: "Bronx", "Brooklyn", "Manhattan",
#'   "Queens", "Staten_Island"
#' @param query Optional text search in sign name or content
#' @return tibble: name, location, borough, content, propID
#' @export
nycparks_history <- function(borough = NULL, query = NULL) {
  raw <- .nycparks_fetch("bigapps/DPR_HistoricalSigns_001.json")
  if (length(raw) == 0) return(tibble())
  df <- as_tibble(raw)

  if ("content" %in% names(df)) {
    df$content <- gsub("<[^>]+>", "", df$content)
    df$content <- gsub("&[a-z]+;", " ", df$content)
    df$content <- gsub("\\s+", " ", trimws(df$content))
  }

  if (!is.null(borough)) {
    df <- df |> filter(grepl(borough, .data[["borough"]], ignore.case = TRUE))
  }
  if (!is.null(query)) {
    df <- df |> filter(grepl(query, name, ignore.case = TRUE) |
                       grepl(query, content, ignore.case = TRUE))
  }
  df
}


# == Press Releases ============================================================

#' Fetch NYC Parks press releases
#'
#' @return tibble with press release data
#' @export
nycparks_press <- function() {
  raw <- .nycparks_fetch("bigapps/DPR_PressReleases_001.json")
  if (length(raw) == 0) return(tibble())
  df <- as_tibble(raw)
  .type_cols(df)
}


# == Public Art ================================================================

#' Fetch NYC Parks temporary public art installations
#'
#' Directory of temporary art exhibitions and installations in NYC Parks
#' properties since 2000.
#'
#' @return tibble with art installation details
#' @export
nycparks_art <- function() {
  raw <- .nycparks_fetch("bigapps/DPR_PublicArt_001.json")
  if (length(raw) == 0) return(tibble())
  df <- as_tibble(raw)
  .type_cols(df)
}


# == Park Closures =============================================================

#' Fetch current NYC Parks closure notifications
#'
#' @return tibble with park/facility closure details
#' @export
nycparks_closures <- function() {
  raw <- .nycparks_fetch("bigapps/DPR_ParkClosure_001.json")
  if (length(raw) == 0) return(tibble())
  df <- as_tibble(raw)
  .type_cols(df)
}


# == Context ===================================================================

#' Generate LLM-friendly context for nycgovparks.org
#'
#' @return Character string with full function signatures
#' @export
nycparks_context <- function() {
  .build_context("nycgovparks.org", header_lines = c(
    "# nycgovparks.org — NYC Parks Department Facilities, Events & Projects",
    "# 24 facility directories, events, capital projects, historical signs, art, closures"
  ))
}
