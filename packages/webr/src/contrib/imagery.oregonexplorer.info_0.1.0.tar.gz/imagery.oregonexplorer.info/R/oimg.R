# == Schemas ===================================================================

.schema_services <- tibble::tibble(
  folder = character(),
  service_name = character(),
  service_type = character(),
  url = character()
)

.schema_metadata <- tibble::tibble(
  name = character(),
  description = character(),
  band_count = integer(),
  pixel_type = character(),
  pixel_size_x = numeric(),
  pixel_size_y = numeric(),
  format = character(),
  extent_xmin = numeric(),
  extent_ymin = numeric(),
  extent_xmax = numeric(),
  extent_ymax = numeric(),
  spatial_ref_wkid = integer(),
  copyright = character()
)

# == Public functions ==========================================================

#' List all Oregon imagery service folders
#'
#' @return tibble: folder (character)
#' @export
oimg_folders <- function() {
  url <- sprintf("%s?f=json", .oimg_base)
  raw <- .fetch_json(url)
  folders <- raw$folders %||% character()
  tibble::tibble(folder = as.character(folders))
}

#' List all imagery services
#'
#' @param folder Optional folder name to filter (e.g., "OSIP_2022").
#' @return tibble: folder, service_name, service_type, url
#' @export
oimg_services <- function(folder = NULL) {
  if (is.null(folder)) {
    folders <- oimg_folders()$folder
  } else {
    folders <- folder
  }

  all_rows <- lapply(folders, function(f) {
    url <- sprintf("%s/%s?f=json", .oimg_base, f)
    tryCatch({
      raw <- .fetch_json(url)
      svcs <- raw$services
      if (is.null(svcs) || nrow(svcs) == 0) return(NULL)
      tibble::tibble(
        folder = f,
        service_name = as.character(svcs$name),
        service_type = as.character(svcs$type),
        url = sprintf("%s/%s/ImageServer", .oimg_base,
                      gsub(" ", "%20", svcs$name))
      )
    }, error = function(e) NULL)
  })
  result <- bind_rows(all_rows)
  if (nrow(result) == 0) return(.schema_services)
  result
}

#' Get metadata for a specific imagery service
#'
#' @param service_name Full service name (e.g., "OSIP_2022/OSIP_2022_WM")
#' @return tibble (1 row): name, description, band_count, pixel_type,
#'   pixel_size_x, pixel_size_y, format, extent columns, spatial_ref_wkid, copyright
#' @export
oimg_metadata <- function(service_name) {
  url <- sprintf("%s/%s/ImageServer?f=json", .oimg_base, service_name)
  raw <- .fetch_json(url)
  ext <- raw$extent %||% list()
  sr <- ext$spatialReference %||% list()

  tibble::tibble(
    name = as.character(raw$name %||% NA),
    description = as.character(raw$description %||% NA),
    band_count = as.integer(raw$bandCount %||% NA),
    pixel_type = as.character(raw$pixelType %||% NA),
    pixel_size_x = as.numeric(raw$pixelSizeX %||% NA),
    pixel_size_y = as.numeric(raw$pixelSizeY %||% NA),
    format = as.character(raw$datasetFormat %||% NA),
    extent_xmin = as.numeric(ext$xmin %||% NA),
    extent_ymin = as.numeric(ext$ymin %||% NA),
    extent_xmax = as.numeric(ext$xmax %||% NA),
    extent_ymax = as.numeric(ext$ymax %||% NA),
    spatial_ref_wkid = as.integer(sr$wkid %||% NA),
    copyright = as.character(raw$copyrightText %||% NA)
  )
}

#' Search Oregon imagery services by keyword
#'
#' @param query Search term matched against folder and service names
#' @return tibble: folder, service_name, service_type, url
#' @export
oimg_search <- function(query) {
  oimg_services() |>
    filter(grepl(query, service_name, ignore.case = TRUE) |
           grepl(query, folder, ignore.case = TRUE))
}

#' Show context for the imagery.oregonexplorer.info client
#'
#' @return Invisible string of context
#' @export
oimg_context <- function() {
  .build_context(
    "imagery.oregonexplorer.info",
    header_lines = c(
      "# imagery.oregonexplorer.info - Oregon Imagery Explorer",
      "# ArcGIS ImageServer metadata for Oregon aerial imagery"
    )
  )
}
