# open-meteo.com.R - Self-contained open-meteo.com client

library(httr2)
library(jsonlite)
library(tibble)
library(dplyr)

# open-meteo-com.R
# Self-contained Open-Meteo weather API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required
# API: https://api.open-meteo.com/v1


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.meteo_base <- "https://api.open-meteo.com/v1"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = TRUE)

`%||%` <- function(a, b) if (is.null(a) || length(a) == 0) b else a

# == Schemas ===================================================================

.schema_hourly <- tibble(
  time = as.POSIXct(character()), temperature_2m = numeric(),
  relative_humidity_2m = numeric(), wind_speed_10m = numeric()
)

.schema_daily <- tibble(
  date = as.Date(character()), temperature_2m_max = numeric(),
  temperature_2m_min = numeric(), precipitation_sum = numeric()
)

# == Forecast ==================================================================


#' Get hourly weather forecast
#'
#' Returns hourly weather data for a location. Free, no API key needed.
#' Forecasts up to 16 days ahead, historical data back to 1940.
#'
#' @param latitude Latitude (e.g. 40.71 for New York)
#' @param longitude Longitude (e.g. -74.01 for New York)
#' @param hourly Variables to include. Default: "temperature_2m,relative_humidity_2m,wind_speed_10m".
#'   Options: temperature_2m, apparent_temperature, precipitation, rain, snowfall,
#'   cloud_cover, wind_speed_10m, wind_direction_10m, pressure_msl, etc.
#' @param forecast_days Days ahead (default 7, max 16)
#' @param start_date Start date for historical (YYYY-MM-DD)
#' @param end_date End date for historical
#' @param timezone Timezone (default "auto")
#' @return tibble with time (POSIXct) and requested weather variables
meteo_hourly <- function(latitude, longitude,
                         hourly = "temperature_2m,relative_humidity_2m,wind_speed_10m",
                         forecast_days = 7, start_date = NULL, end_date = NULL,
                         timezone = "auto") {
  url <- sprintf("%s/forecast?latitude=%s&longitude=%s&hourly=%s&forecast_days=%d&timezone=%s",
                 .meteo_base, latitude, longitude, hourly, forecast_days, timezone)
  if (!is.null(start_date)) url <- paste0(url, "&start_date=", start_date)
  if (!is.null(end_date))   url <- paste0(url, "&end_date=", end_date)

  raw <- tryCatch(.fetch_json(url), error = function(e) {
    warning("Open-Meteo API error: ", e$message); NULL
  })
  if (is.null(raw) || is.null(raw$hourly)) return(.schema_hourly)

  h <- raw$hourly
  result <- tibble(time = as.POSIXct(h$time, format = "%Y-%m-%dT%H:%M", tz = raw$timezone %||% "UTC"))

  # Add all returned variables
  vars <- setdiff(names(h), "time")
  for (v in vars) {
    result[[v]] <- as.numeric(h[[v]])
  }
  result
}


#' Get daily weather forecast/history
#'
#' @param latitude Latitude
#' @param longitude Longitude
#' @param daily Variables. Default: "temperature_2m_max,temperature_2m_min,precipitation_sum".
#'   Options: temperature_2m_max/min, apparent_temperature_max/min, precipitation_sum,
#'   rain_sum, snowfall_sum, wind_speed_10m_max, sunrise, sunset, etc.
#' @param forecast_days Days ahead (default 7)
#' @param start_date Start date for historical
#' @param end_date End date for historical
#' @param timezone Timezone (default "auto")
#' @return tibble with date (Date) and requested variables
meteo_daily <- function(latitude, longitude,
                        daily = "temperature_2m_max,temperature_2m_min,precipitation_sum",
                        forecast_days = 7, start_date = NULL, end_date = NULL,
                        timezone = "auto") {
  url <- sprintf("%s/forecast?latitude=%s&longitude=%s&daily=%s&forecast_days=%d&timezone=%s",
                 .meteo_base, latitude, longitude, daily, forecast_days, timezone)
  if (!is.null(start_date)) url <- paste0(url, "&start_date=", start_date)
  if (!is.null(end_date))   url <- paste0(url, "&end_date=", end_date)

  raw <- tryCatch(.fetch_json(url), error = function(e) {
    warning("Open-Meteo API error: ", e$message); NULL
  })
  if (is.null(raw) || is.null(raw$daily)) return(.schema_daily)

  d <- raw$daily
  result <- tibble(date = as.Date(d$time))
  vars <- setdiff(names(d), "time")
  for (v in vars) {
    result[[v]] <- as.numeric(d[[v]])
  }
  result
}


#' Get historical weather archive data
#'
#' Access historical weather data from 1940 to present.
#'
#' @param latitude Latitude
#' @param longitude Longitude
#' @param start_date Start date (required, YYYY-MM-DD)
#' @param end_date End date (required, YYYY-MM-DD)
#' @param daily Variables (same options as meteo_daily)
#' @return tibble with date and requested variables
meteo_historical <- function(latitude, longitude, start_date, end_date,
                             daily = "temperature_2m_max,temperature_2m_min,precipitation_sum") {
  url <- sprintf(
    "https://archive-api.open-meteo.com/v1/archive?latitude=%s&longitude=%s&start_date=%s&end_date=%s&daily=%s&timezone=auto",
    latitude, longitude, start_date, end_date, daily
  )

  raw <- tryCatch(.fetch_json(url), error = function(e) {
    warning("Open-Meteo Archive API error: ", e$message); NULL
  })
  if (is.null(raw) || is.null(raw$daily)) return(.schema_daily)

  d <- raw$daily
  result <- tibble(date = as.Date(d$time))
  vars <- setdiff(names(d), "time")
  for (v in vars) {
    result[[v]] <- as.numeric(d[[v]])
  }
  result
}


#' Geocode a location name to coordinates
#'
#' Converts a place name to latitude/longitude using Open-Meteo's geocoding API.
#'
#' @param name Place name (e.g., "New York", "Tokyo", "London")
#' @param count Number of results (default 5)
#' @return tibble: name, latitude, longitude, country, timezone, elevation, population
meteo_geocode <- function(name, count = 5) {
  schema <- tibble(name = character(), latitude = numeric(), longitude = numeric(),
                   country = character(), timezone = character(),
                   elevation = numeric(), population = integer())
  url <- sprintf("https://geocoding-api.open-meteo.com/v1/search?name=%s&count=%d&language=en&format=json",
                 utils::URLencode(name, reserved = TRUE), as.integer(count))
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$results)) return(schema)

  r <- raw$results
  if (is.data.frame(r)) {
    nms <- names(r)
    as_tibble(r) |>
      transmute(
        name = as.character(if ("name" %in% nms) name else NA_character_),
        latitude = as.numeric(latitude),
        longitude = as.numeric(longitude),
        country = as.character(if ("country" %in% nms) country else NA_character_),
        timezone = as.character(if ("timezone" %in% nms) timezone else NA_character_),
        elevation = as.numeric(if ("elevation" %in% nms) elevation else NA_real_),
        population = as.integer(if ("population" %in% nms) population else NA_integer_)
      )
  } else {
    schema
  }
}

#' Compare weather across multiple locations
#'
#' Fetches daily forecasts for multiple lat/lon pairs and returns combined data.
#'
#' @param locations Named list of c(lat, lon) pairs, e.g.
#'   list(NYC = c(40.71, -74.01), LA = c(34.05, -118.24))
#' @param daily Variables (default temperature and precipitation)
#' @param forecast_days Days ahead (default 7)
#' @return tibble: location, date, temperature_2m_max, temperature_2m_min, precipitation_sum
meteo_compare <- function(locations,
                          daily = "temperature_2m_max,temperature_2m_min,precipitation_sum",
                          forecast_days = 7) {
  rows <- lapply(names(locations), function(loc_name) {
    coords <- locations[[loc_name]]
    tryCatch({
      result <- meteo_daily(coords[1], coords[2], daily = daily,
                           forecast_days = forecast_days)
      if (nrow(result) > 0) {
        result$location <- loc_name
        result
      } else NULL
    }, error = function(e) NULL)
  })
  rows <- rows[!vapply(rows, is.null, logical(1))]
  if (length(rows) == 0) return(tibble(location = character(), date = as.Date(character())))
  bind_rows(rows) |> select(location, everything())
}

# == Context ===================================================================

#' Generate LLM-friendly context for open-meteo.com
#'
#' @return Character string with full function signatures and bodies
meteo_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/open-meteo.com.R"
  if (!file.exists(src_file)) {
    cat("# open-meteo.com context - source not found\n")
    return(invisible("# open-meteo.com context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

