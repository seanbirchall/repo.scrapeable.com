# api-web.nhle.com.R - Self-contained api-web.nhle.com client




.ua <- "support@scrapeable.com"

.fetch_json <- function(url) {
  tmp <- tempfile(fileext = ".json")
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  jsonlite::fromJSON(tmp, simplifyVector = FALSE)
}


.base <- "https://api-web.nhle.com/v1"

#' Get NHL standings
#' @param date Date in YYYY-MM-DD format (default today)
#' @return tibble of team standings
nhl_standings <- function(date = format(Sys.Date())) {
  url <- sprintf("%s/standings/%s", .base, date)
  raw <- .fetch_json(url)
  standings <- raw$standings
  if (length(standings) == 0) return(tibble::tibble(team = character(), wins = integer()))
  tibble::tibble(
    team = vapply(standings, function(x) x$teamName$default %||% NA_character_, character(1)),
    abbrev = vapply(standings, function(x) x$teamAbbrev$default %||% NA_character_, character(1)),
    wins = vapply(standings, function(x) x$wins %||% NA_integer_, integer(1)),
    losses = vapply(standings, function(x) x$losses %||% NA_integer_, integer(1)),
    ot_losses = vapply(standings, function(x) x$otLosses %||% NA_integer_, integer(1)),
    points = vapply(standings, function(x) x$points %||% NA_integer_, integer(1)),
    goals_for = vapply(standings, function(x) x$goalFor %||% NA_integer_, integer(1)),
    goals_against = vapply(standings, function(x) x$goalAgainst %||% NA_integer_, integer(1))
  )
}

#' Get NHL schedule
#' @param date Date in YYYY-MM-DD format
#' @return tibble of scheduled games
nhl_schedule <- function(date = format(Sys.Date())) {
  url <- sprintf("%s/schedule/%s", .base, date)
  raw <- .fetch_json(url)
  days <- raw$gameWeek
  if (length(days) == 0) return(tibble::tibble(game_id = integer(), home_team = character(), away_team = character()))
  rows <- list()
  for (day in days) {
    for (game in day$games) {
      rows[[length(rows) + 1]] <- tibble::tibble(
        game_id = game$id %||% NA_integer_,
        date = day$date %||% NA_character_,
        home_team = game$homeTeam$abbrev %||% NA_character_,
        away_team = game$awayTeam$abbrev %||% NA_character_,
        game_type = as.integer(game$gameType %||% NA)
      )
    }
  }
  if (length(rows) == 0) return(tibble::tibble(game_id = integer(), home_team = character(), away_team = character()))
  dplyr::bind_rows(rows)
}

# == Context ===================================================================

#' Generate LLM-friendly context for api-web.nhle.com
#'
#' @return Character string with full function signatures and bodies
nhl_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/api-web.nhle.com.R"
  if (!file.exists(src_file)) {
    cat("# api-web.nhle.com context - source not found\n")
    return(invisible("# api-web.nhle.com context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

