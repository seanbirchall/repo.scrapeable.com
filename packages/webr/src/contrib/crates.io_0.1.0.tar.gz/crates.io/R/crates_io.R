# crates.io.R - Self-contained crates.io client



# crates-io.R
# Self-contained crates.io (Rust package registry) API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required (User-Agent header required)


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.crates_base <- "https://crates.io/api/v1"

`%||%` <- function(a, b) if (is.null(a)) b else a

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))

# == Schemas ===================================================================

.schema_search <- tibble(
  name = character(), description = character(), max_version = character(),
  downloads = integer(), created_at = as.POSIXct(character()),
  updated_at = as.POSIXct(character()), homepage = character(),
  repository = character(), categories = character()
)

.schema_crate <- tibble(
  name = character(), description = character(), max_version = character(),
  downloads = integer(), created_at = as.POSIXct(character()),
  updated_at = as.POSIXct(character()), homepage = character(),
  repository = character(), license = character(),
  max_stable_version = character()
)


# == Search ====================================================================

#' Search crates.io for Rust crates
#'
#' @param query Search query string (e.g. "serde", "async runtime")
#' @param per_page Number of results per page (default 20, max 100)
#' @return tibble: name, description, max_version, downloads, created_at,
#'   updated_at, homepage, repository, categories
crates_search <- function(query, per_page = 20) {
  url <- sprintf("%s/crates?q=%s&per_page=%d",
                 .crates_base, utils::URLencode(query), as.integer(per_page))
  raw <- .fetch_json(url)
  crates <- raw$crates
  if (is.null(crates) || nrow(crates) == 0) return(.schema_search)

  as_tibble(crates) |>
    transmute(
      name        = as.character(name),
      description = as.character(description %||% NA_character_),
      max_version = as.character(max_version %||% NA_character_),
      downloads   = as.integer(downloads %||% NA_integer_),
      created_at  = as.POSIXct(created_at, format = "%Y-%m-%dT%H:%M:%OS"),
      updated_at  = as.POSIXct(updated_at, format = "%Y-%m-%dT%H:%M:%OS"),
      homepage    = as.character(homepage %||% NA_character_),
      repository  = as.character(repository %||% NA_character_),
      categories  = as.character(NA)
    )
}

# == Crate detail ==============================================================

#' Get crate details from crates.io
#'
#' @param name Crate name (e.g. "serde", "tokio", "rand")
#' @return tibble: name, description, max_version, downloads, created_at,
#'   updated_at, homepage, repository, license, max_stable_version
crates_crate <- function(name) {
  url <- sprintf("%s/crates/%s", .crates_base, utils::URLencode(name))
  raw <- tryCatch(.fetch_json(url), error = function(e) {
    message("crates.io fetch failed: ", e$message)
    return(NULL)
  })
  if (is.null(raw)) return(.schema_crate)

  cr <- raw$crate
  tibble(
    name               = as.character(cr$name %||% NA_character_),
    description        = as.character(cr$description %||% NA_character_),
    max_version        = as.character(cr$max_version %||% NA_character_),
    downloads          = as.integer(cr$downloads %||% NA_integer_),
    created_at         = as.POSIXct(cr$created_at %||% NA_character_, format = "%Y-%m-%dT%H:%M:%OS"),
    updated_at         = as.POSIXct(cr$updated_at %||% NA_character_, format = "%Y-%m-%dT%H:%M:%OS"),
    homepage           = as.character(cr$homepage %||% NA_character_),
    repository         = as.character(cr$repository %||% NA_character_),
    license            = as.character(cr$license %||% NA_character_),
    max_stable_version = as.character(cr$max_stable_version %||% NA_character_)
  )
}

#' List all published versions of a crate
#'
#' @param name Crate name (e.g. "serde", "tokio")
#' @return tibble: crate, version, downloads, created_at, yanked, license
crates_versions <- function(name) {
  url <- sprintf("%s/crates/%s/versions", .crates_base, utils::URLencode(name))
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(tibble(crate = character(), version = character(),
                                   downloads = integer(), created_at = as.POSIXct(character())))

  vers <- raw$versions
  if (is.null(vers) || nrow(vers) == 0) return(tibble(crate = character(), version = character(),
                                                        downloads = integer()))

  as_tibble(vers) |>
    transmute(
      crate = as.character(name),
      version = as.character(num),
      downloads = as.integer(downloads %||% NA_integer_),
      created_at = as.POSIXct(created_at, format = "%Y-%m-%dT%H:%M:%OS"),
      yanked = as.logical(yanked %||% NA),
      license = as.character(license %||% NA_character_)
    )
}

#' Get download statistics for a crate
#'
#' @param name Crate name
#' @return tibble: date, downloads (daily download counts for last 90 days)
crates_downloads <- function(name) {
  url <- sprintf("%s/crates/%s/downloads", .crates_base, utils::URLencode(name))
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(tibble(date = as.Date(character()), downloads = integer()))

  dl <- raw$version_downloads
  if (is.null(dl) || nrow(dl) == 0) return(tibble(date = as.Date(character()), downloads = integer()))

  as_tibble(dl) |>
    group_by(date = as.Date(date)) |>
    summarise(downloads = sum(as.integer(downloads), na.rm = TRUE), .groups = "drop") |>
    arrange(date)
}

#' Get reverse dependencies (crates that depend on this one)
#'
#' @param name Crate name
#' @param per_page Number of results (default 20)
#' @return tibble: name, downloads, description
crates_reverse_deps <- function(name, per_page = 20) {
  url <- sprintf("%s/crates/%s/reverse_dependencies?per_page=%d",
                 .crates_base, utils::URLencode(name), as.integer(per_page))
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(tibble(name = character(), downloads = integer(), description = character()))

  deps <- raw$versions
  if (is.null(deps) || nrow(deps) == 0) return(tibble(name = character(), downloads = integer()))

  # deps has crate_id but we need more details from the crates list
  crate_ids <- unique(deps$crate_id)
  crates_info <- raw$crates
  if (!is.null(crates_info) && nrow(crates_info) > 0) {
    tibble(
      name = as.character(crates_info$name %||% crates_info$id),
      downloads = as.integer(crates_info$downloads %||% NA_integer_),
      description = as.character(crates_info$description %||% NA_character_)
    )
  } else {
    tibble(name = as.character(crate_ids), downloads = NA_integer_, description = NA_character_)
  }
}

# == Context ===================================================================

#' Generate LLM-friendly context for crates.io
#'
#' @return Character string with full function signatures and bodies
crates_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/crates.io.R"
  if (!file.exists(src_file)) {
    cat("# crates.io context - source not found\n")
    return(invisible("# crates.io context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

