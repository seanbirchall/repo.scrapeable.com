# == Public functions ==========================================================

#' List recent CPSC recalls
#'
#' @param start_date Start date (YYYY-MM-DD). Defaults to 90 days ago.
#' @param end_date End date (YYYY-MM-DD). Defaults to today.
#' @param limit Maximum rows to return (default 100).
#' @return tibble of recalls
#' @export
cpsc_list <- function(start_date = NULL, end_date = NULL, limit = 100) {
  if (is.null(start_date)) start_date <- Sys.Date() - 90
  if (is.null(end_date)) end_date <- Sys.Date()
  url <- .cpsc_recall_url(start_date = start_date, end_date = end_date)
  raw <- .fetch_json(url)
  result <- .parse_recalls(raw)
  head(result, limit)
}

#' Search CPSC recalls by keyword
#'
#' @param query Search term matched against recall titles.
#' @param start_date Optional start date (YYYY-MM-DD).
#' @param end_date Optional end date (YYYY-MM-DD).
#' @param limit Maximum rows to return (default 100).
#' @return tibble of matching recalls
#' @export
cpsc_search <- function(query, start_date = NULL, end_date = NULL, limit = 100) {
  if (is.null(start_date)) start_date <- "2000-01-01"
  if (is.null(end_date)) end_date <- Sys.Date()
  url <- .cpsc_recall_url(start_date = start_date, end_date = end_date, keyword = query)
  raw <- .fetch_json(url)
  result <- .parse_recalls(raw)
  head(result, limit)
}

#' Get a single CPSC recall by recall number
#'
#' @param recall_number Recall number (e.g. "24090").
#' @return tibble with one row of recall details
#' @export
cpsc_recall <- function(recall_number) {
  url <- paste0(.cpsc_base, "/Recall?format=json&RecallNumber=", recall_number)
  raw <- .fetch_json(url)
  .parse_recalls(raw)
}

#' Get CPSC recalls by year
#'
#' @param year Integer year (e.g. 2024).
#' @param limit Maximum rows to return (default 500).
#' @return tibble of recalls for the given year
#' @export
cpsc_by_year <- function(year, limit = 500) {
  start_date <- paste0(year, "-01-01")
  end_date <- paste0(year, "-12-31")
  url <- .cpsc_recall_url(start_date = start_date, end_date = end_date)
  raw <- .fetch_json(url)
  result <- .parse_recalls(raw)
  head(result, limit)
}

#' Summarize CPSC recalls by year
#'
#' Fetches recalls from 2015 to present and counts per year.
#'
#' @return tibble: year, n_recalls
#' @export
cpsc_summary <- function() {
  years <- seq(2015, as.integer(format(Sys.Date(), "%Y")))
  results <- lapply(years, function(y) {
    url <- .cpsc_recall_url(start_date = paste0(y, "-01-01"), end_date = paste0(y, "-12-31"))
    raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
    n <- if (is.null(raw)) 0L else if (is.data.frame(raw)) nrow(raw) else length(raw)
    tibble(year = y, n_recalls = as.integer(n))
  })
  bind_rows(results)
}

# == Context ===================================================================

#' Show CPSC client context for LLM use
#'
#' @return Invisibly returns context string
#' @export
cpsc_context <- function() {
  .build_context("cpsc.gov")
}
