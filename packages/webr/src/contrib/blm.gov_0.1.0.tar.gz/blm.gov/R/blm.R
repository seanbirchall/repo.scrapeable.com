#' List available BLM GIS service categories
#'
#' Returns the folder structure of the BLM national ArcGIS REST services.
#'
#' @return A tibble with columns: folder (character)
#' @export
blm_list <- function() {
  url <- paste0(.blm_base, "?f=json")
  tmp <- tempfile(fileext = ".json")
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_timeout(15) |>
    httr2::req_perform(path = tmp)
  raw <- jsonlite::fromJSON(tmp, simplifyVector = FALSE)
  folders <- vapply(raw$folders, as.character, character(1))
  tibble::tibble(folder = folders)
}

#' List services within a BLM GIS folder
#'
#' @param folder Character. One of the folder names from blm_list().
#' @return A tibble with columns: name, type
#' @export
blm_services <- function(folder) {
  url <- paste0(.blm_base, "/", folder, "?f=json")
  tmp <- tempfile(fileext = ".json")
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_timeout(15) |>
    httr2::req_perform(path = tmp)
  raw <- jsonlite::fromJSON(tmp, simplifyVector = FALSE)
  if (length(raw$services) == 0) return(tibble::tibble(name = character(), type = character()))
  bind_rows(lapply(raw$services, function(s) {
    tibble::tibble(name = s$name %||% NA_character_, type = s$type %||% NA_character_)
  }))
}

#' Search BLM national recreation sites
#'
#' Queries the BLM National Recreation Sites FeatureServer.
#'
#' @param query Character. Search term to match against RecAreaName.
#' @param state Character. Two-letter state abbreviation to filter by.
#' @param max_results Integer. Maximum number of results (default 100).
#' @return A tibble of recreation sites.
#' @export
blm_search <- function(query = NULL, state = NULL, max_results = 100) {
  clauses <- "1=1"
  if (!is.null(state)) {
    clauses <- paste0("State = '", toupper(state), "'")
  }
  if (!is.null(query)) {
    q_esc <- gsub("'", "''", query)
    clause <- paste0("RecAreaName LIKE '%", q_esc, "%'")
    clauses <- if (clauses == "1=1") clause else paste(clauses, "AND", clause)
  }
  .blm_fetch("recreation/BLM_Natl_Recreation_Offline", layer = 0,
             where = clauses, max_results = max_results,
             order_by = "RecAreaName ASC")
}

#' Get BLM National Landscape Conservation System areas
#'
#' @param state Character. Two-letter state abbreviation.
#' @param max_results Integer. Maximum results (default 200).
#' @return A tibble of NLCS areas.
#' @export
blm_nlcs <- function(state = NULL, max_results = 200) {
  where <- "1=1"
  if (!is.null(state)) {
    where <- paste0("STATE_GEOG = '", toupper(state), "'")
  }
  .blm_fetch("lands/BLM_Natl_NLCS_Generalized", layer = 0,
             where = where, max_results = max_results)
}

#' Get BLM recreation site details by name
#'
#' @param name Character. Exact or partial name of the recreation area.
#' @return A tibble with all available fields.
#' @export
blm_recreation_site <- function(name) {
  q_esc <- gsub("'", "''", name)
  where <- paste0("RecAreaName LIKE '%", q_esc, "%'")
  .blm_fetch("recreation/BLM_Natl_Recreation_Offline", layer = 0,
             where = where, max_results = 10)
}

#' Count features in a BLM service layer
#'
#' @param service Character. Service path.
#' @param layer Integer. Layer index (default 0).
#' @param where Character. SQL where clause (default "1=1").
#' @return Integer count.
#' @export
blm_count <- function(service, layer = 0, where = "1=1") {
  .blm_count(service, layer, where)
}

#' Query any BLM FeatureServer layer
#'
#' @param service Character. Service path.
#' @param layer Integer. Layer index (default 0).
#' @param where Character. SQL where clause (default "1=1").
#' @param fields Character. Comma-separated field names or "*".
#' @param max_results Integer. Maximum results (default 500).
#' @return A tibble of feature attributes.
#' @export
blm_query <- function(service, layer = 0, where = "1=1", fields = "*",
                      max_results = 500) {
  .blm_fetch(service, layer, where = where, out_fields = fields,
             max_results = max_results)
}

#' Print blm.gov client context
#'
#' @return Character string of function signatures (invisibly).
#' @export
blm_context <- function() {
  src <- system.file("source", "blm.R", package = "blm.gov")
  if (src == "") {
    f <- sys.frame(sys.nframe())$ofile %||%
      attr(body(blm_context), "srcfile")$filename %||% ""
    if (nzchar(f)) src <- f
  }
  .build_context("blm.gov", src_file = if (nzchar(src)) src else NULL,
                 header_lines = c(
                   "# blm.gov -- Bureau of Land Management GIS R client",
                   "# Base: https://gis.blm.gov/arcgis/rest/services",
                   "# Auth: none"
                 ))
}
