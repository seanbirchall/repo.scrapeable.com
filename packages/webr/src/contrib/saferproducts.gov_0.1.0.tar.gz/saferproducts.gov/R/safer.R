# == Public functions ==========================================================

#' List recent product recalls
#'
#' @param start_date Start date (YYYY-MM-DD). Defaults to 90 days ago.
#' @param end_date End date (YYYY-MM-DD). Defaults to today.
#' @param limit Maximum rows to return (default 100).
#' @return tibble of recalls
#' @export
safer_list <- function(start_date = NULL, end_date = NULL, limit = 100) {
  if (is.null(start_date)) start_date <- Sys.Date() - 90
  if (is.null(end_date)) end_date <- Sys.Date()
  url <- sprintf("%s/Recall?format=json&RecallDateStart=%s&RecallDateEnd=%s",
                 .safer_base, format(as.Date(start_date), "%Y-%m-%d"),
                 format(as.Date(end_date), "%Y-%m-%d"))
  raw <- .fetch_json(url)
  result <- .parse_recalls(raw)
  head(result, limit)
}

#' Search product recalls by keyword
#'
#' @param query Search term (matched against recall titles).
#' @param start_date Optional start date (YYYY-MM-DD). Defaults to 2000-01-01.
#' @param end_date Optional end date (YYYY-MM-DD). Defaults to today.
#' @param limit Maximum rows (default 100).
#' @return tibble of matching recalls
#' @export
safer_search <- function(query, start_date = NULL, end_date = NULL, limit = 100) {
  if (is.null(start_date)) start_date <- "2000-01-01"
  if (is.null(end_date)) end_date <- Sys.Date()
  url <- sprintf("%s/Recall?format=json&RecallDateStart=%s&RecallDateEnd=%s&RecallTitle=%s",
                 .safer_base, format(as.Date(start_date), "%Y-%m-%d"),
                 format(as.Date(end_date), "%Y-%m-%d"),
                 utils::URLencode(query, reserved = TRUE))
  raw <- .fetch_json(url)
  result <- .parse_recalls(raw)
  head(result, limit)
}

#' Get all CPSC civil and criminal penalties
#'
#' @param penalty_type Optional: "Civil" or "Criminal".
#' @param limit Maximum rows (default 500).
#' @return tibble of penalties
#' @export
safer_penalties <- function(penalty_type = NULL, limit = 500) {
  url <- paste0(.safer_base, "/Penalty?format=json")
  raw <- .fetch_json(url)
  result <- .parse_penalties(raw)
  if (!is.null(penalty_type)) {
    result <- result |> filter(grepl(penalty_type, .data$penalty_type, ignore.case = TRUE))
  }
  head(result, limit)
}

#' Search penalties by firm name
#'
#' @param firm Firm name (case-insensitive partial match).
#' @param limit Maximum rows (default 100).
#' @return tibble of matching penalties
#' @export
safer_penalty_search <- function(firm, limit = 100) {
  url <- paste0(.safer_base, "/Penalty?format=json")
  raw <- .fetch_json(url)
  result <- .parse_penalties(raw)
  pattern <- firm
  result <- result |> filter(grepl(pattern, firm, ignore.case = TRUE))
  head(result, limit)
}

#' Summarize penalties by fiscal year
#'
#' @return tibble: fiscal_year, n_penalties, total_fines
#' @export
safer_penalties_by_year <- function() {
  url <- paste0(.safer_base, "/Penalty?format=json")
  raw <- .fetch_json(url)
  result <- .parse_penalties(raw)
  result |>
    group_by(fiscal_year) |>
    summarise(
      n_penalties = n(),
      total_fines = sum(fine_numeric, na.rm = TRUE),
      .groups = "drop"
    ) |>
    arrange(fiscal_year)
}

#' Get a single recall by recall number
#'
#' @param recall_number Recall number (e.g. "24090").
#' @return tibble with one row
#' @export
safer_recall <- function(recall_number) {
  url <- sprintf("%s/Recall?format=json&RecallNumber=%s", .safer_base, recall_number)
  raw <- .fetch_json(url)
  .parse_recalls(raw)
}

# == Context ===================================================================

#' Show SaferProducts client context for LLM use
#'
#' @return Invisibly returns context string
#' @export
safer_context <- function() {
  .build_context("saferproducts.gov")
}
