# ip-ranges.amazonaws.com.R - Self-contained ip-ranges.amazonaws.com client



# ip-ranges-amazonaws-com.R
# Self-contained AWS IP Ranges API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none (public data)
# Rate limits: none known


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.aws_ip_url <- "https://ip-ranges.amazonaws.com/ip-ranges.json"

`%||%` <- function(a, b) if (is.null(a)) b else a

.fetch_aws_ip <- function() {
  tmp <- tempfile(fileext = ".json")
  httr2::request(.aws_ip_url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  jsonlite::fromJSON(tmp, simplifyVector = FALSE)
}

# == Schemas ===================================================================

.schema_ranges <- tibble(
  ip_prefix = character(), region = character(),
  service = character(), network_border_group = character()
)

# == Public functions ==========================================================

#' Get AWS IPv4 IP ranges
#'
#' Fetches all AWS IPv4 CIDR prefixes with optional filtering by service
#' or region.
#'
#' @param service Filter by AWS service (e.g. "S3", "EC2", "CLOUDFRONT",
#'   "AMAZON"). Default NULL returns all.
#' @param region Filter by region pattern (e.g. "us-east-1", "eu-").
#'   Uses partial matching. Default NULL returns all.
#' @return tibble: ip_prefix, region, service, network_border_group
awsip_ranges <- function(service = NULL, region = NULL) {
  raw <- tryCatch(.fetch_aws_ip(), error = function(e) NULL)
  if (is.null(raw)) return(.schema_ranges)

  prefixes <- raw$prefixes
  if (length(prefixes) == 0) return(.schema_ranges)

  tbl <- tibble(
    ip_prefix = vapply(prefixes, function(x) x$ip_prefix %||% NA_character_, character(1)),
    region = vapply(prefixes, function(x) x$region %||% NA_character_, character(1)),
    service = vapply(prefixes, function(x) x$service %||% NA_character_, character(1)),
    network_border_group = vapply(prefixes, function(x) x$network_border_group %||% NA_character_, character(1))
  )
  if (!is.null(service)) tbl <- tbl[tbl$service == service, ]
  if (!is.null(region)) tbl <- tbl[grepl(region, tbl$region), ]
  tbl
}

#' Get AWS IPv6 IP ranges
#'
#' Fetches all AWS IPv6 CIDR prefixes with optional filtering.
#'
#' @param service Filter by AWS service. Default NULL returns all.
#' @param region Filter by region pattern. Default NULL returns all.
#' @return tibble: ipv6_prefix, region, service, network_border_group
awsip_ipv6_ranges <- function(service = NULL, region = NULL) {
  raw <- tryCatch(.fetch_aws_ip(), error = function(e) NULL)
  if (is.null(raw)) return(tibble(ipv6_prefix = character(), region = character(),
                                   service = character(), network_border_group = character()))

  prefixes <- raw$ipv6_prefixes
  if (length(prefixes) == 0) return(tibble(ipv6_prefix = character(), region = character(),
                                            service = character(), network_border_group = character()))

  tbl <- tibble(
    ipv6_prefix = vapply(prefixes, function(x) x$ipv6_prefix %||% NA_character_, character(1)),
    region = vapply(prefixes, function(x) x$region %||% NA_character_, character(1)),
    service = vapply(prefixes, function(x) x$service %||% NA_character_, character(1)),
    network_border_group = vapply(prefixes, function(x) x$network_border_group %||% NA_character_, character(1))
  )
  if (!is.null(service)) tbl <- tbl[tbl$service == service, ]
  if (!is.null(region)) tbl <- tbl[grepl(region, tbl$region), ]
  tbl
}

#' List all AWS services in IP ranges
#'
#' @return tibble: service, ipv4_count, ipv6_count
awsip_services <- function() {
  raw <- tryCatch(.fetch_aws_ip(), error = function(e) NULL)
  if (is.null(raw)) return(tibble(service = character(), ipv4_count = integer(), ipv6_count = integer()))

  v4 <- vapply(raw$prefixes, function(x) x$service %||% NA_character_, character(1))
  v6 <- vapply(raw$ipv6_prefixes, function(x) x$service %||% NA_character_, character(1))

  v4_counts <- as.data.frame(table(v4), stringsAsFactors = FALSE)
  names(v4_counts) <- c("service", "ipv4_count")
  v6_counts <- as.data.frame(table(v6), stringsAsFactors = FALSE)
  names(v6_counts) <- c("service", "ipv6_count")

  result <- merge(v4_counts, v6_counts, by = "service", all = TRUE)
  result$ipv4_count[is.na(result$ipv4_count)] <- 0L
  result$ipv6_count[is.na(result$ipv6_count)] <- 0L
  as_tibble(result) |>
    mutate(ipv4_count = as.integer(ipv4_count), ipv6_count = as.integer(ipv6_count)) |>
    arrange(desc(ipv4_count))
}

#' List all AWS regions in IP ranges
#'
#' @return tibble: region, ipv4_count, ipv6_count
awsip_regions <- function() {
  raw <- tryCatch(.fetch_aws_ip(), error = function(e) NULL)
  if (is.null(raw)) return(tibble(region = character(), ipv4_count = integer(), ipv6_count = integer()))

  v4 <- vapply(raw$prefixes, function(x) x$region %||% NA_character_, character(1))
  v6 <- vapply(raw$ipv6_prefixes, function(x) x$region %||% NA_character_, character(1))

  v4_counts <- as.data.frame(table(v4), stringsAsFactors = FALSE)
  names(v4_counts) <- c("region", "ipv4_count")
  v6_counts <- as.data.frame(table(v6), stringsAsFactors = FALSE)
  names(v6_counts) <- c("region", "ipv6_count")

  result <- merge(v4_counts, v6_counts, by = "region", all = TRUE)
  result$ipv4_count[is.na(result$ipv4_count)] <- 0L
  result$ipv6_count[is.na(result$ipv6_count)] <- 0L
  as_tibble(result) |>
    mutate(ipv4_count = as.integer(ipv4_count), ipv6_count = as.integer(ipv6_count)) |>
    arrange(desc(ipv4_count))
}

# == Context ===================================================================

#' Generate LLM-friendly context for ip-ranges.amazonaws.com
#'
#' @return Character string with full function signatures and bodies
awsip_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/ip-ranges.amazonaws.com.R"
  if (!file.exists(src_file)) {
    cat("# ip-ranges.amazonaws.com context - source not found\n")
    return(invisible("# ip-ranges.amazonaws.com context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}
