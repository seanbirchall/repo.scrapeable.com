# api.ooni.io.R - Self-contained api.ooni.io client



# api-ooni-io.R
# Self-contained OONI (Open Observatory of Network Interference) API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required.
# Rate limits: none documented — be polite.


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.ooni_base <- "https://api.ooni.io/api/v1"
# -- Fetch helpers -------------------------------------------------------------

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))

`%||%` <- function(a, b) if (is.null(a)) b else a


# == Schemas ===================================================================

.schema_measurements <- tibble(
  measurement_uid = character(), report_id = character(),
  probe_cc = character(), probe_asn = character(),
  test_name = character(), input = character(),
  measurement_start_time = character(),
  anomaly = logical(), confirmed = logical(), failure = logical()
)

.schema_incidents <- tibble(
  id = character(), title = character(), text = character(),
  start_time = character(), create_time = character(),
  update_time = character(), event_type = character()
)

# == Measurements ==============================================================

#' Search OONI network measurements
#'
#' Query the OONI measurements database for internet censorship test results.
#'
#' @param country ISO 3166-1 alpha-2 country code (e.g. "IR", "CN", "RU")
#' @param test_name OONI test name: "web_connectivity", "tor", "signal",
#'   "whatsapp", "facebook_messenger", "telegram", "vanilla_tor",
#'   "http_invalid_request_line", "ndt"
#' @param limit Max results (default 20, max 100)
#' @param input URL or input tested (optional, for web_connectivity)
#' @param since Only measurements after this date (YYYY-MM-DD, optional)
#' @param until Only measurements before this date (YYYY-MM-DD, optional)
#' @return tibble: measurement_uid, report_id, probe_cc, probe_asn,
#'   test_name, input, measurement_start_time, anomaly, confirmed, failure
ooni_measurements <- function(country = NULL, test_name = NULL, limit = 20,
                              input = NULL, since = NULL, until = NULL) {
  params <- list()
  if (!is.null(country)) params$probe_cc <- country
  if (!is.null(test_name)) params$test_name <- test_name
  if (!is.null(input)) params$input <- input
  if (!is.null(since)) params$since <- since
  if (!is.null(until)) params$until <- until
  params$limit <- limit

  query <- paste(names(params), vapply(params, as.character, character(1)),
                 sep = "=", collapse = "&")
  url <- paste0(.ooni_base, "/measurements?", query)

  raw <- tryCatch(.fetch_json(url), error = function(e) {
    warning("OONI measurements query failed: ", e$message)
    return(list())
  })

  results <- raw$results
  if (is.null(results) || length(results) == 0) return(.schema_measurements)

  as_tibble(results) |>
    transmute(
      measurement_uid      = as.character(measurement_uid),
      report_id            = as.character(report_id),
      probe_cc             = as.character(probe_cc),
      probe_asn            = as.character(probe_asn),
      test_name            = as.character(test_name),
      input                = as.character(if ("input" %in% names(results)) input else NA_character_),
      measurement_start_time = as.character(measurement_start_time),
      anomaly              = as.logical(anomaly),
      confirmed            = as.logical(confirmed),
      failure              = as.logical(failure)
    )
}

# == Incidents =================================================================

#' Search OONI censorship incidents
#'
#' Retrieve reported internet censorship incidents from the OONI database.
#'
#' @param limit Max results (default 20)
#' @return tibble: id, title, text, start_time, create_time,
#'   update_time, event_type
ooni_incidents <- function(limit = 20) {
  url <- paste0(.ooni_base, "/incidents/search?limit=", limit)

  raw <- tryCatch(.fetch_json(url), error = function(e) {
    warning("OONI incidents query failed: ", e$message)
    return(list())
  })

  incidents <- raw$incidents
  if (is.null(incidents) || length(incidents) == 0) return(.schema_incidents)

  as_tibble(incidents) |>
    transmute(
      id          = as.character(id %||% NA_character_),
      title       = as.character(title %||% NA_character_),
      text        = as.character(if ("text" %in% names(incidents)) text else NA_character_),
      start_time  = as.character(if ("start_time" %in% names(incidents)) start_time else NA_character_),
      create_time = as.character(create_time %||% NA_character_),
      update_time = as.character(update_time %||% NA_character_),
      event_type  = as.character(if ("event_type" %in% names(incidents)) event_type else NA_character_)
    )
}

# == Aggregation ===============================================================

#' Get measurement aggregation stats by country
#'
#' @param probe_cc ISO 3166-1 alpha-2 country code (e.g. "IR", "CN")
#' @param test_name OONI test name (e.g. "web_connectivity")
#' @param since Start date YYYY-MM-DD (default 30 days ago)
#' @param until End date YYYY-MM-DD (default today)
#' @return tibble: measurement_start_day, measurement_count, anomaly_count, confirmed_count
ooni_aggregation <- function(probe_cc, test_name = "web_connectivity",
                             since = NULL, until = NULL) {
  schema <- tibble(measurement_start_day = character(), measurement_count = integer(),
                   anomaly_count = integer(), confirmed_count = integer())
  if (is.null(since)) since <- format(Sys.Date() - 30, "%Y-%m-%d")
  if (is.null(until)) until <- format(Sys.Date(), "%Y-%m-%d")
  url <- sprintf("%s/aggregation?probe_cc=%s&test_name=%s&since=%s&until=%s&axis_x=measurement_start_day",
                 .ooni_base, probe_cc, test_name, since, until)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(schema)
  d <- raw$result
  if (is.null(d) || length(d) == 0) return(schema)
  if (!is.data.frame(d)) return(schema)

  as_tibble(d) |>
    transmute(
      measurement_start_day = as.character(if ("measurement_start_day" %in% names(d)) measurement_start_day else NA_character_),
      measurement_count = as.integer(if ("measurement_count" %in% names(d)) measurement_count else NA_integer_),
      anomaly_count = as.integer(if ("anomaly_count" %in% names(d)) anomaly_count else NA_integer_),
      confirmed_count = as.integer(if ("confirmed_count" %in% names(d)) confirmed_count else NA_integer_)
    )
}

# == Context ===================================================================

#' Generate LLM-friendly context for api.ooni.io
#'
#' @return Character string with full function signatures and bodies
ooni_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/api.ooni.io.R"
  if (!file.exists(src_file)) {
    cat("# api.ooni.io context - source not found\n")
    return(invisible("# api.ooni.io context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

