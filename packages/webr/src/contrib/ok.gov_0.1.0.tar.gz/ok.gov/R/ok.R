#' Search Oklahoma open datasets
#'
#' @param q Search query (optional)
#' @param rows Max results (default 20)
#' @param start Pagination offset (default 0)
#' @return tibble: name, title, notes, organization, num_resources, metadata_modified
#' @export
ok_search <- function(q = NULL, rows = 20, start = 0) {
  url <- sprintf("%s/action/package_search?rows=%d&start=%d",
                 .ok_base, as.integer(rows), as.integer(start))
  if (!is.null(q)) url <- paste0(url, "&q=", utils::URLencode(q))
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || !isTRUE(raw$success)) return(.schema_packages)
  results <- raw$result$results
  if (is.null(results) || length(results) == 0) return(.schema_packages)
  tibble(
    name              = as.character(results$name %||% NA),
    title             = as.character(results$title %||% NA),
    notes             = substr(as.character(results$notes %||% ""), 1, 300),
    organization      = as.character(results$organization$title %||% NA),
    num_resources     = as.integer(results$num_resources %||% NA),
    metadata_modified = as.character(results$metadata_modified %||% NA)
  )
}

#' List all Oklahoma open dataset names
#'
#' @param limit Max results (default 500)
#' @return character vector of dataset slugs
#' @export
ok_list <- function(limit = 500) {
  url <- sprintf("%s/action/package_list?limit=%d", .ok_base, as.integer(limit))
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || !isTRUE(raw$success)) return(character())
  as.character(raw$result)
}

#' Get resources for an Oklahoma dataset
#'
#' @param name Dataset slug
#' @return tibble: id, name, format, url, description
#' @export
ok_package <- function(name) {
  url <- sprintf("%s/action/package_show?id=%s", .ok_base, utils::URLencode(name))
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || !isTRUE(raw$success)) return(tibble())
  resources <- raw$result$resources
  if (is.null(resources) || !is.data.frame(resources)) return(tibble())
  tibble(
    id          = as.character(resources$id %||% NA),
    name        = as.character(resources$name %||% NA),
    format      = as.character(resources$format %||% NA),
    url         = as.character(resources$url %||% NA),
    description = as.character(resources$description %||% NA)
  )
}

#' Query Oklahoma datastore records
#'
#' @param resource_id Resource UUID
#' @param q Full-text search query (optional)
#' @param filters Named list of field:value filters (optional)
#' @param limit Max records (default 100)
#' @param offset Pagination offset (default 0)
#' @param sort Sort string (optional)
#' @return tibble of data records
#' @export
ok_data <- function(resource_id, q = NULL, filters = NULL,
                    limit = 100, offset = 0, sort = NULL) {
  url <- sprintf("%s/action/datastore_search?resource_id=%s&limit=%d&offset=%d",
                 .ok_base, resource_id, as.integer(limit), as.integer(offset))
  if (!is.null(q)) url <- paste0(url, "&q=", utils::URLencode(q))
  if (!is.null(filters)) {
    fj <- jsonlite::toJSON(filters, auto_unbox = TRUE)
    url <- paste0(url, "&filters=", utils::URLencode(as.character(fj)))
  }
  if (!is.null(sort)) url <- paste0(url, "&sort=", utils::URLencode(sort))
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || !isTRUE(raw$success)) return(tibble())
  records <- raw$result$records
  if (is.null(records) || !is.data.frame(records) || nrow(records) == 0) return(tibble())
  as_tibble(records) |> select(-any_of("_id"))
}

#' Run a SQL query against Oklahoma datastore
#'
#' @param sql SQL query string
#' @return tibble of results
#' @export
ok_sql <- function(sql) {
  url <- paste0(.ok_base, "/action/datastore_search_sql?sql=", utils::URLencode(sql))
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || !isTRUE(raw$success)) return(tibble())
  records <- raw$result$records
  if (is.null(records) || !is.data.frame(records) || nrow(records) == 0) return(tibble())
  as_tibble(records)
}

#' Generate LLM-friendly context for ok.gov
#'
#' @return Character string (invisibly), also printed
#' @export
ok_context <- function() {
  .build_context("ok.gov")
}
