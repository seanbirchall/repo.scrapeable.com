# ed.gov.R
# Self-contained Department of Education client.
# Covers: NCES CCD (K-12 schools/districts), NCES IPEDS (postsecondary),
# and ERIC (education research database).
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required
# APIs: educationdata.urban.org (CCD/IPEDS), api.ies.ed.gov (ERIC)

library(httr2)
library(jsonlite)
library(dplyr, warn.conflicts = FALSE)
library(tibble)


# == Private utilities =========================================================

`%||%` <- function(a, b) if (is.null(a)) b else a
.ua <- "support@scrapeable.com"
.ccd_base <- "https://educationdata.urban.org/api/v1"
.ipeds_base <- "https://educationdata.urban.org/api/v1"
.eric_base <- "https://api.ies.ed.gov/eric/"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url))


# == Schemas ===================================================================

.schema_schools <- tibble(
  ncessch = character(), school_name = character(), leaid = character(),
  lea_name = character(), state_location = character(), city_location = character(),
  zip_location = character(), enrollment = integer(), year = integer()
)

.schema_districts <- tibble(
  leaid = character(), lea_name = character(), state_leaid = character(),
  state_location = character(), city_location = character(),
  zip_location = character(), enrollment = integer(), year = integer()
)

.schema_institutions <- tibble(
  unitid = integer(), inst_name = character(), state_abbr = character(),
  city = character(), zip = character(), sector = integer(),
  inst_level = integer(), year = integer()
)

.schema_enrollment <- tibble(
  unitid = integer(), inst_name = character(), year = integer(),
  enrollment_fall = integer(), state_abbr = character()
)

.schema_search <- tibble(
  id = character(), title = character(), author = character(),
  source = character(), publicationdate = character(),
  description = character(), subject = character(),
  url = character()
)




#' Search CCD school directory
#'
#' Returns school-level data from the NCES Common Core of Data via the
#' Urban Institute Education Data API.
#'
#' @param year School year (e.g., 2021 for 2021-22). Default 2021.
#' @param state Two-digit FIPS code as string (e.g., "06" for CA), or NULL for all.
#' @param limit Maximum records to return. Default 100.
#' @return tibble: ncessch, school_name, leaid, lea_name, state_location,
#'   city_location, zip_location, enrollment, year
ccd_schools <- function(year = 2021, state = NULL, limit = 100) {
  url <- sprintf("%s/schools/ccd/directory/%d/?limit=%d",
                 .ccd_base, as.integer(year), as.integer(limit))
  if (!is.null(state)) url <- paste0(url, "&fips=", state)

  raw <- .fetch_json(url)
  results <- raw$results
  if (is.null(results) || nrow(results) == 0) return(.schema_schools)

  nms <- names(results)
  as_tibble(results) |>
    transmute(
      ncessch = as.character(if ("ncessch" %in% nms) ncessch else NA_character_),
      school_name = as.character(if ("school_name" %in% nms) school_name else NA_character_),
      leaid = as.character(if ("leaid" %in% nms) leaid else NA_character_),
      lea_name = as.character(if ("lea_name" %in% nms) lea_name else NA_character_),
      state_location = as.character(if ("state_location" %in% nms) state_location else NA_character_),
      city_location = as.character(if ("city_location" %in% nms) city_location else NA_character_),
      zip_location = as.character(if ("zip_location" %in% nms) zip_location else NA_character_),
      enrollment = as.integer(if ("enrollment" %in% nms) enrollment else NA_integer_),
      year = as.integer(year)
    )
}


#' Search CCD school district directory
#'
#' Returns district-level data from the NCES Common Core of Data.
#'
#' @param year School year (e.g., 2021 for 2021-22). Default 2021.
#' @param state Two-digit FIPS code as string (e.g., "06" for CA), or NULL for all.
#' @param limit Maximum records to return. Default 100.
#' @return tibble: leaid, lea_name, state_leaid, state_location,
#'   city_location, zip_location, enrollment, year
ccd_districts <- function(year = 2021, state = NULL, limit = 100) {
  url <- sprintf("%s/school-districts/ccd/directory/%d/?limit=%d",
                 .ccd_base, as.integer(year), as.integer(limit))
  if (!is.null(state)) url <- paste0(url, "&fips=", state)

  raw <- .fetch_json(url)
  results <- raw$results
  if (is.null(results) || nrow(results) == 0) return(.schema_districts)

  nms <- names(results)
  as_tibble(results) |>
    transmute(
      leaid = as.character(if ("leaid" %in% nms) leaid else NA_character_),
      lea_name = as.character(if ("lea_name" %in% nms) lea_name else NA_character_),
      state_leaid = as.character(if ("state_leaid" %in% nms) state_leaid else NA_character_),
      state_location = as.character(if ("state_location" %in% nms) state_location else NA_character_),
      city_location = as.character(if ("city_location" %in% nms) city_location else NA_character_),
      zip_location = as.character(if ("zip_location" %in% nms) zip_location else NA_character_),
      enrollment = as.integer(if ("enrollment" %in% nms) enrollment else NA_integer_),
      year = as.integer(year)
    )
}


#' Get school enrollment totals by race and sex
#'
#' Returns grade-99 (total) enrollment from the CCD enrollment endpoint,
#' broken down by race and sex codes.
#'
#' @param year School year (e.g., 2020)
#' @param state Two-digit FIPS code (optional)
#' @param limit Max records (default 100)
#' @return tibble: ncessch, year, grade, race, sex, enrollment
ccd_enrollment <- function(year = 2020, state = NULL, limit = 100) {
  schema <- tibble(ncessch = character(), year = integer(), grade = integer(),
                   race = integer(), sex = integer(), enrollment = integer())
  url <- sprintf("%s/schools/ccd/enrollment/%d/grade-99/?limit=%d",
                 .ccd_base, as.integer(year), as.integer(limit))
  if (!is.null(state)) url <- paste0(url, "&fips=", state)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$results) || nrow(raw$results) == 0) return(schema)

  nms <- names(raw$results)
  as_tibble(raw$results) |>
    transmute(
      ncessch = as.character(if ("ncessch" %in% nms) ncessch else NA_character_),
      year = as.integer(if ("year" %in% nms) year else NA_integer_),
      grade = as.integer(if ("grade" %in% nms) grade else NA_integer_),
      race = as.integer(if ("race" %in% nms) race else NA_integer_),
      sex = as.integer(if ("sex" %in% nms) sex else NA_integer_),
      enrollment = as.integer(if ("enrollment" %in% nms) enrollment else NA_integer_)
    )
}


#' Search IPEDS institution directory
#'
#' Returns institution-level data from the NCES IPEDS via the Urban Institute
#' Education Data API.
#'
#' @param year Academic year (e.g., 2021). Default 2021.
#' @param state Two-digit FIPS code as string (e.g., "06" for CA), or NULL for all.
#' @param limit Maximum records to return. Default 100.
#' @return tibble: unitid, inst_name, state_abbr, city, zip, sector,
#'   inst_level, year
#' @export
ipeds_institutions <- function(year = 2021, state = NULL, limit = 100) {
  url <- sprintf("%s/college-university/ipeds/directory/%d/?limit=%d",
                 .ipeds_base, as.integer(year), as.integer(limit))
  if (!is.null(state)) url <- paste0(url, "&fips=", state)

  raw <- .fetch_json(url)
  results <- raw$results
  if (is.null(results) || nrow(results) == 0) return(.schema_institutions)

  nms <- names(results)
  as_tibble(results) |>
    transmute(
      unitid = as.integer(if ("unitid" %in% nms) unitid else NA_integer_),
      inst_name = as.character(if ("inst_name" %in% nms) inst_name else NA_character_),
      state_abbr = as.character(if ("state_abbr" %in% nms) state_abbr else NA_character_),
      city = as.character(if ("city" %in% nms) city else NA_character_),
      zip = as.character(if ("zip" %in% nms) zip else NA_character_),
      sector = as.integer(if ("sector" %in% nms) sector else NA_integer_),
      inst_level = as.integer(if ("inst_level" %in% nms) inst_level else NA_integer_),
      year = as.integer(year)
    )
}


#' Search IPEDS fall enrollment data
#'
#' Returns enrollment data from IPEDS.
#'
#' @param year Academic year (e.g., 2021). Default 2021.
#' @param limit Maximum records to return. Default 100.
#' @return tibble: unitid, inst_name, year, enrollment_fall, state_abbr
#' @export
ipeds_enrollment <- function(year = 2021, limit = 100) {
  url <- sprintf("%s/college-university/ipeds/fall-enrollment/race/2021/%d/?limit=%d&sex=99&level_of_study=1&class_level=99",
                 .ipeds_base, as.integer(year), as.integer(limit))

  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) {
    # Fallback: use directory endpoint which has enrollment
    url2 <- sprintf("%s/college-university/ipeds/directory/%d/?limit=%d",
                    .ipeds_base, as.integer(year), as.integer(limit))
    raw <- .fetch_json(url2)
  }
  results <- raw$results
  if (is.null(results) || nrow(results) == 0) return(.schema_enrollment)

  nms <- names(results)
  enroll_col <- if ("enrollment_fall" %in% nms) "enrollment_fall" else
                if ("efytotlt" %in% nms) "efytotlt" else
                if ("enrollment" %in% nms) "enrollment" else NULL

  as_tibble(results) |>
    transmute(
      unitid = as.integer(if ("unitid" %in% nms) unitid else NA_integer_),
      inst_name = as.character(if ("inst_name" %in% nms) inst_name else NA_character_),
      year = as.integer(year),
      enrollment_fall = if (!is.null(enroll_col)) as.integer(.data[[enroll_col]]) else NA_integer_,
      state_abbr = as.character(if ("state_abbr" %in% nms) state_abbr else NA_character_)
    )
}


#' Get IPEDS completions (degrees awarded) data
#'
#' Returns degree completion counts by CIP code, award level, race, and sex.
#'
#' @param year Academic year (e.g., 2021). Default 2021.
#' @param limit Maximum records to return. Default 100.
#' @return tibble: unitid, year, cipcode, award_level, race, sex, awards
ipeds_completions <- function(year = 2021, limit = 100) {
  schema <- tibble(unitid = integer(), year = integer(), cipcode = character(),
                   award_level = integer(), race = integer(),
                   sex = integer(), awards = integer())
  url <- sprintf("%s/college-university/ipeds/completions-cip-2/%d/?limit=%d",
                 .ipeds_base, as.integer(year), as.integer(limit))
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw) || is.null(raw$results) || nrow(raw$results) == 0) return(schema)

  nms <- names(raw$results)
  as_tibble(raw$results) |>
    transmute(
      unitid = as.integer(if ("unitid" %in% nms) unitid else NA_integer_),
      year = as.integer(if ("year" %in% nms) year else NA_integer_),
      cipcode = as.character(if ("cipcode" %in% nms) cipcode else NA_character_),
      award_level = as.integer(if ("award_level" %in% nms) award_level else NA_integer_),
      race = as.integer(if ("race" %in% nms) race else NA_integer_),
      sex = as.integer(if ("sex" %in% nms) sex else NA_integer_),
      awards = as.integer(if ("awards" %in% nms) awards else NA_integer_)
    )
}


#' Search ERIC education research database
#'
#' @param query Search query (e.g. "mathematics instruction", "STEM education")
#' @param rows Number of results (default 10, max 200)
#' @param start Starting record offset for pagination (default 0)
#' @return tibble: id, title, author, source, publicationdate,
#'   description, subject, url
eric_search <- function(query, rows = 10, start = 0) {
  url <- paste0(.eric_base, "?search=", utils::URLencode(query),
                "&rows=", rows, "&start=", start, "&format=json")
  raw <- .fetch_json(url)
  d <- raw$response$docs
  if (is.null(d) || length(d) == 0) return(.schema_search)

  # author and subject may be list columns
  .collapse_col <- function(x) {
    if (is.list(x)) vapply(x, function(v) paste(v, collapse = "; "), character(1))
    else as.character(x)
  }

  as_tibble(d) |>
    transmute(
      id = as.character(id),
      title = as.character(title),
      author = .collapse_col(if ("author" %in% names(d)) author else NA_character_),
      source = as.character(if ("source" %in% names(d)) source else NA_character_),
      publicationdate = as.character(if ("publicationdate" %in% names(d)) publicationdate else NA_character_),
      description = as.character(if ("description" %in% names(d)) description else NA_character_),
      subject = .collapse_col(if ("subject" %in% names(d)) subject else NA_character_),
      url = paste0("https://eric.ed.gov/?id=", id)
    )
}


#' Get a single ERIC document by ID
#'
#' @param eric_id ERIC document ID (e.g. "EJ1234567" or "ED654321")
#' @return tibble with one row: id, title, author, source, publicationdate,
#'   description, subject, url, peerreviewed, publicationtype, fulltext_url
eric_document <- function(eric_id) {
  url <- paste0(.eric_base, "?search=id:", eric_id, "&rows=1&format=json")
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(.schema_search)

  d <- raw$response$docs
  if (is.null(d) || length(d) == 0) return(.schema_search)

  .collapse_col <- function(x) {
    if (is.list(x)) vapply(x, function(v) paste(v, collapse = "; "), character(1))
    else as.character(x)
  }

  nms <- names(d)
  as_tibble(d) |>
    transmute(
      id = as.character(id),
      title = as.character(title),
      author = .collapse_col(if ("author" %in% nms) author else NA_character_),
      source = as.character(if ("source" %in% nms) source else NA_character_),
      publicationdate = as.character(if ("publicationdate" %in% nms) publicationdate else NA_character_),
      description = as.character(if ("description" %in% nms) description else NA_character_),
      subject = .collapse_col(if ("subject" %in% nms) subject else NA_character_),
      url = paste0("https://eric.ed.gov/?id=", id),
      peerreviewed = as.character(if ("peerreviewed" %in% nms) peerreviewed else NA_character_),
      publicationtype = .collapse_col(if ("publicationtype" %in% nms) publicationtype else NA_character_)
    )
}


#' Search ERIC with faceted results
#'
#' Returns search results along with facet counts for subject, author,
#' publication type, etc.
#'
#' @param query Search query
#' @param rows Number of results (default 10)
#' @param facet_field Facet field: "subject", "author", "publicationtype",
#'   "source", "educationlevel" (default "subject")
#' @return list with $results (tibble) and $facets (tibble: value, count)
eric_facets <- function(query, rows = 10, facet_field = "subject") {
  url <- paste0(.eric_base, "?search=", utils::URLencode(query),
                "&rows=", rows, "&format=json",
                "&facet=on&facet.field=", facet_field)
  raw <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(raw)) return(list(results = .schema_search,
                                facets = tibble(value = character(), count = integer())))

  # Parse results
  results <- eric_search(query, rows = rows)

  # Parse facets
  fc <- raw$facet_counts$facet_fields
  if (is.null(fc)) {
    facets <- tibble(value = character(), count = integer())
  } else {
    fvals <- fc[[facet_field]]
    if (is.null(fvals) || length(fvals) == 0) {
      facets <- tibble(value = character(), count = integer())
    } else {
      # Facets come as alternating value, count pairs
      idx_vals <- seq(1, length(fvals), 2)
      idx_cnts <- seq(2, length(fvals), 2)
      facets <- tibble(
        value = as.character(fvals[idx_vals]),
        count = as.integer(fvals[idx_cnts])
      ) |> filter(count > 0)
    }
  }

  list(results = results, facets = facets)
}


# == Context ===================================================================

#' Generate LLM-friendly context for ed.gov
#'
#' @return Character string with full function signatures and bodies
ed_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/ed.gov.R"
  if (!file.exists(src_file)) {
    cat("# ed.gov context - source not found\n")
    return(invisible("# ed.gov context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

