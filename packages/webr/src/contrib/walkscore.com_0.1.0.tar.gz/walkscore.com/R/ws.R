# == Schemas ===================================================================

.schema_score <- tibble::tibble(
  address = character(),
  lat = numeric(),
  lon = numeric(),
  walkscore = integer(),
  walk_description = character(),
  transit_score = integer(),
  transit_description = character(),
  bike_score = integer(),
  bike_description = character(),
  tip = character()
)

# == Public functions ==========================================================

#' Get Walk Score, Transit Score, and Bike Score for an address
#'
#' @param address Street address
#' @param lat Latitude
#' @param lon Longitude
#' @param api_key Walk Score API key. Defaults to WALKSCORE_API_KEY env var.
#' @return tibble: address, lat, lon, walkscore, walk_description,
#'   transit_score, transit_description, bike_score, bike_description, tip
#' @export
ws_score <- function(address, lat, lon, api_key = NULL) {
  key <- .ws_key(api_key)
  url <- sprintf(
    "%s/score?format=json&address=%s&lat=%f&lon=%f&transit=1&bike=1&wsapikey=%s",
    .ws_base, utils::URLencode(address), lat, lon, key
  )
  raw <- .fetch_json(url)

  if (!is.null(raw$status) && raw$status != 1) {
    status_msg <- switch(as.character(raw$status),
      "2" = "Score being calculated, try again later",
      "30" = "Invalid API key",
      "31" = "API quota exceeded",
      "40" = "Your API key is invalid",
      "41" = "Your API quota has been exceeded",
      sprintf("API error status: %s", raw$status)
    )
    warning(status_msg)
    return(.schema_score)
  }

  transit <- raw$transit %||% list()
  bike <- raw$bike %||% list()

  tibble::tibble(
    address = as.character(raw$`snapped-address` %||% address),
    lat = as.numeric(lat),
    lon = as.numeric(lon),
    walkscore = as.integer(raw$walkscore %||% NA),
    walk_description = as.character(raw$description %||% NA),
    transit_score = as.integer(transit$score %||% NA),
    transit_description = as.character(transit$description %||% NA),
    bike_score = as.integer(bike$score %||% NA),
    bike_description = as.character(bike$description %||% NA),
    tip = as.character(raw$tip %||% NA)
  )
}

#' Get Walk Scores for multiple addresses
#'
#' @param addresses Character vector of street addresses
#' @param lats Numeric vector of latitudes
#' @param lons Numeric vector of longitudes
#' @param api_key Walk Score API key
#' @return tibble: same columns as ws_score(), one row per address
#' @export
ws_scores_batch <- function(addresses, lats, lons, api_key = NULL) {
  results <- lapply(seq_along(addresses), function(i) {
    tryCatch(
      ws_score(addresses[i], lats[i], lons[i], api_key),
      error = function(e) {
        row <- .schema_score[1, ]
        row$address <- addresses[i]
        row$lat <- lats[i]
        row$lon <- lons[i]
        row
      }
    )
  })
  bind_rows(results)
}

#' Show context for the walkscore.com client
#'
#' @return Invisible string of context
#' @export
ws_context <- function() {
  .build_context(
    "walkscore.com",
    header_lines = c(
      "# walkscore.com - Walk Score API",
      "# Walk, Transit, and Bike scores for any address",
      "# Requires API key (WALKSCORE_API_KEY env var)"
    )
  )
}
