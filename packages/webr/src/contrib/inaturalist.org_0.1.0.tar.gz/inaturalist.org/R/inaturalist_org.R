# inaturalist.org.R - Self-contained inaturalist.org client



# inaturalist.R
# Self-contained iNaturalist API client.
# All public functions return tibbles. All columns properly typed.
#
# Dependencies: httr2, jsonlite, dplyr, tibble
# Auth: none required
# Rate limits: ~100 requests/minute (be polite)


# == Private utilities =========================================================

.ua <- "support@scrapeable.com"
.inat_base <- "https://api.inaturalist.org/v1"

.fetch <- function(url, ext = ".json") {
  tmp <- tempfile(fileext = ext)
  httr2::request(url) |>
    httr2::req_headers(`User-Agent` = .ua) |>
    httr2::req_perform(path = tmp)
  tmp
}

.fetch_json <- function(url) jsonlite::fromJSON(.fetch(url), simplifyVector = TRUE)

# == Schemas ===================================================================

.schema_observations <- tibble(
  id = integer(), species_guess = character(), taxon_name = character(),
  observed_on = as.Date(character()), place_guess = character(),
  latitude = numeric(), longitude = numeric(), quality_grade = character(),
  user_login = character()
)

.schema_taxa <- tibble(
  id = integer(), name = character(), common_name = character(),
  rank = character(), observations_count = integer(),
  iconic_taxon_name = character()
)

`%||%` <- function(x, y) if (is.null(x)) y else x

# == Public functions ==========================================================

#' Search iNaturalist observations
#'
#' @param taxon_name Taxon name to filter by (e.g. "Panthera", "Aves")
#' @param query Free-text search query
#' @param place_id iNaturalist place ID to filter by
#' @param quality_grade Quality grade: "research", "needs_id", or "casual"
#' @param per_page Results per page (default 30, max 200)
#' @param page Page number (default 1)
#' @return tibble: id, species_guess, taxon_name, observed_on, place_guess,
#'   latitude, longitude, quality_grade, user_login
inat_observations <- function(taxon_name = NULL, query = NULL, place_id = NULL,
                              quality_grade = NULL, per_page = 30, page = 1) {
  params <- list(
    taxon_name = taxon_name, q = query, place_id = place_id,
    quality_grade = quality_grade, per_page = per_page, page = page
  )
  params <- params[!vapply(params, is.null, logical(1))]
  qstr <- paste(names(params), params, sep = "=", collapse = "&")
  url <- paste0(.inat_base, "/observations?", qstr)

  raw <- .fetch_json(url)
  results <- raw$results
  if (is.null(results) || length(results) == 0) return(.schema_observations)

  tibble(
    id = as.integer(results$id),
    species_guess = as.character(results$species_guess %||% NA_character_),
    taxon_name = as.character(
      if (!is.null(results$taxon) && !is.null(results$taxon$name)) results$taxon$name
      else NA_character_
    ),
    observed_on = as.Date(results$observed_on %||% NA_character_),
    place_guess = as.character(results$place_guess %||% NA_character_),
    latitude = as.numeric(vapply(results$geojson$coordinates, function(x) if (!is.null(x)) x[2] else NA_real_, numeric(1))),
    longitude = as.numeric(vapply(results$geojson$coordinates, function(x) if (!is.null(x)) x[1] else NA_real_, numeric(1))),
    quality_grade = as.character(results$quality_grade %||% NA_character_),
    user_login = as.character(results$user$login %||% NA_character_)
  )
}

#' Search iNaturalist taxa
#'
#' @param q Search query (e.g. "wolf", "Canis lupus")
#' @param per_page Results per page (default 30, max 200)
#' @return tibble: id, name, common_name, rank, observations_count, iconic_taxon_name
inat_taxa <- function(q, per_page = 30) {
  url <- sprintf("%s/taxa?q=%s&per_page=%d", .inat_base,
                 utils::URLencode(q, reserved = TRUE), as.integer(per_page))
  raw <- .fetch_json(url)
  results <- raw$results
  if (is.null(results) || length(results) == 0) return(.schema_taxa)

  tibble(
    id = as.integer(results$id),
    name = as.character(results$name),
    common_name = as.character(
      if (!is.null(results$preferred_common_name)) results$preferred_common_name
      else NA_character_
    ),
    rank = as.character(results$rank),
    observations_count = as.integer(results$observations_count),
    iconic_taxon_name = as.character(results$iconic_taxon_name %||% NA_character_)
  )
}

# == Context ===================================================================

#' Generate LLM-friendly context for inaturalist.org
#'
#' @return Character string with full function signatures and bodies
inat_context <- function() {
  src_file <- NULL
  tryCatch(src_file <- sys.frame(1)$ofile, error = function(e) NULL)
  if (is.null(src_file) || !file.exists(src_file)) {
    tryCatch({
      f <- sys.frame(0)$ofile
      if (!is.null(f) && file.exists(f)) src_file <<- f
    }, error = function(e) NULL)
  }
  if (is.null(src_file)) src_file <- "clients/inaturalist.org.R"
  if (!file.exists(src_file)) {
    cat("# inaturalist.org context - source not found\n")
    return(invisible("# inaturalist.org context - source not found"))
  }
  lines <- readLines(src_file, warn = FALSE)
  n <- length(lines)
  fn_indices <- grep("^([a-zA-Z][a-zA-Z0-9_.]*) <- function[(]", lines)
  blocks <- list()
  for (fi in fn_indices) {
    fn_name <- sub(" <- function[(].*", "", lines[fi])
    if (startsWith(fn_name, ".")) next
    j <- fi - 1; rox_start <- fi
    while (j > 0 && grepl("^#'", lines[j])) { rox_start <- j; j <- j - 1 }
    rox <- if (rox_start < fi) lines[rox_start:(fi - 1)] else character()
    depth <- 0; end_line <- fi
    for (k in fi:n) {
      depth <- depth + nchar(gsub("[^{]", "", lines[k])) - nchar(gsub("[^}]", "", lines[k]))
      if (depth == 0 && k >= fi) { end_line <- k; break }
    }
    body <- lines[fi:end_line]
    blocks[[length(blocks) + 1]] <- c(rox, body, "")
  }
  out <- paste(unlist(blocks), collapse = "\n")
  cat(out, "\n")
  invisible(out)
}

