# == Services ==================================================================

#' List available Montana GIS map services
#'
#' @param folder Optional folder name (e.g. "MSDI_Framework", "DLI", "MSL")
#' @return tibble: name, type
#' @export
mtgis_services <- function(folder = NULL) {
  path <- if (is.null(folder)) "" else paste0("/", folder)
  url <- paste0(.mtgis_base, path, "?f=json")
  res <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(res)) return(.schema_service)

  services <- res$services
  folders <- res$folders
  out <- .schema_service
  if (!is.null(services) && nrow(services) > 0) {
    out <- tibble(
      name = as.character(services$name),
      type = as.character(services$type)
    )
  }
  if (!is.null(folders) && length(folders) > 0) {
    folder_rows <- tibble(name = as.character(folders), type = rep("Folder", length(folders)))
    out <- bind_rows(out, folder_rows)
  }
  out
}

# == Layers ====================================================================

#' List layers in a Montana GIS map service
#'
#' @param service Service path (e.g. "MSDI_Framework/Boundaries")
#' @return tibble: id, name, type, geometryType, minScale, maxScale
#' @export
mtgis_layers <- function(service) {
  url <- paste0(.mtgis_base, "/", service, "/MapServer?f=json")
  res <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(res) || is.null(res$layers)) return(.schema_layer)

  d <- res$layers
  tibble(
    id = as.integer(.safe_col(d, "id", NA_integer_)),
    name = as.character(.safe_col(d, "name")),
    type = as.character(.safe_col(d, "type")),
    geometryType = as.character(.safe_col(d, "geometryType")),
    minScale = as.numeric(.safe_col(d, "minScale", NA_real_)),
    maxScale = as.numeric(.safe_col(d, "maxScale", NA_real_))
  )
}

# == Query Features ============================================================

#' Query features from a Montana GIS map layer
#'
#' @param service Service path (e.g. "MSDI_Framework/Boundaries")
#' @param layer_id Numeric layer ID
#' @param where SQL where clause (default "1=1" for all)
#' @param out_fields Comma-separated field names (default "*" for all)
#' @param max_records Maximum records to return (default 100, max 1000)
#' @return tibble of feature attributes
#' @export
mtgis_query <- function(service, layer_id, where = "1=1",
                        out_fields = "*", max_records = 100) {
  url <- sprintf(
    "%s/%s/MapServer/%d/query?where=%s&outFields=%s&f=json&resultRecordCount=%d&returnGeometry=false",
    .mtgis_base, service, layer_id,
    utils::URLencode(where, reserved = TRUE),
    utils::URLencode(out_fields, reserved = TRUE),
    min(max_records, 1000)
  )
  res <- tryCatch(.fetch_json(url), error = function(e) NULL)
  if (is.null(res) || is.null(res$features) || length(res$features) == 0)
    return(.schema_feature)

  attrs <- res$features$attributes
  if (is.data.frame(attrs)) as_tibble(attrs)
  else .schema_feature
}

# == Boundaries (convenience) ==================================================

#' Get Montana county boundaries (attributes only)
#'
#' @param max_records Maximum records (default 100)
#' @return tibble of county attributes: OBJECTID, NAME, FIPS, Acres, SQMILES, etc.
#' @export
mtgis_counties <- function(max_records = 100) {
  # County boundaries are layer 8 in the Boundaries service
  mtgis_query("MSDI_Framework/Boundaries", layer_id = 8,
              max_records = max_records)
}

# == Context ===================================================================

#' Return the full source of this client for LLM context
#'
#' @return character string of the source file
#' @export
mtgis_context <- function() {
  f <- system.file("source", "gisservicemt.gov.R", package = "gisservicemt.gov", mustWork = FALSE)
  if (f == "") {
    sf <- sys.frame(1)$ofile %||% ""
    if (nzchar(sf)) f <- sf
  }
  if (nzchar(f)) paste(readLines(f, warn = FALSE), collapse = "\n") else
    "Source not found. Load from inst/source/gisservicemt.gov.R"
}
